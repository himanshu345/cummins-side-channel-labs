# issue.md — getting a clean signal out of Flush+Reload

This is the debugging log for making the attack actually work. Flush+Reload is
"simple in theory, finicky in practice" — the raw primitive is easy, but turning
the trace into correct key bits takes care. Every problem below is one we hit on
a 12th-gen Intel i7-1260P (a modern hybrid P-core/E-core laptop), with the
symptom, the root cause, and the fix. If `run.sh` gives you **no output, a hang,
or low accuracy**, work through these in order.

The attack has two halves, and they fail differently:

1. **Signal acquisition** — can we even see cache hits? (symptoms: 0 output, hang)
2. **Decoding** — can we turn the trace into correct bits? (symptom: ~50–70% accuracy)

---

## 1. Symptom: attack produces **no output** and seems to hang

**What happens:** `FR-attack` runs until `timeout` kills it and writes an empty
`trace.out`. It never prints anything.

**Root cause:** The tool buffers every sample and prints only *after* its trace
loop returns. The loop in Mastik's `fr_trace` **first waits for a cache hit**
before it starts recording:

```c
do { fr_probe(fr, results); } while (!is_active(results, len, threshold));
```

If no reload is ever faster than `THRESHOLD`, this spins forever. So "no output"
really means **"the threshold is wrong — nothing is ever counted as a hit."**

### Why the threshold is wrong
The stock Mastik value is `THRESHOLD = 100` cycles, which assumes a cache hit is
an **L1** hit (~44–65 cycles). But when the attacker and victim run on different
cores, a shared-line hit comes from the **L3** cache, which is slower
(~130–230 cycles here) — never below 100. Nothing crosses the threshold.

### Fix
`calibrate.c` measures this machine's actual hit and miss times and sets the
threshold **two-thirds of the way from hit to miss**, so it catches the slower
cross-thread hits while staying below genuine misses. On this box it picks
~200–205 instead of 100. You can sanity-check the numbers it prints:

```
calibrate: hit~55 cyc, miss~289 cyc -> THRESHOLD=205 ...
```

If `hit` and `miss` are *not* well separated (e.g. both ~300), Flush+Reload
cannot work in your environment at all — see §5.

---

## 2. Symptom: a hit signal exists, but accuracy is stuck near 50% (random)

**Root cause A — attacker and victim not on sibling threads.**
The classic version runs the spy and victim on **SMT sibling hardware threads**
(e.g. cores 2 and 3 of one physical core) so they share L1/L2 **and run at the
same time** — the spy can probe *during* the victim's exponentiation. If you pin
both to the *same* core, they time-share and the spy mostly misses the victim's
activity; if you leave them unpinned, they migrate across the hybrid chip's P/E
cores and the timing drifts.

**Fix:** `run.sh` auto-detects an SMT sibling pair from
`/sys/.../topology/thread_siblings_list` and pins victim and attacker to the two
threads of one physical core. On this machine that lifted clean hits from ~tens
to ~250,000. **If no SMT pair exists (Hyper-Threading disabled in BIOS), the
attack will be far weaker** — enable SMT, or expect poor results.

> Watch out: the siblings file can read `2-3` (a dash range) or `2,3`. Pinning to
> `taskset -c 2-3` lets the attacker roam *both* cores and collapses the signal —
> you must pin to the *single* sibling. `run.sh` parses this correctly.

**Root cause B — the time slot is shorter than one probe.** *(the big one)*
Each slot probes **three** cache lines. Measure how long that takes:

```
3-probe time cycles: median=2120 p90=2472 p99=3366
```

The stock slot was `SLOT = 2000` cycles — **below** the probe time. So every slot
overran, the tool had to skip ("miss") slots to catch up, and each missed slot
can drop a Square. A dropped Square is a **deleted bit**: every later bit shifts
by one and the decode falls apart (an *indel*, not a simple bit-flip, so it can't
be voted away). The paper says the same thing — it uses a 2,500-cycle slot for a
~2,200-cycle probe.

**Fix:** `calibrate.c` sets `SLOT` ≈ 1.1 × the measured 3-probe p90, so slots
stop overrunning. Note the tension: the slot must be **large enough** to avoid
misses but **small enough** to resolve individual operations. On a fast CPU the
fixed probe overhead (~2,100 cycles) is large relative to the operations, so
~2,500–3,000 is the sweet spot; much larger (e.g. 3,400) loses resolution and
accuracy drops again.

---

## 3. Symptom: decode works but caps around 67%

**Root cause:** the first decoder counted *reductions* between squares (bit 1 has
two reductions, bit 0 has one). But at a coarse slot the two reductions of a
1-bit merge into one sample, so 1-bits are systematically read as 0 — a bias that
caps accuracy around 67%.

**Fix (what `decode.py` does now):** decode on the **time between consecutive
squares** instead. A 0-bit is Square→Reduce (short); a 1-bit is
Square→Reduce→Multiply→Reduce (long). The interval histogram is cleanly bimodal,
and the split point is found automatically as the valley between the two peaks
(so it adapts to whatever `SLOT` calibration chose). The Multiply line itself is
unreliable here — GnuPG takes a Karatsuba code path that misses the monitored
line — but it isn't needed, because the interval already encodes the bit.

Also: merge Square hits that are only 1–2 slots apart into **one** Square event,
or a single long square fragments into several and injects spurious bits.

---

## 4. Symptom: one CRT branch (dq) is noticeably noisier than the other (dp)

**Root cause:** RSA signing uses CRT (`cipher/rsa.c`): it computes
`m^dp mod p` then `m^dq mod q`. The **first** exponentiation (`dp`) starts after
a quiet process startup — clean boundaries. The **second** (`dq`) is sandwiched
between the `mpi_fdiv_r` division that computes `d mod (q-1)` and the CRT
recombination multiplies that follow it; that adjacent arithmetic runs
cache-close to `dq`'s squares and injects more boundary misses. So `dq` captures
cleanly less often. This is expected — the paper's Table 3 shows the same
asymmetry between the two CRT components.

**Fix / takeaway:** you do **not** need both. Recover whichever branch is cleaner
in your run (`decode.py` tells you which), then factor `n` with it. Raising `SLOT`
above the probe time (§2) also reduces the misses that hurt `dq` the most.

---

## 5. Symptom: hit and miss times are *not* separated at all

If `calibrate.c` reports hit and miss both around the same large value (e.g. both
~300 cycles, no gap), the machine cannot resolve cache hits from misses and
Flush+Reload won't work here. Usual causes:

- Running inside a VM/sandbox that traps or emulates `rdtsc`/`clflush` and adds
  uniform overhead. Run on bare metal.
- `clflush` not effective (some non-Intel or virtualised setups). This attack is
  written for Intel x86-64.

On bare-metal Intel with SMT enabled, you should see a clean gap (hit ~40–80,
miss ~230–320) and the attack works.

---

## Quick checklist when it doesn't work

1. `calibrate` shows a clear hit/miss gap? → if not, §1 / §5.
2. `THRESHOLD` sits in the gap (not 100)? → §1.
3. `SLOT` is above your 3-probe time? → §2B.
4. Victim and attacker pinned to **sibling** threads (SMT on)? → §2A.
5. Accuracy still ~67%? → you're on an old decoder; use interval decoding, §3.
6. Only `dq` is bad? → that's expected; use `dp`, §4.

Every parameter above is measured automatically by `calibrate.c` and
`decode.py`; this file explains *why*, so you can debug a machine they don't
handle out of the box.
