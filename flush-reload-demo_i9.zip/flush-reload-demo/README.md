# Flush+Reload attack on GnuPG 1.4.13 — self-contained demo

This kit reproduces the **Flush+Reload cache side-channel attack** of
Yarom & Falkner (USENIX Security 2014, `../sec14-paper-yarom.pdf`) and uses it to
**recover an RSA private key from GnuPG 1.4.13** while it signs — by watching
which lines of GnuPG's code land in the CPU cache.

It is **fully self-contained**: one command builds everything, runs the attack,
and reports how many private-key bits it recovered.

```
./run.sh
```

---

## Is this safe to run? Yes.

- It **never touches your system**. Everything is built and run inside this folder.
- **No `sudo`.** No `make install`. Nothing is put on your `PATH`.
- It builds its **own** copy of the old, vulnerable GnuPG 1.4.13 locally. Your
  real `gpg` (and your real `~/.gnupg` keyring) are **never used or modified** —
  the attack uses a throwaway test key in an isolated keyring under `work/`.
- To reset completely, just delete the `work/` folder.

You are attacking a key that this script generated for the demo. Don't point it
at anyone else's key.

---

## Why an old GnuPG?

GnuPG 1.4.13 is the exact version from the original paper. **Current GnuPG**
(2.x / libgcrypt) fixed this leak with constant-time exponentiation and key
blinding, so the same attack produces no signal against it. Using the known-
vulnerable version isolates *the vulnerability* from *modern mitigations* —
that is the whole point of the demo. (See "Mitigations" below.)

---

## Requirements

Linux on an **Intel x86-64 CPU with Hyper-Threading enabled** (the attacker and
victim must run on sibling hardware threads). Then:

```bash
# Debian / Ubuntu
sudo apt-get install build-essential binutils-dev libdwarf-dev libelf-dev python3

# Fedora
sudo dnf install gcc make binutils-devel libdwarf-devel elfutils-libelf-devel python3
```

`binutils-dev` / `libdwarf-dev` / `libelf-dev` are needed so the attack tool can
map GnuPG source lines to addresses. `taskset` (from `util-linux`) is used for
CPU pinning and is normally already installed.

> These packages are a build dependency of the *attack tool*, not of GnuPG, and
> installing them is the only step that needs root — the attack itself does not.

No internet connection is required: the GnuPG source is bundled
(`gnupg-1.4.13.tar.bz2`).

---

## Usage

```bash
./run.sh                # 30 s capture, auto-pick an SMT sibling pair
./run.sh 60             # 60 s capture (more signatures = more clean traces)
./run.sh 30 2           # pin victim to core 2 (attacker goes to its sibling)
```

First run takes ~1–2 min (it builds Mastik and GnuPG). Later runs are seconds.

### What you should see

The run prints four steps:

```
==> Building ...            Build OK
==> Calibrating ...         calibrate: hit~55 cyc, miss~269 cyc -> THRESHOLD=194 ; SLOT=2800
==> Capturing traces for 20s ...

STEP 1  ORIGINAL PRIVATE PARAMETERS   (the secret, read from the test key)
   dp = d mod (p-1)   509 bits   0x1210b0fd...
   dq = d mod (q-1)   511 bits   0x5ccef372...

STEP 2  WHAT THE CAPTURED TRACE LOOKS LIKE
   slot    Multiply  Square  Reduce   meaning
   2001      ·       HIT      ·      square
   2005      ·        ·      HIT     modular reduce   ...
   decoded bits: 1000000100001011000011111101... 

STEP 3  CAPTURE SUMMARY
   5,000,000 slots -> 337,599 squares -> 427 candidate runs
   dp: 179 full-length traces (best 99.6%)
   dq: 289 full-length traces (best 100.0%)

STEP 4  RECOVERED PRIVATE PARAMETER vs ORIGINAL  (branch dq)
   original  : 1011100110011101111001101110010011101101...
   recovered : 1011100110011101111001101110010011101101...
   match     : ||||||||||||||||||||||||||||||||||||||||
   => 510 / 511 bits correct = 99.8% (1 wrong)
```

**Step 4 is the result**: the recovered bits placed next to the real secret, with
the match accuracy. One near-perfect capture of either CRT branch (`dp` or `dq`),
plus the public modulus `n`, is enough to **factor `n` and reconstruct the whole
private key**. Residual one- or two-bit errors are removed by combining 2–3
captures (as the paper describes).

**If you get 0 output, a hang, or low accuracy, read `issue.md`** — it documents
every signal problem we hit and how to fix it on a new machine.

---

## How it works (one paragraph)

GnuPG signs with RSA using **square-and-multiply** modular exponentiation
(`mpi/mpi-pow.c`). Every exponent bit does a Square then a Reduce; a **1**-bit
additionally does a Multiply then a Reduce. The attacker shares GnuPG's code
pages (same read-only file, same physical cache lines) and, in a tight loop,
**flushes** three specific code lines (Square / Multiply / Reduce) and times how
long it takes to **reload** them. A fast reload means the victim just executed
that line. The *time between consecutive Squares* is short for a 0-bit and long
for a 1-bit — so the trace spells out the private exponent. Signing uses CRT, so
each signature leaks `dp = d mod (p-1)` and `dq = d mod (q-1)`; either one plus
`n` recovers the key.

---

## Files

| File | What it is |
|------|-----------|
| `run.sh` | End-to-end: build → calibrate → attack → decode → report. |
| `src/calibrate.c` | Measures this CPU's cache hit/miss times and probe time, and prints the `THRESHOLD` and `SLOT` to use. **This is the portability fix** (see `issue.md`). |
| `src/FR-attack.c` | The Flush+Reload monitor. Records the Square/Multiply/Reduce trace. |
| `src/decode.py` | Decodes the trace into exponent bits and scores accuracy vs. ground truth. Auto-calibrates its thresholds, so it works at any slot size. |
| `src/parse_key.py` | Reads the throwaway secret key and computes the ground-truth `dp`/`dq`. |
| `src/keygen.batch` | Spec for the throwaway RSA-1024 test key. |
| `mastik/` | The Mastik side-channel toolkit (source only; built locally, never installed). |
| `gnupg-1.4.13.tar.bz2` | Source of the vulnerable GnuPG (built locally, never installed). |
| `issue.md` | The signal-quality debugging log: symptoms, root causes, fixes. |
| `work/` | Everything generated at run time (build outputs, keys, trace). Delete to reset. |

---

## Mitigations (what fixes the real bug)

The attack needs four things at once: secret-dependent code paths, shared memory
pages, a high-resolution timer, and the unprivileged `clflush` instruction.
Breaking any one stops it:

- **Constant-time crypto** (what modern GnuPG/libgcrypt did): the exponentiation
  no longer branches on secret bits, so there is nothing to see. This is the fix.
- **Key blinding**: randomizes the operand each time, so traces don't correlate.
- Disabling memory de-duplication / page sharing between distrusting tenants.
- Restricting `clflush` or high-resolution timers (partial, hardware-dependent).

---

## Credit

Mastik toolkit © CSIRO (GPLv3). Attack technique: Yuval Yarom and Katrina
Falkner, *"FLUSH+RELOAD: a High Resolution, Low Noise, L3 Cache Side-Channel
Attack"*, USENIX Security 2014. This kit wires those together with a calibration
and decoding pipeline for classroom reproduction.
