/*
 * Copyright 2016 CSIRO
 *
 * This file is part of Mastik.
 *
 * Mastik is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mastik is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Mastik.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "config.h"
#ifndef HAVE_BFD_H
#error Must have bfd to compile this
#endif

#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <bfd.h>
#if defined(HAVE_LIBDWARF_H)
#include <libdwarf.h>
#elif defined(HAVE_LIBDWARF_LIBDWARF_H)
#include <libdwarf/libdwarf.h>
#endif

#include <mastik/symbol.h>

static void initialise() {
  static int init = 0;
  if (init)
    return;
    
  bfd_init();
  init = 1;
}

uint64_t sym_loadersymboloffset(const char *file, const char *name) {
  initialise();

  bfd *abfd = NULL;
  asymbol **symbol_table = NULL;
  uint64_t rv = ~0ULL;

  abfd = bfd_openr(file, "default");
  if (abfd == NULL)
    goto out;



  if (!bfd_check_format(abfd, bfd_object)) {
    if (bfd_get_error () != bfd_error_file_ambiguously_recognized) 
      goto out;
  }

  long storage_needed = bfd_get_symtab_upper_bound (abfd);
  if (storage_needed <= 0) 
    goto out;

  symbol_table = (asymbol **) malloc (storage_needed);

  long number_of_symbols = bfd_canonicalize_symtab (abfd, symbol_table);
  if (number_of_symbols < 0) 
    goto out;

  for (long i = 0; i < number_of_symbols; i++) {
    if (!strcmp(name, symbol_table[i]->name)) {
      struct bfd_section *section = symbol_table[i]->section;
      rv = symbol_table[i]->value + section->filepos;
      goto out;
    }
  }


out:
  if (symbol_table != NULL)
    free(symbol_table);
  if (abfd != NULL)
    bfd_close(abfd);
  return rv;
}

uint64_t sym_addresstooffset(const char *file, uint64_t address) {
  initialise();

  bfd *abfd = NULL;
  uint64_t rv = ~0ULL;

  abfd = bfd_openr(file, "default");
  if (abfd == NULL)
    goto out;

  if (!bfd_check_format(abfd, bfd_object)) {
    if (bfd_get_error () != bfd_error_file_ambiguously_recognized) 
      goto out;
  }


// Interface for bfd changed in verison 2.33, support older versions as well
#ifdef HAVE_LEGACY_BFD

  for (asection *s = abfd->sections; s; s = s->next) {
    if (bfd_get_section_flags (abfd, s) & (SEC_LOAD)) {
      uint64_t vma = bfd_section_vma(abfd, s);
      uint64_t size = bfd_section_size(abfd, s);
      if (address >= vma && address - vma  < size) {
	rv = address - vma + s->filepos;
	break;
      }
    }
  }

#else

  for (asection *s = abfd->sections; s; s = s->next) {
    if (bfd_section_flags (s) & (SEC_LOAD)) {
      uint64_t vma = bfd_section_vma(s);
      uint64_t size = bfd_section_size(s);
      if (address >= vma && address - vma  < size) {
	rv = address - vma + s->filepos;
	break;
      }
    }
  }

#endif

out:
  if (abfd != NULL)
    bfd_close(abfd);
  return rv;
}


/*
 * Ported from the legacy libdwarf API (dwarf_init / dwarf_next_cu_header /
 * dwarf_siblingof / dwarf_srclines), which was removed in libdwarf 0.x, to the
 * current API (dwarf_init_b / dwarf_next_cu_header_d / dwarf_siblingof_b /
 * dwarf_srclines_b + dwarf_srclines_from_linecontext). Behaviour is unchanged.
 */
uint64_t sym_debuglineoffset(const char *file, const char *src, int lineno) {
#ifdef HAVE_DWARF
  Dwarf_Debug dbg = NULL;
  int res = DW_DLV_ERROR;
  Dwarf_Error error = NULL;
  Dwarf_Die die = NULL;
  char *name = NULL;
  Dwarf_Line *linebuf = NULL;
  Dwarf_Signed linecount = 0;
  Dwarf_Unsigned line;
  Dwarf_Addr lineaddr;
  Dwarf_Line_Context linecontext = NULL;
  int fd = -1;
  uint64_t rv = ~0ULL;

  fd = open(file, O_RDONLY);
  if(fd < 0)
    goto out;

  res = dwarf_init_b(fd, DW_GROUPNUMBER_ANY, NULL, NULL, &dbg, &error);
  if (res != DW_DLV_OK) {
    if (error && dbg)
      dwarf_dealloc_error(dbg, error);
    goto out;
  }

  for (;;) {
    Dwarf_Unsigned next_cu_header;
    Dwarf_Half header_cu_type;
    res = dwarf_next_cu_header_d(dbg, 1 /* is_info */,
            NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
            &next_cu_header, &header_cu_type, &error);
    if (res != DW_DLV_OK)
      goto out;

    // The first sibling is a DW_TAG_compile_unit
    res = dwarf_siblingof_b(dbg, NULL, 1 /* is_info */, &die, &error);
    if (res != DW_DLV_OK)
      goto out;

    res = dwarf_diename(die, &name, &error);
    if (res != DW_DLV_OK) {
      dwarf_dealloc_die(die);
      die = NULL;
      continue;
    }

    int found = (name != NULL && !strcmp(name, src));

    dwarf_dealloc(dbg, name, DW_DLA_STRING);
    name = NULL;
    if (found)
      break;

    dwarf_dealloc_die(die);
    die = NULL;
  }

  {
    Dwarf_Unsigned version = 0;
    Dwarf_Small table_count = 0;
    res = dwarf_srclines_b(die, &version, &table_count, &linecontext, &error);
    if (res != DW_DLV_OK)
      goto out;
    res = dwarf_srclines_from_linecontext(linecontext, &linebuf, &linecount, &error);
    if (res != DW_DLV_OK)
      goto out;
  }

  int nextline = 0;
  uint64_t nextaddr = ~0ULL;
  for (Dwarf_Signed i = 0; i < linecount; i++) {
    if (dwarf_lineno(linebuf[i], &line, &error) != DW_DLV_OK)
      continue;
    if (dwarf_lineaddr(linebuf[i], &lineaddr, &error) != DW_DLV_OK)
      continue;
    if (rv == ~0ULL) {
      if ((Dwarf_Unsigned)lineno == line)
	rv = lineaddr;
      else if (line > (Dwarf_Unsigned)lineno) {
	if (nextline == 0 || (Dwarf_Unsigned)nextline > line) {
	  nextline = line;
	  nextaddr = lineaddr;
	}
      }
    }
  }

  if (rv == ~0ULL)
    rv = nextaddr;
  if (rv != ~0ULL)
    rv = sym_addresstooffset(file, rv);


out:
  // The line table (linebuf) is owned by linecontext; freeing the context
  // releases it, so there is no per-line dealloc as in the legacy API.
  if (linecontext != NULL)
    dwarf_srclines_dealloc_b(linecontext);
  if (name != NULL)
    dwarf_dealloc(dbg, name, DW_DLA_STRING);
  if (die != NULL)
    dwarf_dealloc_die(die);
  if (dbg != NULL)
    dwarf_finish(dbg);
  if (fd >=0)
    close(fd);
  return rv;
#else
  return ~0ULL;
#endif
}


