#!/usr/bin/env python3
# Parse an unprotected OpenPGP v4 RSA secret key packet -> n,e,d,p,q and CRT exps.
import sys

data = open(sys.argv[1], "rb").read()

# --- packet header ---
b0 = data[0]
assert b0 & 0x80, "not a packet"
if b0 & 0x40:                      # new format
    tag = b0 & 0x3f
    l = data[1]
    assert l < 192, "unexpected long length"
    off = 2
else:                               # old format
    tag = (b0 >> 2) & 0x0f
    lentype = b0 & 0x03
    sizes = {0: 1, 1: 2, 2: 4}
    nb = sizes[lentype]
    off = 1 + nb
assert tag == 5, f"expected secret key packet (tag 5), got {tag}"

p = off
def u8():
    global p; v = data[p]; p += 1; return v
def u32():
    global p; v = int.from_bytes(data[p:p+4], "big"); p += 4; return v
def mpi():
    global p
    bits = int.from_bytes(data[p:p+2], "big"); p += 2
    nbytes = (bits + 7) // 8
    v = int.from_bytes(data[p:p+nbytes], "big"); p += nbytes
    return v

ver = u8(); assert ver == 4
u32()                      # creation time
algo = u8(); assert algo in (1, 2, 3), f"not RSA (algo {algo})"
n = mpi(); e = mpi()       # public
s2k = u8(); assert s2k == 0, f"key is protected (s2k usage {s2k}) - re-export unprotected"
d = mpi(); pp = mpi(); qq = mpi(); u = mpi()

# gpg stores p<q with u=p^-1 mod q; CRT exps:
dp = d % (pp - 1)
dq = d % (qq - 1)

def bits(x): return bin(x)[2:]
print("n_bits", n.bit_length(), "e", e)
print("d_bits", d.bit_length())
print("p_bits", pp.bit_length(), "q_bits", qq.bit_length())
print("dp_bits", dp.bit_length(), "dq_bits", dq.bit_length())
# emit the bitstrings (MSB first) for the decoder to compare against
with open(sys.argv[2], "w") as f:
    f.write("d "  + bits(d)  + "\n")
    f.write("dp " + bits(dp) + "\n")
    f.write("dq " + bits(dq) + "\n")
    # public key -- the only thing a real attacker also has; used by the
    # finishing step (STEP 6) to factor n from the recovered dp.
    f.write("n " + str(n) + "\n")
    f.write("e " + str(e) + "\n")
print("wrote bitstrings to", sys.argv[2])
