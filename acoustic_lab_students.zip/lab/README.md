# Acoustic Side-Channel Attacks — Hands-On Lab

Build the acoustic attacks yourself: recover **keypad numbers, typed words and sentences** from
sound, learn to **judge whether a result is real**, and test **defences**. Everything runs in
Python/Jupyter against the recordings included in `data/` — no extra downloads.

## Setup (any OS)

```bash
cd lab
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
jupyter notebook 00_setup_check.ipynb
```

Run **Lab 0** first — if every cell prints OK, you're ready. Each later notebook has cells with
`...` **TODO stubs** for you to complete. Your instructor has the worked solutions.

## The notebooks

Two ways to work:

- **One notebook, easiest -> hardest:** open **`Cummins_ASCA_All_Labs.ipynb`** and run top to
  bottom (recommended for the live session; it starts with the DTMF attack so everyone succeeds early).
- **Or the separate notebooks `00-08`** (original numbering):

| Notebook | What you do | Level |
|---|---|---|
| **00** Setup check | confirm your environment works | — |
| **06** Keypad tones (DTMF) | read a dialled number — no ML needed | ★ |
| **01** Signal & segmentation | spectrogram, band-pass, find each keystroke | ★★ |
| **02** Features & classifier | 3 vs 16 features, k-NN vs random forest | ★★ |
| **03** Evaluation pitfalls | pooled vs cross-session vs calibration | ★★★ |
| **05** Defences | noise & bandwidth vs a naive / adaptive attacker | ★★★ |
| **07** Beyond keyboards | app & CPU-instruction emanations; "is 100% meaningful?" | ★★★ |
| **04** Words → sentences | Trie + language model, hard vs soft decoding | ★★★★ |
| **08** Bonus — record your own | capture and attack your own typing (needs a mic) | — |

## Ground rules
Record only your **own** typing, or with explicit consent. Only ever test systems and people you
are authorised to.
