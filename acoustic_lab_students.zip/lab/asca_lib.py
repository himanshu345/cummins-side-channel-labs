"""Helper library for the Cummins ASCA hands-on lab.
Everything the notebooks share lives here so notebooks stay short and readable."""
import os, glob, warnings
import numpy as np
import librosa
from scipy.signal import butter, sosfiltfilt, find_peaks
from scipy.stats import kurtosis

warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
SR = 22050            # all lab audio is resampled to this
LETTERS = list("abcdefghijklmnopqrstuvwxyz")


def load(path, sr=SR):
    y, _ = librosa.load(path, sr=sr, mono=True)
    return y


def bandpass(y, lo=200, hi=500, sr=SR, order=4):
    sos = butter(order, [lo / (sr / 2), hi / (sr / 2)], btype="band", output="sos")
    return sosfiltfilt(sos, y)


def energy_envelope(y, sr=SR, lo=200, hi=500, smooth_ms=15):
    f = bandpass(y, lo, hi, sr)
    win = max(1, int(smooth_ms / 1000 * sr))
    return np.convolve(f ** 2, np.ones(win) / win, mode="same")


def detect_keystrokes(y, sr=SR, rel_thresh=1 / 8, min_gap_s=0.5, lo=200, hi=500):
    """Return sample indices of keystroke peaks (energy envelope + find_peaks)."""
    env = energy_envelope(y, sr, lo, hi)
    thr = env.max() * rel_thresh
    peaks, _ = find_peaks(env, height=thr, distance=int(min_gap_s * sr))
    return peaks, env, thr


def clip_around(y, peak, sr=SR, half_s=0.15):
    h = int(half_s * sr)
    return y[max(0, peak - h): min(len(y), peak + h)]


def features(clip, sr=SR):
    """Per-keystroke feature vector: spectral kurtosis, mean pitch, short-time
    energy (original thesis features) + 13 MFCC means (added for the lab)."""
    if len(clip) < 1024:
        clip = np.pad(clip, (0, 1024 - len(clip)))
    c = librosa.effects.preemphasis(clip)
    P = np.abs(librosa.stft(c, n_fft=1024)) ** 2
    sk = float(np.mean(kurtosis(P, axis=1)))
    pit = librosa.piptrack(y=c, sr=sr, n_fft=1024)[0]
    nz = pit[pit > 0]
    pm = float(nz.mean()) if nz.size else 0.0
    fl, hl = int(0.02 * sr), int(0.01 * sr)
    ste = float(np.mean([np.sum(c[i:i + fl] ** 2) for i in range(0, max(1, len(c) - fl), hl)]))
    mf = librosa.feature.mfcc(y=c, sr=sr, n_mfcc=13, n_fft=1024).mean(axis=1)
    return np.concatenate([[sk, pm, ste], mf])


FEATURE_NAMES = ["spectral_kurtosis", "pitch", "ste"] + [f"mfcc{i}" for i in range(13)]


def load_clips(sessions=(1, 2)):
    """Return (clips, letters, sessions) for the shipped keystroke-clip dataset."""
    clips, labels, sess = [], [], []
    for s in sessions:
        for p in sorted(glob.glob(os.path.join(DATA, "clips", f"session{s}", "*", "*.wav"))):
            clips.append(load(p)); labels.append(p.split(os.sep)[-2]); sess.append(s)
    return clips, np.array(labels), np.array(sess)


def feature_matrix(clips, feat_fn=features):
    return np.array([feat_fn(c) for c in clips])


def topk_accuracy(proba, classes, y_true, k=5):
    classes = np.asarray(classes)
    return float(np.mean([y_true[i] in classes[np.argsort(proba[i])[::-1][:k]] for i in range(len(y_true))]))


def add_noise(clip, snr_db, rng):
    """Add white noise to reach a given signal-to-noise ratio (dB)."""
    p = np.mean(clip ** 2) + 1e-12
    return clip + rng.normal(0, np.sqrt(p / 10 ** (snr_db / 10)), len(clip))


def lowpass(clip, cutoff, sr=SR, order=4):
    sos = butter(order, cutoff / (sr / 2), btype="low", output="sos")
    return sosfiltfilt(sos, clip)


class Trie:
    def __init__(self):
        self.root = {}

    def insert(self, w):
        n = self.root
        for ch in w:
            n = n.setdefault(ch, {})
        n["$"] = True

    def search(self, cand_lists):
        """All dictionary words whose i-th letter is in cand_lists[i]."""
        out = []

        def dfs(node, d, acc):
            if d == len(cand_lists):
                if "$" in node:
                    out.append(acc)
                return
            for ch in cand_lists[d]:
                if ch in node:
                    dfs(node[ch], d + 1, acc + ch)
        dfs(self.root, 0, "")
        return out


class LanguageModel:
    """Tiny Brown-corpus unigram+bigram model (no downloads, no GPU)."""

    def __init__(self):
        import json
        self.uni = json.load(open(os.path.join(DATA, "lm_unigram.json")))
        self.bi = json.load(open(os.path.join(DATA, "lm_bigram.json")))
        self.total = sum(self.uni.values())

    def words(self):
        return list(self.uni)

    def logp_word(self, w, prev=None):
        pu = (self.uni.get(w, 0) + 0.5) / self.total
        if prev is None:
            return float(np.log(pu))
        c_prev = self.uni.get(prev, 0)
        pb = self.bi.get(f"{prev} {w}", 0) / c_prev if c_prev else 0.0
        return float(np.log(0.7 * pb + 0.3 * pu))     # interpolation

    def score(self, sentence):
        ws = sentence.split()
        return sum(self.logp_word(w, ws[i - 1] if i else None) for i, w in enumerate(ws))


# ───────────────────────── DTMF (Lab 6) ─────────────────────────
import csv
from scipy.signal import lfilter, periodogram

DTMF_LOW = [697, 770, 852, 941]
DTMF_HIGH = [1209, 1336, 1477]
DTMF_ALL = DTMF_LOW + DTMF_HIGH
DTMF_KEYS = {(697, 1209): "1", (697, 1336): "2", (697, 1477): "3", (770, 1209): "4", (770, 1336): "5", (770, 1477): "6",
             (852, 1209): "7", (852, 1336): "8", (852, 1477): "9", (941, 1209): "*", (941, 1336): "0", (941, 1477): "#"}


def frame_signal(y, sr, frame_ms=40.0, hop_ms=10.0):
    fl, hop = int(sr * frame_ms / 1000), int(sr * hop_ms / 1000)
    starts = np.arange(0, max(1, len(y) - fl), hop)
    return np.stack([y[s:s + fl] for s in starts])


def goertzel_power(x, sr, freq):
    """Energy of signal x at ONE frequency (Goertzel recursion, O(N))."""
    k = int(0.5 + len(x) * freq / sr)
    coeff = 2 * np.cos(2 * np.pi * k / len(x))
    s1 = s2 = 0.0
    for v in x:
        s0 = v + coeff * s1 - s2
        s2, s1 = s1, s0
    return s1 * s1 + s2 * s2 - coeff * s1 * s2


def tone_powers(frames, sr):
    """Vectorised version: (n_frames, 7) energies at the 7 DTMF frequencies (direct DFT at the exact frequency)."""
    n = frames.shape[1]; t = np.arange(n) / sr
    E = np.stack([np.exp(-2j * np.pi * f * t) for f in DTMF_ALL], axis=1)        # (n, 7)
    return np.abs(frames @ E) ** 2          # rectangular window (a Hann window leaves a stray tone frame in Demo 7 - try it!)


def classify_frames(frames, powers, min_energy=0.01, min_share=0.30, dominance=2.0):
    """Per frame: a digit character, or None if the frame is not a clean DTMF tone."""
    energy = (frames ** 2).mean(1); emax = energy.max() or 1.0
    labels = []
    for e, p in zip(energy, powers):
        lo = np.argsort(p[:4])[::-1]; hi = np.argsort(p[4:])[::-1]
        share = (p[lo[0]] + p[4 + hi[0]]) / (p.sum() + 1e-12)
        ok = e > min_energy * emax and share > min_share and p[lo[0]] > dominance * p[lo[1]] and p[4 + hi[0]] > dominance * p[4 + hi[1]]
        labels.append(DTMF_KEYS[(DTMF_LOW[lo[0]], DTMF_HIGH[hi[0]])] if ok else None)
    return labels


def group_presses(labels, typ_frames=None, min_run=7, bridge=3):
    """Frames -> key presses: bridge tiny dropouts, keep runs >= min_run frames, split long runs into repeats."""
    lab = list(labels); n = len(lab); i = 0
    while i < n:
        if lab[i] is None:
            j = i
            while j < n and lab[j] is None: j += 1
            if 0 < i < j < n and lab[i - 1] == lab[j] and j - i <= bridge:
                for k in range(i, j): lab[k] = lab[j]
            i = j
        else:
            i += 1
    runs, i = [], 0
    while i < n:
        v, j = lab[i], i
        while j < n and lab[j] == v: j += 1
        if v is not None and j - i >= min_run: runs.append((v, j - i))
        i = j
    digits = ""
    if runs:
        typ = typ_frames or sorted(r[1] for r in runs)[len(runs) // 2]
        for v, L in runs: digits += v * max(1, round(L / typ))
    return runs, digits


def dtmf_truth():
    with open(os.path.join(DATA, "dtmf", "truth.csv")) as f:
        return {r["file"]: (float(r["distance_samples_44k"]), r["number"]) for r in csv.DictReader(f)}


# ───────────────── Device emanations (Lab 7): phone apps & CPU instructions ─────────────────
from sklearn.feature_selection import mutual_info_classif


def window_features(y, sr, win_ms=30, hop_ms=15):
    """Per-window features for app identification: 13 MFCC + spectral centroid + RMS + zero-crossing rate."""
    n, h = int(win_ms / 1000 * sr), int(hop_ms / 1000 * sr)
    M = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13, n_fft=n, hop_length=h, n_mels=40)
    c = librosa.feature.spectral_centroid(y=y, sr=sr, n_fft=n, hop_length=h)
    r = librosa.feature.rms(y=y, frame_length=n, hop_length=h)
    z = librosa.feature.zero_crossing_rate(y, frame_length=n, hop_length=h)
    return np.vstack([M, c, r, z]).T


APP_FEATURE_NAMES = [f"mfcc{i}" for i in range(13)] + ["centroid", "rms", "zcr"]


def mrmr_select(X, y, k=8, random_state=0):
    """Simplified mRMR: greedily pick the feature maximising  relevance - mean |correlation| with already-chosen ones.
    relevance = mutual information with the label."""
    rel = mutual_info_classif(X, y, random_state=random_state)
    C = np.abs(np.corrcoef(X, rowvar=False)); chosen = [int(np.argmax(rel))]
    while len(chosen) < k:
        score = [(rel[j] - C[j, chosen].mean()) if j not in chosen else -np.inf for j in range(X.shape[1])]
        chosen.append(int(np.argmax(score)))
    return chosen, rel


def loudness_envelope(x, fs, tau=0.125):
    """Fast-weighted (125 ms) sound level in dB, like an SPL meter, mean removed."""
    a = np.exp(-1 / (tau * fs)); L = 10 * np.log10(lfilter([1 - a], [1, -a], x ** 2) + 1e-20)
    return L - L.mean()


def psd_block_feature(block, fs, n_feat=7):
    """Thesis feature: first n_feat bins of the centred periodogram of the loudness envelope of one block."""
    p = np.fft.fftshift(periodogram(loudness_envelope(block, fs), fs=fs, return_onesided=False)[1])
    return np.log10(p[:n_feat] + 1e-30)
