"""Record a short mono WAV from the default microphone (for the optional bonus lab).
usage: python record_keystrokes.py --seconds 15 --out my_typing.wav
Only record your own typing, with everyone's consent."""
import argparse, time
import sounddevice as sd, soundfile as sf
ap = argparse.ArgumentParser(); ap.add_argument("--seconds", type=float, default=15)
ap.add_argument("--out", default="my_typing.wav"); ap.add_argument("--sr", type=int, default=22050)
a = ap.parse_args()
print("Starting in 3 s..."); time.sleep(3); print("GO — type now!")
rec = sd.rec(int(a.seconds * a.sr), samplerate=a.sr, channels=1, dtype="float32"); sd.wait()
sf.write(a.out, rec, a.sr); print("saved", a.out)
