# Worksheet — the Transient Execution Lab (clickable simulator)

Open **`Transient Execution Lab (Copy).html`** in a browser. Keys: **→** step, **Space** play/pause.
Work through the two tabs and answer the questions. (Answers are in `INSTRUCTOR_GUIDE.md`.)

The screen has: **Attacker's view** (recovered bytes) across the top; a left column (code,
predictor / protection state, reorder buffer) = *the CPU doing the work*; a right column
(probe grid + timing chart) = *the attacker's channel*.

---

## Part 1 — Spectre v1 tab

Set the speed slider low. Press **Step** and watch one byte at a time.

1. During the **Train** phase, what happens to the **Branch predictor** counter, and why does
   the attacker want it in the "Strongly in" state?

2. At the **Flush** phase, two things are flushed: the probe lines **and** `array1_size`.
   Why flush `array1_size`? (What does it do to the bounds check?)

3. At the **Transient** phase, exactly one cell in the **Probe array** lights up red.
   What decides *which* cell? Write down its index.

4. At the **Squash** phase: which parts of the screen get rolled back, and which one thing
   **does not**? Why is that the whole point of the attack?

5. At **Reload**, look at the timing chart. How does the attacker know which byte it was,
   without ever being told?

6. Now tick **Mitigation: lfence after bounds check** and press **Play**. Describe what the
   reorder buffer and probe grid do differently, and why nothing is recovered.

7. Tick **Realistic noise**. Why does the attacker now need to repeat and vote?

---

## Part 2 — Meltdown tab

Notice what changed vs the Spectre tab before you start: the code panel now says **"Attacker
code — no victim cooperation needed"**, and the middle panel is **Protection state**, not a
branch predictor.

8. There is no "Train" phase here. Why does Meltdown need no training and no victim gadget?

9. At the **Load** phase, read the **Protection state** panel. What does *"U/S check pending,
   data forwarded"* mean, and why is it the essence of Meltdown?

10. At **Retire + #PF**: what is raised, what gets squashed, and what survives?

11. Tick **Mitigation: KPTI** and replay. Read the Protection state and reorder buffer:
    *why* is there now nothing to leak? (Answer in terms of the three ingredients.)

---

## Wrap-up (both tabs)

12. Both attacks end with the **same** right-hand picture (one warm probe line, one timing dip).
    In one sentence, what do Spectre and Meltdown have in common, and how do they differ in how
    the transient window opens?

13. Map each mitigation you toggled (lfence, KPTI) to **which of the three ingredients** it
    removes. Are they computation-side or channel-side?
