# Microarchitectural Side-Channel Attacks — Hands-On Lab

Build the attacks yourself: **Flush+Reload, Spectre v1, and Meltdown**, then watch the defences
stop them. The core labs run against a small **deterministic model** of a CPU cache
(`uarch_lib.py`), so they work on **Windows, macOS and Linux** — nothing depends on your real
CPU. (A real-hardware bonus is in `native/`, Linux/x86 only.)

## Setup (any OS)

```bash
cd microarch_lab
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
jupyter notebook 00_setup_and_your_machine.ipynb
```

Work through the notebooks **in order, 00 → 05**. Each has **`# TODO`** cells (marked by a
"Your turn" heading and a `raise NotImplementedError`) for you to complete, and self-checks that
print `PASS` / `FAIL`. Your instructor has the worked solutions.

| Notebook | You build |
|---|---|
| **00** Setup | check your machine's real Spectre/Meltdown status |
| **01** Cache timing & Flush+Reload | the timing **read-out** that recovers a byte |
| **02** Covert channel | send a message through the cache |
| **03** Spectre v1 | leak a secret past a bounds check — then stop it with index masking |
| **04** Meltdown | dump "kernel" memory — then stop it with KPTI |
| **05** Defences | score which **ingredient** each defence breaks |

## Also here
- **`HTML_lab_worksheet.md`** — questions to answer while you drive the clickable
  *Transient Execution Lab* simulator (your instructor provides the `.html`).
- **`native/`** — *bonus:* real Flush+Reload in C on actual silicon (Linux/x86-64, needs `gcc`).

## Ground rules
These notebooks are a **model**, not a weapon, and the `native/` code only ever reads cache
lines of its own arrays. Only ever test systems you are **authorised** to test.
