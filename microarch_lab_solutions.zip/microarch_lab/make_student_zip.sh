#!/usr/bin/env bash
#
# make_student_zip.sh — rebuild the student hand-out zip from this lab folder.
#
# Produces  ../microarch_lab_students.zip  containing ONLY what students need:
#   the 6 notebooks with TODO stubs (flattened to the top level), uarch_lib.py,
#   the native/ bonus (C sources), requirements.txt, the HTML worksheet, and a
#   student-facing README.
#
# It EXCLUDES solutions/, INSTRUCTOR_GUIDE.md, nbgen.py and this script, and
# verifies no runnable solution code or saved outputs leaked in.
#
# Usage:   bash make_student_zip.sh            # package the existing student/ stubs
#          bash make_student_zip.sh --regen    # first re-run nbgen.py (rebuilds student/ AND
#                                              # solutions/ from source; clears solution outputs)
#
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"      # the microarch_lab/ folder
OUT="$ROOT/../microarch_lab_students.zip"
STAGE="$(mktemp -d)"
PKG="$STAGE/microarch_lab"
PY="$(command -v python3 || command -v python)"
REGEN="${1:-}"

cleanup() { rm -rf "$STAGE"; }
trap cleanup EXIT

if [ "$REGEN" = "--regen" ]; then
    echo "==> --regen: rebuilding student/ and solutions/ from nbgen.py"
    ( cd "$ROOT" && "$PY" nbgen.py >/dev/null ) && echo "    done (solution outputs cleared)"
else
    echo "==> using existing student/ notebooks (pass --regen to rebuild from nbgen.py)"
fi

echo "==> staging student-only files (flattened)"
mkdir -p "$PKG/native"
cp "$ROOT"/student/*.ipynb        "$PKG"/
cp "$ROOT"/student/uarch_lib.py   "$PKG"/ 2>/dev/null || cp "$ROOT"/uarch_lib.py "$PKG"/
cp "$ROOT"/requirements.txt       "$PKG"/
cp "$ROOT"/HTML_lab_worksheet.md  "$PKG"/
cp "$ROOT"/native/cache_timing.c "$ROOT"/native/covert_channel.c "$ROOT"/native/README.md "$PKG"/native/

echo "==> writing student-facing README"
cat > "$PKG/README.md" <<'MD'
# Microarchitectural Side-Channel Attacks — Hands-On Lab

Build the attacks yourself: **Flush+Reload, Spectre v1, and Meltdown**, then watch the defences
stop them. The core labs run against a small **deterministic model** of a CPU cache
(`uarch_lib.py`), so they work on **Windows, macOS and Linux** — nothing depends on your real
CPU. (A real-hardware bonus is in `native/`, Linux/x86 only.)

## Setup (any OS)

```bash
cd microarch_lab
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
jupyter notebook 00_setup_and_your_machine.ipynb
```

Work through the notebooks **in order, 00 → 05**. Each has **`# TODO`** cells (marked by a
"Your turn" heading and a `raise NotImplementedError`) for you to complete, and self-checks that
print `PASS` / `FAIL`. Your instructor has the worked solutions.

| Notebook | You build |
|---|---|
| **00** Setup | check your machine's real Spectre/Meltdown status |
| **01** Cache timing & Flush+Reload | the timing **read-out** that recovers a byte |
| **02** Covert channel | send a message through the cache |
| **03** Spectre v1 | leak a secret past a bounds check — then stop it with index masking |
| **04** Meltdown | dump "kernel" memory — then stop it with KPTI |
| **05** Defences | score which **ingredient** each defence breaks |

## Also here
- **`HTML_lab_worksheet.md`** — questions to answer while you drive the clickable
  *Transient Execution Lab* simulator (your instructor provides the `.html`).
- **`native/`** — *bonus:* real Flush+Reload in C on actual silicon (Linux/x86-64, needs `gcc`).

## Ground rules
These notebooks are a **model**, not a weapon, and the `native/` code only ever reads cache
lines of its own arrays. Only ever test systems you are **authorised** to test.
MD

echo "==> safety check: no runnable solution code, no saved outputs"
if ! "$PY" -c "import nbformat" >/dev/null 2>&1; then
    echo "    (skipped: nbformat not installed in '$PY' — run inside the lab venv to enable this check)"
else
"$PY" - "$PKG" <<'PYEOF'
import sys, glob, nbformat
pkg = sys.argv[1]
SIGS = ["cache.touch(mem.read(idx))", "round(t / quantum) * quantum", "self.hidden[line"]
bad = False
outputs = 0
for nb in sorted(glob.glob(pkg + "/*.ipynb")):
    cells = nbformat.read(nb, 4).cells
    runnable = "\n".join(
        l for c in cells if c.cell_type == "code"
        for l in c.source.split("\n")
        if l.strip() and not l.strip().startswith("#"))
    outputs += sum(len(c.get("outputs", [])) for c in cells if c.cell_type == "code")
    if any(s in runnable for s in SIGS):
        print("   !! LEAK:", nb); bad = True
if outputs:
    print(f"   !! {outputs} saved cell outputs present"); bad = True
sys.exit(1 if bad else 0)
PYEOF
echo "    clean: no solution code, no outputs"
fi

echo "==> zipping"
rm -f "$OUT"
( cd "$STAGE" && zip -rq "$OUT" microarch_lab )
echo ""
echo "Built: $OUT ($(du -h "$OUT" | cut -f1))"
echo "Contents:"
unzip -l "$OUT" | awk 'NR>3 && $4!="" {print "   " $4}'
