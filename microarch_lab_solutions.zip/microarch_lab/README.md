# Microarchitectural Side-Channel Attacks — Hands-On Lab

A half-day, build-it-yourself companion to the Part A lecture (Flush+Reload, Spectre, Meltdown).
Participants **write the attacks from scratch** and watch the defences stop them.

Everything in the core labs runs against a **deterministic model** of a CPU cache
(`uarch_lib.py`), so it behaves identically on **Windows, macOS and Linux** with no special
hardware — *nothing depends on your real CPU speculating.* The real-hardware attacks are an
optional Linux/x86 bonus (`native/`) plus the instructor's GnuPG demo.

## What you build

| Lab | You build | Lecture link |
|-----|-----------|--------------|
| **00** Setup | check your machine's real Spectre/Meltdown status | slide 49 |
| **01** Cache timing & Flush+Reload | the timing **read-out** that recovers a byte | slides 15–16 |
| **02** Covert channel | send a message through the cache | slide 15 |
| **03** Spectre v1 | train the predictor, speculate past a bounds check, leak a secret — then **index masking** | slides 32–34, 43 |
| **04** Meltdown | forward a faulting load's byte, dump kernel memory — then **KPTI** | slides 25–26, 36 |
| **05** Defences | timer coarsening & partitioning; score which **ingredient** each defence breaks | slides 42, 47, 50 |

## Setup (any OS)

```bash
cd microarch_lab
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
jupyter notebook student/00_setup_and_your_machine.ipynb
```

Then work through `student/00 → 05` in order. Each notebook has **TODO** cells to complete and
self-checks that print `PASS`/`FAIL`. Stuck? The fully worked versions are in `solutions/`
(instructors: hand these out only after each lab).

> Each of `student/` and `solutions/` contains its own copy of `uarch_lib.py`, so you can run a
> notebook straight from its folder.

## Suggested half-day timing (~3 h + break)

| Time | Lab |
|------|-----|
| 0:00–0:15 | **00** Setup & check your machine |
| 0:15–0:55 | **01** Cache timing & Flush+Reload (★) |
| 0:55–1:25 | **02** Covert channel (★) |
| 1:25–1:40 | *break* |
| 1:40–2:25 | **03** Spectre v1 (★★★) — the centrepiece |
| 2:25–2:55 | **04** Meltdown (★★) |
| 2:55–3:25 | **05** Defences (★★★) |
| bonus | `native/` real Flush+Reload (Linux/x86) + instructor GnuPG demo |

## Files

```
microarch_lab/
├── README.md                 this file
├── requirements.txt          jupyter, matplotlib, numpy
├── uarch_lib.py              the deterministic cache/CPU model (the "hardware")
├── HTML_lab_worksheet.md     guided questions for the Transient Execution Lab (the clickable simulator)
├── INSTRUCTOR_GUIDE.md       timing, answers, teaching tips, exercise solutions
├── student/                  notebooks 00–05 with TODO stubs (+ uarch_lib.py)
├── solutions/                fully worked notebooks (+ uarch_lib.py)   ← instructors only
└── native/                   BONUS real Flush+Reload in C (Linux/x86): cache_timing, covert_channel
```

## How the day fits together

1. **Lecture Part A** (slides) — the ideas.
2. **The clickable simulator** (`SpectreMeltdown_live.html`) with `HTML_lab_worksheet.md` — *watch* one byte leak and toggle the mitigations.
3. **These notebooks** — *build* the attacks yourself against the model.
4. **`native/` + GnuPG demo** — *run* the real thing on real silicon.

Observe → build → run. Nothing here is a weapon: the notebooks are a model, and the native
code only ever reads cache lines of its own arrays. Attack only systems you are authorised to test.
