# Instructor Guide — Microarchitectural Hands-On

## Before the session
- Have participants install Python + `requirements.txt` **ahead of time** (works on any OS).
- You (instructor) pre-build the `native/` programs and the `flush-reload-demo/` capstone on a
  known-good Intel/Linux machine (see their READMEs).
- Decide the GnuPG capstone is **your demo**, not a participant task (it needs specific hardware).

## The model (what to say up front)
`uarch_lib.py` is a **deterministic teaching model**, not an exploit. There is no real
speculation; the `Cache` just records which line is "warm" and returns a fast/slow time. This is
deliberate: it makes the *logic* of each attack visible and reproducible on every laptop, and it
sidesteps the "modern CPUs fixed Meltdown, so a real PoC won't leak" problem. The real silicon
behaviour is the `native/` bonus and your GnuPG demo.

## Pacing
Follow the table in `README.md`. Lab 3 (Spectre) is the centrepiece — give it the most time.
Labs 1–2 are quick wins that build the shared `fr_recover`. Lab 5 is discussion-heavy; leave
time for the "which ingredient?" conversation.

## Self-checks
Each notebook prints `PASS`/`FAIL` via `U.check(...)`. A completed Lab 1 must recover `'S'`;
Lab 2 `HELLO uarch`; Lab 3 `TOP-SECRET!`; Lab 4 `r00t:x:0:0:MELTDOWN`. If a participant's check
fails, the bug is in the one function they just wrote — point them back to it.

## Key solution logic (for reference)
- **Lab 1 `fr_recover`:** reload all lines; count lines whose latency `< threshold`; return the
  most-voted (or −1). Voting matters only with noise/rounds.
- **Lab 3 `spectre_victim`:** if `size_cached`, behave correctly (only read when `x < size`);
  else if `pred.predicts_taken()`, speculatively `cache.touch(mem.read(idx))` — with the mask,
  clamp `idx = x if x < size else 0`. Always resolve + train the predictor afterwards. The
  training calls (in-bounds, `size_cached=True`) are what push the predictor to "taken".
- **Lab 4 `meltdown_leak`:** `if kpti: return` (nothing to forward) else `cache.touch(kmem.read(addr))`.
- **Lab 5 `coarsen`:** `round(t/quantum)*quantum`. q=512 defeats (hit & miss both → 0); q=128
  leaks again (gap re-opens). `PartitionedCache.victim_touch`: write to `self.hidden`, not
  `self.present`, so `reload_all` never sees it.

## Worksheet answers (HTML simulator)
1. The counter climbs toward **Strongly in**; the attacker wants a confident "in-bounds"
   prediction so the CPU speculates into the body on the malicious call.
2. Flushing `array1_size` makes the bounds comparison wait ~hundreds of cycles for DRAM — that
   stall is the **speculation window**; without it the check resolves before the loads complete.
3. The **secret byte value** decides the index (`probe[secret]`). It's the one byte being leaked.
4. Registers / the reorder-buffer entries roll back (squashed); the **warm probe line does not**.
   That surviving footprint is the leak.
5. One line reloads far faster (below the threshold) — its **index is the byte**.
6. With lfence the dependent load is **blocked** until the branch resolves; no transient load
   issues, no probe line warms, the timing chart has no dip, Attacker's view stays empty.
7. Noise warms stray lines; repeating and taking a majority vote recovers the true line.
8. Meltdown reads a kernel address **directly** in the attacker's own code; it relies on the
   fault being late (raised at retirement), not on mistraining a victim's branch.
9. The permission (U/S) check hasn't resolved, yet the loaded byte is already **forwarded** to
   dependent instructions — data beats the check. That race *is* Meltdown.
10. A **page fault (#PF)** is raised at retirement; the dependent instructions are squashed; the
    **cache line survives**.
11. KPTI unmaps the kernel, so the load finds **no data to forward** → ingredient 1 removed → no
    footprint. (Computation/data-side fix.)
12. Both end in the same cache read-out; they differ in how the transient window opens —
    **mispredicted conditional branch** (Spectre) vs **faulting load** (Meltdown).
13. lfence & KPTI both remove **ingredient 1** (transient access) → computation-side, robust.

## Notebook exercise notes
- **1.2 / 2.1 noise:** one round can pick a stray warm line; voting over rounds fixes it.
- **3.1:** any secret leaks — the attack doesn't depend on its content.
- **3.2 masking:** the clamp is *arithmetic*, correct even on the speculative path — a branch can
  be mispredicted, arithmetic can't.
- **5.1:** the smallest defeating quantum is roughly the **hit/miss gap** (`MISS−HIT`); below it,
  hit and miss round to different buckets and the leak returns.
- **5.2:** partitioning and timer coarsening are **channel-side** — an attacker can defeat them
  (eviction sets, a counting-thread clock) without touching the victim; masking/KPTI can't be.

## If you fall behind
Drop Lab 2 (covert channel) to discussion, or run Lab 5's partitioning part as a demo. Keep
Labs 1, 3, 4 — they are the core (read-out, Spectre, Meltdown).
