/*
 * covert_channel.c  —  BONUS (real hardware): a real Flush+Reload covert channel.
 *
 * The REAL version of Lab 2. A "sender" transmits a secret message to a "receiver"
 * with no files, no pipes, no network — only through the CPU cache. The receiver uses
 * Flush+Reload timing to read it back.
 *
 * Design: a robust BIT-SERIAL channel. Two cache lines, ONE and ZERO, far apart in memory.
 * To send a 1-bit the sender warms ONE; to send a 0-bit it warms ZERO. The receiver flushes
 * both, lets the sender transmit, times both, and the faster line is the bit. It votes over
 * several rounds. Timing only two far-apart lines keeps the hardware prefetcher out of the
 * way (a 256-line scan would fight it — see cache_timing.c for the raw hit/miss signal).
 *
 * Linux + x86-64 only. No root.
 *   gcc -O2 -o covert_channel covert_channel.c && ./covert_channel
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <sched.h>
#include <x86intrin.h>

#define ROUNDS 31
/* two probe lines, 1 MiB apart (different pages and cache sets) */
static uint8_t arena[2 * 1024 * 1024 + 4096];
static volatile uint8_t *ONE  = &arena[0];
static volatile uint8_t *ZERO = &arena[1024 * 1024 + 64];

static inline uint64_t timed(volatile uint8_t *p) {
    unsigned aux;
    _mm_mfence(); _mm_lfence();
    uint64_t t0 = __rdtscp(&aux);
    _mm_lfence();
    (void)*p;
    _mm_lfence();
    return __rdtscp(&aux) - t0;
}

static void send_bit(int bit) {                 /* sender: warm the line for this bit */
    volatile uint8_t *p = bit ? ONE : ZERO;
    (void)*p; _mm_mfence();
}

static int recv_bit(void) {                     /* receiver: vote over ROUNDS */
    int one_fast = 0, zero_fast = 0;
    for (int r = 0; r < ROUNDS; r++) {
        _mm_clflush((void *)ONE); _mm_clflush((void *)ZERO); _mm_mfence();
        /* ---- the sender transmits here (same bit) ---- */
        extern int CURRENT_BIT; send_bit(CURRENT_BIT);
        /* ---- receiver times both lines ---- */
        uint64_t t1 = timed(ONE), t0 = timed(ZERO);
        if (t1 < t0) one_fast++; else zero_fast++;
    }
    return one_fast > zero_fast;
}

int CURRENT_BIT;                                 /* the bit the sender is currently sending */

static uint8_t recv_byte(const char *bits_source, int idx) {
    uint8_t v = 0;
    for (int b = 7; b >= 0; b--) {               /* MSB first */
        CURRENT_BIT = (bits_source[idx] >> b) & 1;
        v = (v << 1) | recv_bit();
    }
    return v;
}

int main(void) {
    cpu_set_t set; CPU_ZERO(&set); CPU_SET(0, &set);     /* pin to core 0: steadier timing */
    sched_setaffinity(0, sizeof(set), &set);

    const char *secret = "cache!";
    char out[64] = {0};
    printf("Flush+Reload covert channel: transmitting \"%s\" bit by bit (vote over %d rounds)\n\n",
           secret, ROUNDS);
    for (size_t i = 0; secret[i]; i++)
        out[i] = (char)recv_byte(secret, (int)i);

    printf("received: \"%s\"\n", out);
    printf("%s\n", strcmp(out, secret) == 0
           ? "MATCH: the message crossed the cache with no file / pipe / socket."
           : "mismatch (very noisy machine: raise ROUNDS, or pin with taskset -c 0).");
    return 0;
}
