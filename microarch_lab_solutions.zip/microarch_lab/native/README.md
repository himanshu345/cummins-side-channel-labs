# Bonus — Real Flush+Reload on your own hardware (Linux / x86-64)

The Python notebooks run against a *model* so they work on any laptop. These two tiny C
programs run the **real** thing on actual silicon, using the `rdtsc` cycle counter and the
`clflush` instruction. They are the hardware proof behind Labs 1 and 2.

> **Requirements:** Linux on an **Intel/AMD x86-64** CPU, `gcc`. No root. Won't work on Apple
> Silicon / ARM (no `clflush`), and may not work inside a VM that emulates `rdtsc`.

```bash
gcc -O2 -o cache_timing   cache_timing.c
gcc -O2 -o covert_channel covert_channel.c
./cache_timing
./covert_channel
```

### 1. `cache_timing` — see the hit/miss gap on *your* CPU
Times a cached load vs a flushed load 200,000 times and prints a histogram. You should see
**two separated clusters** — a fast "hit" peak (~tens of cycles) and a slow "miss" peak
(~200–300 cycles). That gap is the entire side channel. If the two peaks overlap (e.g. inside
a trapping VM), Flush+Reload can't work on that machine — which is itself the lecture's point
about bare metal.

This is the real version of **Lab 1**: the model's `HIT_CYCLES`/`MISS_CYCLES` are made-up;
here you measure your own.

### 2. `covert_channel` — send data through the cache, no files or sockets
A sender and receiver (in one process) pass a secret string **only by warming cache lines**.
The receiver recovers it with Flush+Reload timing and votes over several rounds. It pins
itself to one core for steady timing; if you still get a mismatch on a busy/throttled laptop,
run it pinned and quiet:

```bash
taskset -c 0 ./covert_channel
```

This is the real version of **Lab 2**: cache timing genuinely carries data between programs.

### Why only two lines (not 256)?
`covert_channel` sends one **bit** at a time over two far-apart lines, instead of timing a
256-line probe array. On a fast modern CPU a full 256-line scan fights the hardware
**prefetcher** (cold lines read warm), which is exactly the kind of engineering noise the
GnuPG write-up documents. Two far-apart lines keep the prefetcher out of the way, so the demo
is robust on any machine. `cache_timing` already shows the raw 256-value signal quality.

---

## The capstone (instructor demo): a real RSA key from GnuPG

The full real attack — recovering an actual RSA private key from GnuPG 1.4.13 by Flush+Reload —
is the separate `flush-reload-demo/` kit (run `./run.sh`). It needs an Intel CPU with
Hyper-Threading on bare metal. Run it as the instructor demo after the Spectre/Meltdown labs;
it ties the whole day together: *the same timing channel, against real crypto software.*
