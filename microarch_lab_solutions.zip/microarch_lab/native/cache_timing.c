/*
 * cache_timing.c  —  BONUS (real hardware): measure your CPU's cache hit vs miss time.
 *
 * This is the REAL version of Lab 1's premise: it uses rdtsc (cycle counter) and
 * clflush (cache-line flush) to time a load that is cached vs one that was just flushed.
 * It prints a histogram so you can see the two peaks and pick YOUR machine's threshold.
 *
 * Linux + x86-64 only (needs clflush / rdtsc). No root, no special privileges.
 *   gcc -O2 -o cache_timing cache_timing.c && ./cache_timing
 *
 * If the two peaks overlap (e.g. inside a VM that emulates rdtsc), Flush+Reload
 * cannot work on that machine — exactly the point made in the lecture.
 */
#include <stdio.h>
#include <stdint.h>
#include <x86intrin.h>   /* __rdtscp, _mm_clflush, _mm_mfence */

#define N 200000

static inline uint64_t time_load(volatile char *p) {
    unsigned aux;
    uint64_t t0 = __rdtscp(&aux);
    (void)*p;                      /* the load we are timing */
    uint64_t t1 = __rdtscp(&aux);
    return t1 - t0;
}

int main(void) {
    char buf[4096];
    volatile char *p = &buf[64];
    uint64_t hit_hist[64] = {0}, miss_hist[64] = {0};
    uint64_t hit_sum = 0, miss_sum = 0;

    for (int i = 0; i < N; i++) {
        /* HIT: make sure the line is cached, then time it */
        (void)*p; _mm_mfence();
        uint64_t h = time_load(p);
        hit_sum += h; hit_hist[h < 64*10 ? h/10 : 63]++;

        /* MISS: flush the line, then time it */
        _mm_clflush((void *)p); _mm_mfence();
        uint64_t m = time_load(p);
        miss_sum += m; miss_hist[m < 64*10 ? m/10 : 63]++;
    }

    printf("Measured over %d iterations on this CPU:\n", N);
    printf("  average HIT  (cached)  : %3llu cycles\n", (unsigned long long)(hit_sum / N));
    printf("  average MISS (flushed) : %3llu cycles\n", (unsigned long long)(miss_sum / N));
    uint64_t th = (hit_sum / N + miss_sum / N) / 2;
    printf("  -> a good THRESHOLD here is about %llu cycles\n\n", (unsigned long long)th);

    printf("histogram (each row = a 10-cycle bucket; H=hit column, M=miss column)\n");
    for (int b = 0; b < 40; b++) {
        if (!hit_hist[b] && !miss_hist[b]) continue;
        printf("%4d cyc | ", b*10);
        for (uint64_t k = 0; k < hit_hist[b] / (N/200 + 1); k++) putchar('H');
        for (uint64_t k = 0; k < miss_hist[b] / (N/200 + 1); k++) putchar('M');
        putchar('\n');
    }
    printf("\nTwo separated clusters => Flush+Reload works here. Overlapping => it does not.\n");
    return 0;
}
