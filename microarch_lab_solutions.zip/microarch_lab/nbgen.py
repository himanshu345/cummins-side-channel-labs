"""Generate the Microarchitectural Attacks hands-on notebooks, in two versions:
  - student/   : key functions are TODO stubs to complete
  - solutions/ : fully worked (used to self-check and for instructors)
Run:  python nbgen.py
"""
import os, re, nbformat as nbf

HERE = os.path.dirname(os.path.abspath(__file__))
STUD = os.path.join(HERE, "student")
SOLN = os.path.join(HERE, "solutions")
for d in (STUD, SOLN):
    os.makedirs(d, exist_ok=True)

# A code cell may carry a student stub. Use the markers below inside `sol`:
#   ###TODO
#   <stub lines shown to the student>
#   ###SOLUTION
#   <worked lines, replace the stub in the solutions version>
#   ###END
# Lines outside any marker appear in BOTH versions.
def split_versions(src: str):
    stu, sol, mode = [], [], "both"
    for line in src.split("\n"):
        s = line.strip()
        if s == "###TODO": mode = "stub"; continue
        if s == "###SOLUTION": mode = "soln"; continue
        if s == "###END": mode = "both"; continue
        if mode == "both": stu.append(line); sol.append(line)
        elif mode == "stub": stu.append(line)
        elif mode == "soln": sol.append(line)
    return "\n".join(stu).strip("\n"), "\n".join(sol).strip("\n")

CELLS = []  # (kind, payload) kind in {md, code}
def md(t): CELLS.append(("md", t.strip("\n")))
def code(t): CELLS.append(("code", t.strip("\n")))

def build(title):
    stu_cells, sol_cells = [], []
    for kind, payload in CELLS:
        if kind == "md":
            stu_cells.append(nbf.v4.new_markdown_cell(payload))
            sol_cells.append(nbf.v4.new_markdown_cell(payload))
        else:
            st, so = split_versions(payload)
            stu_cells.append(nbf.v4.new_code_cell(st))
            sol_cells.append(nbf.v4.new_code_cell(so))
    for cells, folder in ((stu_cells, STUD), (sol_cells, SOLN)):
        nb = nbf.v4.new_notebook(cells=cells)
        nb.metadata = {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                       "language_info": {"name": "python"}}
        with open(os.path.join(folder, title), "w") as f:
            nbf.write(nb, f)
    CELLS.clear()

HEAD = "import uarch_lib as U\nfrom uarch_lib import Cache, Predictor, VictimMemory, KernelMemory, bytes_to_text, score, latency_plot"

# ================================================================= 00 SETUP
md("""# Lab 0 — Setup & Check Your Own Machine

**Microarchitectural Side-Channel Attacks — hands-on.**

These labs let you build Flush+Reload, Spectre v1 and Meltdown **from scratch** and watch
the defences stop them. Everything runs against a small **deterministic model** of a CPU
cache in `uarch_lib.py`, so it behaves identically on Windows, macOS and Linux — *nothing
here depends on your real CPU speculating.* (The real-hardware versions are the optional
`native/` bonus and the instructor demos.)

**The whole course in one idea:** an attack needs three ingredients —
1. **transient execution** that touches a secret,
2. a **covert channel** (one cache line goes warm, chosen by the secret),
3. a **timing read-out** (Flush+Reload) that recovers it.

You will build each one. Run every cell top to bottom.""")

code(f"""{HEAD}
# sanity check: the model's cache tells hit from miss
c = Cache()
c.flush_all()                 # all 256 lines cold
c.touch(42)                   # a load warms line 42
print("cold line  0 :", round(c.time_load(0)),  "cycles  (miss)")
print("warm line 42 :", round(c.time_load(42)), "cycles  (hit)")
print("hit/miss threshold the labs use:", U.DEFAULT_THRESHOLD, "cycles")""")

md("""### Check your *real* machine's Spectre/Meltdown status

This part reads the Linux kernel's own verdict. On Windows/macOS it just says so — that's fine,
it's informational only.""")

code("""import platform, glob
print("OS:", platform.system(), platform.release(), "| CPU:", platform.machine())
vulns = sorted(glob.glob("/sys/devices/system/cpu/vulnerabilities/*"))
if vulns:
    for p in vulns:
        name = p.rsplit("/", 1)[-1]
        if name in ("meltdown", "spectre_v1", "spectre_v2"):
            print(f"  {name:12s}: {open(p).read().strip()}")
else:
    print("  (no /sys vulnerabilities file — not Linux, or not exposed. Informational only.)")""")

md("""**Read your result** (slide 49 of the lecture):
- `meltdown: Not affected` → fixed in silicon on modern Intel; KPTI is off.
- `spectre_v1: Mitigation: ...` → no hardware fix; software hardening (masking, barriers).
- `spectre_v2: Mitigation: ...` → hardware (eIBRS) + software (IBPB, retpoline).

On to the attacks. ➡️ open **Lab 1**.""")
build("00_setup_and_your_machine.ipynb")

# ================================================================= 01 FLUSH+RELOAD
md("""# Lab 1 — The Cache Timing Side Channel & Flush+Reload

**Goal:** build the *read-out* — recover a secret byte from nothing but timing.

The cache has 256 lines, one per possible byte value. A warm line reloads fast (a **hit**),
a cold line slow (a **miss**). If some code touched `probe[secret]`, then **line `secret`
is the one warm line** — and Flush+Reload finds it by timing every line.""")

code(f"""{HEAD}
cache = Cache()
cache.flush_all()                       # 1. FLUSH: all lines cold
secret_byte = ord('S')                  # (pretend) transient code touched probe[secret]
cache.touch(secret_byte)                # 2. one line is warmed, chosen by the secret
lat = cache.reload_all(shuffle=True)    # 3. RELOAD: time every line
fig = latency_plot(lat, highlight=secret_byte, title="One warm line among 256")
fig  # look for the single dip""")

md("""### Your turn: write the read-out `fr_recover`

Given the 256 latencies, decide **which line is the warm one**: the line whose reload time
is *below the hit threshold*. Return its index (that's the secret byte), or `-1` if none.""")

code("""def fr_recover(cache, threshold=U.DEFAULT_THRESHOLD, rounds=1, noise=False):
    \"\"\"Flush+Reload read-out. Reload all lines; the fast one names the secret.
    With noise, repeat `rounds` times and take the most-voted line.\"\"\"
    votes = [0] * U.LINES
    ###TODO
    # 1. repeat `rounds` times: lat = cache.reload_all(noise=noise)
    # 2. for each line i, if lat[i] < threshold -> votes[i] += 1
    # 3. return the line with the most votes (or -1 if nobody was ever fast)
    raise NotImplementedError("write fr_recover")
    ###SOLUTION
    for _ in range(rounds):
        lat = cache.reload_all(noise=noise)
        for i, t in enumerate(lat):
            if t < threshold:
                votes[i] += 1
    best = max(range(U.LINES), key=lambda i: votes[i])
    return best if votes[best] > 0 else -1
    ###END""")

code("""# self-check: recover the planted byte
got = fr_recover(cache)
U.check("recovered byte", chr(got) if got >= 0 else None, 'S')""")

md("""### Exercise 1.1
Plant a different byte (e.g. `ord('K')`), flush, touch, and recover it with your function.

### Exercise 1.2
Turn on noise and rounds and see voting work:
```python
cache.flush_all(); cache.touch(ord('K'))
print(chr(fr_recover(cache, rounds=9, noise=True)))
```
Why does a single noisy round sometimes fail? (Hint: stray warm lines.)

Keep `fr_recover` — every later lab uses it.""")
build("01_cache_timing_and_flush_reload.ipynb")

# ================================================================= 02 COVERT CHANNEL
md("""# Lab 2 — A Flush+Reload Covert Channel

Two cooperating programs can **secretly send data through the cache** — no network, no files.
The *sender* warms the line numbered by the byte it wants to send; the *receiver* times the
lines and reads it back. This proves cache timing really carries information. It uses only the
read-out from Lab 1.""")

code(f"""{HEAD}
# paste (or re-import) your fr_recover from Lab 1:
def fr_recover(cache, threshold=U.DEFAULT_THRESHOLD, rounds=1, noise=False):
    votes=[0]*U.LINES
    for _ in range(rounds):
        lat=cache.reload_all(noise=noise)
        for i,t in enumerate(lat):
            if t<threshold: votes[i]+=1
    b=max(range(U.LINES),key=lambda i:votes[i]); return b if votes[b]>0 else -1""")

md("""### Your turn: the two endpoints""")
code("""def send_byte(cache, value):
    \"\"\"Sender: transmit one byte through the cache.\"\"\"
    ###TODO
    # flush all lines, then touch the one line numbered by `value`
    raise NotImplementedError
    ###SOLUTION
    cache.flush_all()
    cache.touch(value)
    ###END

def recv_byte(cache):
    \"\"\"Receiver: read one byte back.\"\"\"
    ###TODO
    # use fr_recover to find the warm line
    raise NotImplementedError
    ###SOLUTION
    return fr_recover(cache)
    ###END""")

code("""# transmit a whole message, byte by byte, through the shared cache
chan = Cache()
message = b"HELLO uarch"
out = bytearray()
for b in message:
    send_byte(chan, b)
    out.append(recv_byte(chan))
print("received:", bytes_to_text(out))
U.check("covert channel", bytes(out), message)""")

md("""### Exercise 2.1 — noisy channel
Make the receiver robust: call `fr_recover(chan, rounds=9, noise=True)` and send the message
over a noisy channel. Measure the byte error rate. This is why real attacks **repeat and vote**.

### Exercise 2.2 — bandwidth
The real Meltdown paper reached ~500 KB/s. What limits *this* channel's rate?
(One cache round per byte; 256 timed loads per round.)""")
build("02_covert_channel.ipynb")

# ================================================================= 03 SPECTRE
md("""# Lab 3 — Spectre v1: Make the Victim Leak Its Own Secret

Now a real transient-execution attack. The victim has a **correct** bounds check:

```c
if (x < array1_size)              // x is attacker-controlled
    y = probe[array1[x] * 4096];  // only runs if x is in bounds
```

`array1[x]` reads the byte **x steps past the start of array1**. A huge, *out-of-bounds* `x`
reaches the **secret** sitting further along in memory. The check forbids that — but if the
branch predictor is **trained** to expect "in bounds" and the bound is **slow to load**, the CPU
**speculates** into the body with the bad `x`, reads the secret, and warms a probe line before
the check resolves and squashes everything. The footprint survives → Flush+Reload reads it.""")

code(f"""{HEAD}
def fr_recover(cache, threshold=U.DEFAULT_THRESHOLD, rounds=1, noise=False):
    votes=[0]*U.LINES
    for _ in range(rounds):
        lat=cache.reload_all(noise=noise)
        for i,t in enumerate(lat):
            if t<threshold: votes[i]+=1
    b=max(range(U.LINES),key=lambda i:votes[i]); return b if votes[b]>0 else -1

mem = VictimMemory(secret=b"TOP-SECRET!")
print("array1_size (in-bounds indices 0..%d)" % (mem.array1_size-1))
print("the secret sits at out-of-bounds index x =", mem.secret_offset, "onward")
print("so array1[%d] == secret[0] ==" % mem.secret_offset, repr(chr(mem.read(mem.secret_offset))))""")

md("""### Your turn: model the victim gadget (the transient step)

Complete `spectre_victim`. Two situations:
- `size_cached=True`: the bounds check resolves **instantly** → behave correctly (only read if in bounds). No speculation.
- `size_cached=False`: the bound is **flushed** (slow) → the CPU follows the **predictor**. If it predicts "taken/in-bounds", it **speculatively** reads `array1[x]` and touches that probe line — *even if x is out of bounds*.

Either way the branch eventually resolves and **trains the predictor** (taken if in bounds, not-taken if not).""")

code("""def spectre_victim(x, mem, pred, cache, size_cached, mask=False):
    ###TODO
    # if size_cached:
    #     if x < mem.array1_size: cache.touch(mem.read(x))   # correct, non-speculative
    # elif pred.predicts_taken():                            # bound slow -> speculate
    #     idx = x
    #     # (Exercise 3.2) if mask: clamp idx to 0 when x is out of bounds
    #     cache.touch(mem.read(idx))                          # TRANSIENT touch
    # then resolve + train: pred.train_taken() if x<size else pred.train_not_taken()
    raise NotImplementedError
    ###SOLUTION
    if size_cached:
        if x < mem.array1_size:
            cache.touch(mem.read(x))
    elif pred.predicts_taken():
        idx = x
        if mask:
            idx = x if x < mem.array1_size else 0
        cache.touch(mem.read(idx))
    if x < mem.array1_size:
        pred.train_taken()
    else:
        pred.train_not_taken()
    ###END""")

code("""def run_spectre(mask=False):
    pred, cache = Predictor(), Cache()
    for _ in range(6):                                   # 1. TRAIN with in-bounds calls
        spectre_victim(0, mem, pred, cache, size_cached=True)
    recovered = bytearray()
    for k in range(len(mem.secret)):                     # leak the secret byte by byte
        x = mem.secret_offset + k
        cache.flush_all()                                # 2. FLUSH probe lines
        spectre_victim(x, mem, pred, cache, size_cached=False, mask=mask)  # 3. ATTACK (bound slow)
        recovered.append(max(0, fr_recover(cache)))      # 4. RELOAD
        for _ in range(2):                               # keep the predictor trained
            spectre_victim(0, mem, pred, cache, size_cached=True)
    return bytes(recovered)

leaked = run_spectre(mask=False)
print("leaked:", bytes_to_text(leaked), score(leaked, mem.secret))
U.check("Spectre v1 leak", leaked, mem.secret)""")

md("""### Exercise 3.1
Change the secret in `VictimMemory(secret=b"...")` and re-run. Does it still leak?

### Exercise 3.2 — the index-masking defence (slide 43)
In `spectre_victim`, the `mask=True` path should **clamp an out-of-bounds index to 0**
(`idx = x if x < size else 0`) using *arithmetic*, not a branch. Implement it, then run:
```python
fixed = run_spectre(mask=True)
print(bytes_to_text(fixed), "  <- should NOT be the secret")
```
Why does the clamp hold even on the speculative path? (A branch can be mispredicted; arithmetic can't.)""")
build("03_spectre_v1.ipynb")

# ================================================================= 04 MELTDOWN
md("""# Lab 4 — Meltdown: Read Kernel Memory from User Space

Meltdown doesn't need a victim. The attacker's **own** code reads a forbidden kernel address:

```asm
mov  al, [kernel_addr]      ; illegal — but the byte is forwarded before the fault
shl  rax, 12                ; secret * 4096
mov  rbx, [probe + rax]     ; touch probe[secret]
; #PF is only delivered here, at retirement
```

On affected CPUs the loaded byte is **forwarded to dependent instructions before the
permission check is enforced**. Those run transiently, warm `probe[secret]`, and *then* the
page fault squashes everything — but the cache line survives. **KPTI** unmaps the kernel so
there is no data to forward.""")

code(f"""{HEAD}
def fr_recover(cache, threshold=U.DEFAULT_THRESHOLD, rounds=1, noise=False):
    votes=[0]*U.LINES
    for _ in range(rounds):
        lat=cache.reload_all(noise=noise)
        for i,t in enumerate(lat):
            if t<threshold: votes[i]+=1
    b=max(range(U.LINES),key=lambda i:votes[i]); return b if votes[b]>0 else -1

kmem = KernelMemory()   # holds b"r00t:x:0:0:MELTDOWN"
print("kernel secret length:", len(kmem.secret), "bytes")""")

md("""### Your turn: the Meltdown transient read""")
code("""def meltdown_leak(addr, kmem, cache, kpti=False):
    \"\"\"Leak one kernel byte at `addr` into the cache footprint.\"\"\"
    cache.flush_all()
    ###TODO
    # if kpti: the kernel is unmapped -> there is NO data to forward -> return (touch nothing)
    # else:    the byte is forwarded transiently -> cache.touch(kmem.read(addr))
    raise NotImplementedError
    ###SOLUTION
    if kpti:
        return
    cache.touch(kmem.read(addr))
    ###END""")

code("""def run_meltdown(kpti=False):
    cache = Cache(); out = bytearray()
    for addr in range(len(kmem.secret)):
        meltdown_leak(addr, kmem, cache, kpti=kpti)
        out.append(max(0, fr_recover(cache)))
    return bytes(out)

dumped = run_meltdown(kpti=False)
print("dumped kernel memory:", bytes_to_text(dumped), score(dumped, kmem.secret))
U.check("Meltdown leak", dumped, kmem.secret)""")

md("""### Exercise 4.1 — turn on KPTI
```python
print(bytes_to_text(run_meltdown(kpti=True)), " <- kernel unmapped: nothing leaks")
```
Explain, in one line, *why* nothing leaks with KPTI — in terms of the three ingredients.

### Exercise 4.2
Meltdown is fixed in silicon on modern CPUs (your Lab 0 output probably said *Not affected*).
What does that mean for whether this model reflects your real laptop? (It's a *model* of the
2018 behaviour — the mechanism, not your silicon.)""")
build("04_meltdown.ipynb")

# ================================================================= 05 DEFENSES
md("""# Lab 5 — Defences: Which Ingredient Does Each One Break?

Every attack needs all three ingredients, so **any single break stops the leak** — but some
breaks are robust and some are fragile. You've already built two:
- **Index masking** (Lab 3) — breaks ingredient **1** (transient access), at the source. Robust.
- **KPTI** (Lab 4) — breaks ingredient **1** (no data to forward). Robust.

Here you add the **channel-side** defences and see why they're weaker.""")

code(f"""{HEAD}
def fr_recover(cache, threshold=U.DEFAULT_THRESHOLD, rounds=1, noise=False):
    votes=[0]*U.LINES
    for _ in range(rounds):
        lat=cache.reload_all(noise=noise)
        for i,t in enumerate(lat):
            if t<threshold: votes[i]+=1
    b=max(range(U.LINES),key=lambda i:votes[i]); return b if votes[b]>0 else -1""")

md("""### Ingredient 3 — timer coarsening (slide 47)

If the attacker can only measure time in coarse quanta, hit and miss may round to the **same**
value and become indistinguishable. But only while the quantum is **wider than the hit/miss gap**.""")

code("""def coarsen(lat, quantum):
    \"\"\"Round every latency to the nearest multiple of `quantum`.\"\"\"
    ###TODO
    # return a list where each t becomes round(t/quantum)*quantum
    raise NotImplementedError
    ###SOLUTION
    return [round(t / quantum) * quantum for t in lat]
    ###END

def still_leaks(lat, planted, threshold=U.DEFAULT_THRESHOLD):
    \"\"\"A leak works only if EXACTLY ONE line is identifiable as warm, and it's the right one.\"\"\"
    below = [i for i, t in enumerate(lat) if t < threshold]
    return below == [planted]

c = Cache(); c.flush_all(); c.touch(ord('X'))
lat = c.reload_all(shuffle=False)
print("fine timer   :", still_leaks(lat, ord('X')), "(leaks)")
print("quantum 512  :", still_leaks(coarsen(lat, 512), ord('X')), "(defeated)")
print("quantum 128  :", still_leaks(coarsen(lat, 128), ord('X')), "(leaks again! the gap re-opens)")""")

md("""### Ingredient 2 — cache partitioning

Give the victim its own partition the attacker can't observe. Model it: the victim's touch lands
in a *hidden* cache the attacker never times, so the attacker's probe grid stays cold.""")

code("""class PartitionedCache(Cache):
    \"\"\"Victim touches go to a hidden partition; the attacker only ever sees its own.\"\"\"
    def __init__(self):
        super().__init__()
        self.hidden = [False] * U.LINES
    def victim_touch(self, line):
        ###TODO
        # the victim's footprint must NOT be visible to the attacker's reload_all():
        # store it in self.hidden instead of self.present
        raise NotImplementedError
        ###SOLUTION
        self.hidden[line % U.LINES] = True
        ###END

pc = PartitionedCache(); pc.flush_all(); pc.victim_touch(ord('X'))
print("attacker recovers:", fr_recover(pc), "(-1 = nothing; the footprint is hidden)")""")

md("""### Put it together — the scorecard""")
code("""rows = [
    ("Index masking",    "1  transient access", "robust  — branchless, cheap"),
    ("lfence barrier",   "1  transient access", "robust  — but serialises the pipeline"),
    ("KPTI",             "1  data to forward",  "robust  — OS unmaps the kernel"),
    ("Cache partition",  "2  the channel",      "blunt   — hides footprint, wastes cache"),
    ("Timer coarsening", "3  the read-out",     "fragile — fails once a finer clock is built"),
]
print(f"{'defence':18s}{'breaks ingredient':22s}{'nature'}")
print("-"*70)
for d, ing, nat in rows:
    print(f"{d:18s}{ing:22s}{nat}")
print("\\nLesson: when you can, fix the COMPUTATION (ingredient 1). Hiding the channel is blunt or fragile.")""")

md("""### Exercise 5.1
At `quantum = 128` the leak returns. Find the **smallest** quantum that still defeats it, and
relate it to the hit/miss gap (`U.HIT_CYCLES` vs `U.MISS_CYCLES`).

### Exercise 5.2
Of masking, KPTI, partitioning and timer coarsening — which could an attacker **defeat without
touching the victim**, just by working harder (a finer clock, eviction sets)? That's the
difference between *computation-side* and *channel-side* defences.

### 🎉 Done — you've built Flush+Reload, a covert channel, Spectre, Meltdown, and five defences.
Next: the optional **`native/`** bonus runs a *real* Flush+Reload on Linux/x86, and the instructor
demo recovers a *real* RSA key from GnuPG.""")
build("05_defenses.ipynb")

import shutil
for d in (STUD, SOLN): shutil.copy(os.path.join(HERE,"uarch_lib.py"), d)
print("generated notebooks in", STUD, "and", SOLN)
print("student :", sorted(os.listdir(STUD)))
print("solutions:", sorted(os.listdir(SOLN)))
