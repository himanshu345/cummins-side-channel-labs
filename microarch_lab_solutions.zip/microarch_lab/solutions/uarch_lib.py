"""
uarch_lib.py — shared infrastructure for the Microarchitectural Attacks hands-on lab.

This is a DETERMINISTIC TEACHING MODEL of a CPU cache and the transient-execution
machinery, so the labs run identically on any laptop (Windows / macOS / Linux) with
no special hardware. It models the three ingredients of Spectre/Meltdown:

  1. a cache that keeps a FOOTPRINT (which 64-byte line is "warm"),
  2. transient execution that can touch a line chosen by a secret,
  3. a timing read-out (Flush+Reload) that recovers the secret from the footprint.

Nothing here depends on your CPU actually speculating. Students write the ATTACK
logic (Flush+Reload read-out, the Spectre/Meltdown transient step, the mitigations)
in the notebooks; this file only provides the cache, the memory, the predictor,
plotting and scoring — the "hardware" the attack runs against.
"""
from __future__ import annotations
import random

# ---- model constants (made-up but realistic cycle counts) -------------------
LINES = 256            # one cache line per possible byte value (0..255)
STRIDE = 4096          # bytes between probe lines: each value gets its own line
HIT_CYCLES = 60        # a cached line reloads fast
MISS_CYCLES = 250      # an uncached line comes from DRAM: slow
DEFAULT_THRESHOLD = (HIT_CYCLES + MISS_CYCLES) // 2   # 155: midway hit<->miss


class Cache:
    """A 256-line cache. The only observable is: how long does it take to read a line?
    present[i] == True  means line i is warm (a fast reload)."""

    def __init__(self):
        self.present = [False] * LINES

    def flush_all(self):
        """clflush every probe line -> all cold."""
        self.present = [False] * LINES

    def flush(self, line: int):
        self.present[line % LINES] = False

    def touch(self, line: int):
        """A memory load of this line brings it into the cache (it becomes warm)."""
        self.present[line % LINES] = True

    def time_load(self, line: int, noise: bool = False, rng: random.Random | None = None) -> float:
        """Time one reload of `line`, in cycles. Warm -> ~HIT, cold -> ~MISS."""
        r = rng or random
        base = HIT_CYCLES if self.present[line % LINES] else MISS_CYCLES
        jit = r.uniform(-8, 8)
        if noise:
            jit += r.uniform(-35, 35)              # a jittery clock
        return max(1.0, base + jit)

    def reload_all(self, noise: bool = False, shuffle: bool = True,
                   rng: random.Random | None = None) -> list[float]:
        """Reload all 256 lines (optionally in shuffled order, as a real attack does
        to defeat the prefetcher) and return the 256 latencies, indexed by line."""
        r = rng or random
        order = list(range(LINES))
        if shuffle:
            r.shuffle(order)
        lat = [0.0] * LINES
        for i in order:
            lat[i] = self.time_load(i, noise=noise, rng=r)
        return lat


class Predictor:
    """A 2-bit saturating branch-direction predictor for one branch.
    States 0..3; >=2 predicts 'taken / in bounds'. Learns from history."""

    def __init__(self):
        self.ctr = 0

    def train_taken(self, times: int = 1):
        for _ in range(times):
            self.ctr = min(3, self.ctr + 1)

    def train_not_taken(self, times: int = 1):
        for _ in range(times):
            self.ctr = max(0, self.ctr - 1)

    def predicts_taken(self) -> bool:
        return self.ctr >= 2

    @property
    def state_name(self) -> str:
        return ["Strongly not-taken", "Weakly not-taken",
                "Weakly taken", "Strongly taken"][self.ctr]


# ---- victim "memory" for Spectre --------------------------------------------
# A flat byte array. array1 occupies indices 0..len(public)-1 (the public, in-bounds
# region). The secret sits further along at a known OFFSET, so reading array1[offset+k]
# -- an OUT-OF-BOUNDS index -- reaches secret byte k. This is exactly the slide picture.
class VictimMemory:
    def __init__(self, public: bytes = bytes(range(16)), secret: bytes = b"TOP-SECRET!"):
        self.public = bytes(public)
        self.array1_size = len(self.public)
        self.secret = bytes(secret)
        gap = 48  # unrelated bytes between the array and the secret
        self.flat = self.public + bytes(gap) + self.secret
        self.secret_offset = len(self.public) + gap   # x that lands on secret[0]

    def read(self, x: int) -> int:
        """array1[x] = the byte x steps past the start of array1. Out-of-bounds x
        reaches the gap or the secret. Returns 0 past the end (unmapped)."""
        return self.flat[x] if 0 <= x < len(self.flat) else 0


# ---- "kernel" memory for Meltdown -------------------------------------------
class KernelMemory:
    def __init__(self, secret: bytes = b"r00t:x:0:0:MELTDOWN"):
        self.secret = bytes(secret)

    def read(self, addr: int) -> int:
        return self.secret[addr] if 0 <= addr < len(self.secret) else 0


# ---- scoring / display helpers ----------------------------------------------
def bytes_to_text(bs) -> str:
    return "".join(chr(b) if 32 <= b < 127 else "." for b in bs)


def score(recovered: bytes, truth: bytes) -> tuple[int, int]:
    """Return (correct, total) bytes."""
    n = min(len(recovered), len(truth))
    ok = sum(1 for i in range(n) if recovered[i] == truth[i])
    return ok, len(truth)


def latency_plot(lat, threshold=DEFAULT_THRESHOLD, highlight=None, title="Flush+Reload timing"):
    """Bar chart of the 256 reload latencies with the hit threshold drawn in."""
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(10, 3))
    colors = ["#C00000" if (highlight is not None and i == highlight) else "#1F5FA8"
              for i in range(len(lat))]
    ax.bar(range(len(lat)), lat, color=colors, width=1.0)
    ax.axhline(threshold, color="#2E7D32", ls="--", lw=1.5, label=f"hit threshold = {threshold}")
    ax.set_xlabel("probe line (byte value 0–255)")
    ax.set_ylabel("reload latency (cycles)")
    ax.set_title(title)
    ax.legend(loc="upper right")
    ax.set_xlim(-1, len(lat))
    fig.tight_layout()
    return fig


def check(label, got, want):
    """Tiny assert helper the notebooks use to self-grade a student's function."""
    ok = got == want
    print(f"[{'PASS' if ok else 'FAIL'}] {label}: got {got!r}" + ("" if ok else f", expected {want!r}"))
    return ok
