"""Cummins ASCA labs (script form of the notebook). Cells are marked with # %% (VS Code / Spyder / PyCharm run them one by one).
Plain run:  MPLBACKEND=Agg python this_file.py   (figures are then not shown)"""

# %% [markdown]
# # Cummins — Acoustic Side-Channel Attacks: all labs in one notebook
#
# Labs 0–7, ordered from easiest to hardest (≈ 3 h 15 min of work plus a 15-min break). **Run top to bottom**; the notebook is fully self-contained (no helper file) — each lab defines the helper functions it introduces just before using them, so the order matters.
#
# | Lab | Topic | Level | Time |
# |---|---|---|---|
# | 0 | Setup check | — | 10 min |
# | 1 | Phone numbers from keypad tones (DTMF) | ★ easiest — no training data | 25 min |
# | 2 | Signal and segmentation | ★★ | 30 min |
# | 3 | Features and classifier | ★★ | 35 min |
# | — | *break* | | 15 min |
# | 4 | Evaluation pitfalls | ★★★ | 20 min |
# | 5 | Apps and CPU emanations | ★★★ | 25 min |
# | 6 | Defences | ★★★ | 20 min |
# | 7 | Words → sentences (language decoding) | ★★★★ hardest | 30 min |
#
# Difficulty rises as you go: first a leak that needs no machine learning, then the keyboard attack step by step, then how to judge results, and last the hardest part. *Bonus Lab 8 (record your own keyboard) needs a microphone and stays in* `08_bonus_record_your_own.ipynb`.

# %% [markdown]
# ---
# ---
# <a id='lab0'></a>
# ## ▶ LAB 0  ·  `00_setup_check.ipynb` (setup)

# %% [markdown]
# # Lab 0 — Setup check (≈10 min)
# **Goal:** make sure everyone's environment works *before* the real labs begin.
#
# Run every cell. If all of them print ✅ you are ready. If not, raise your hand — don't debug alone for more than 3 minutes.

# %%
import sys, importlib
print("Python", sys.version.split()[0])
for m in ["numpy","scipy","sklearn","librosa","soundfile","matplotlib"]:
    try:
        mod = importlib.import_module(m); print("✅", m, getattr(mod, "__version__", ""))
    except Exception as e:
        print("❌", m, "->", e)

# %% [markdown]
# ### 0.0 Imports and shared settings
# Everything the labs need is defined **in this notebook** — no external helper file. Libraries and constants come first; each lab then defines the helper functions it introduces, right before using them.

# %%
# Libraries used throughout the labs
import os, glob, warnings
import numpy as np
import librosa
from scipy.signal import butter, sosfiltfilt, find_peaks
from scipy.stats import kurtosis
import csv
from scipy.signal import lfilter, periodogram
from sklearn.feature_selection import mutual_info_classif

warnings.filterwarnings('ignore')
# Folder that holds the audio data (works from lab/ or lab/solutions/)
DATA = next(p for p in ('data', '../data') if os.path.isdir(p))
SR = 22050            # all lab audio is resampled to this rate
LETTERS = list('abcdefghijklmnopqrstuvwxyz')

# %% [markdown]
# ### Helper functions for Lab 0
# Defined here, then used in the cells below.

# %%
def load(path, sr=SR):
    y, _ = librosa.load(path, sr=sr, mono=True)
    return y


def load_clips(sessions=(1, 2)):
    """Return (clips, letters, sessions) for the shipped keystroke-clip dataset."""
    clips, labels, sess = [], [], []
    for s in sessions:
        for p in sorted(glob.glob(os.path.join(DATA, "clips", f"session{s}", "*", "*.wav"))):
            clips.append(load(p)); labels.append(p.split(os.sep)[-2]); sess.append(s)
    return clips, np.array(labels), np.array(sess)

# %%
clips, letters, sessions = load_clips()
print(f"✅ dataset: {len(clips)} keystroke clips, {len(set(letters))} letters, sessions {sorted(set(sessions))}")
y = load(os.path.join(DATA, "sentences", "good-afternoon.wav"))
print(f"✅ sentence recording: {len(y)/SR:.1f} s @ {SR} Hz")

# %%
from IPython.display import Audio
Audio(y, rate=SR)   # you should hear someone typing 'good afternoon' on a phone

# %% [markdown]
# ## What are we working with?
# | Item | What it is |
# |---|---|
# | `data/sentences/good-afternoon.wav` | A real recording: *"good afternoon"* typed on a phone, captured by the phone's own microphone |
# | `data/clips/session1`, `session2` | ~650 short single-keystroke clips from two separate recording sessions, labelled by letter |
# | `data/lm_*.json` | A small English language model (Brown corpus) used later to turn letter guesses into words |
#
# > **Ethics reminder.** We attack **our own recordings** for learning. Do not record anyone's typing without their consent. We return to this in Lab 6.

# %% [markdown]
# ---
# ---
# <a id='lab1'></a>
# ## ▶ LAB 1  ·  `06_dtmf_keypad_tones.ipynb` (★ easiest)

# %% [markdown]
# # Lab 1 — Phone numbers from keypad tones (DTMF) (≈25 min)
# **A different kind of acoustic leak: no machine learning needed.**
#
# When you press a key on a phone keypad it plays a **DTMF tone** — the sum of one *low* and one *high* sine wave. The tone is designed to be machine-readable, so anyone who can record the call (or the room) can read the digits.
#
# | | 1209 Hz | 1336 Hz | 1477 Hz |
# |---|---|---|---|
# | **697 Hz** | 1 | 2 | 3 |
# | **770 Hz** | 4 | 5 | 6 |
# | **852 Hz** | 7 | 8 | 9 |
# | **941 Hz** | * | 0 | # |
#
# You will build the decoder in three steps — **measure 7 frequencies → classify each 40 ms frame → group frames into key presses** — and test it on 8 real recordings of dialled numbers (resampled to 8 kHz, the telephone rate).

# %% [markdown]
# ### Helper functions for Lab 1
# Defined here, then used in the cells below.

# %%
def add_noise(clip, snr_db, rng):
    """Add white noise to reach a given signal-to-noise ratio (dB)."""
    p = np.mean(clip ** 2) + 1e-12
    return clip + rng.normal(0, np.sqrt(p / 10 ** (snr_db / 10)), len(clip))


DTMF_LOW = [697, 770, 852, 941]


DTMF_HIGH = [1209, 1336, 1477]


DTMF_ALL = DTMF_LOW + DTMF_HIGH


DTMF_KEYS = {(697, 1209): "1", (697, 1336): "2", (697, 1477): "3", (770, 1209): "4", (770, 1336): "5", (770, 1477): "6",
             (852, 1209): "7", (852, 1336): "8", (852, 1477): "9", (941, 1209): "*", (941, 1336): "0", (941, 1477): "#"}


def frame_signal(y, sr, frame_ms=40.0, hop_ms=10.0):
    fl, hop = int(sr * frame_ms / 1000), int(sr * hop_ms / 1000)
    starts = np.arange(0, max(1, len(y) - fl), hop)
    return np.stack([y[s:s + fl] for s in starts])


def goertzel_power(x, sr, freq):
    """Energy of signal x at ONE frequency (Goertzel recursion, O(N))."""
    k = int(0.5 + len(x) * freq / sr)
    coeff = 2 * np.cos(2 * np.pi * k / len(x))
    s1 = s2 = 0.0
    for v in x:
        s0 = v + coeff * s1 - s2
        s2, s1 = s1, s0
    return s1 * s1 + s2 * s2 - coeff * s1 * s2


def tone_powers(frames, sr):
    """Vectorised version: (n_frames, 7) energies at the 7 DTMF frequencies (direct DFT at the exact frequency)."""
    n = frames.shape[1]; t = np.arange(n) / sr
    E = np.stack([np.exp(-2j * np.pi * f * t) for f in DTMF_ALL], axis=1)        # (n, 7)
    return np.abs(frames @ E) ** 2


def classify_frames(frames, powers, min_energy=0.01, min_share=0.30, dominance=2.0):
    """Per frame: a digit character, or None if the frame is not a clean DTMF tone."""
    energy = (frames ** 2).mean(1); emax = energy.max() or 1.0
    labels = []
    for e, p in zip(energy, powers):
        lo = np.argsort(p[:4])[::-1]; hi = np.argsort(p[4:])[::-1]
        share = (p[lo[0]] + p[4 + hi[0]]) / (p.sum() + 1e-12)
        ok = e > min_energy * emax and share > min_share and p[lo[0]] > dominance * p[lo[1]] and p[4 + hi[0]] > dominance * p[4 + hi[1]]
        labels.append(DTMF_KEYS[(DTMF_LOW[lo[0]], DTMF_HIGH[hi[0]])] if ok else None)
    return labels


def group_presses(labels, typ_frames=None, min_run=7, bridge=3):
    """Frames -> key presses: bridge tiny dropouts, keep runs >= min_run frames, split long runs into repeats."""
    lab = list(labels); n = len(lab); i = 0
    while i < n:
        if lab[i] is None:
            j = i
            while j < n and lab[j] is None: j += 1
            if 0 < i < j < n and lab[i - 1] == lab[j] and j - i <= bridge:
                for k in range(i, j): lab[k] = lab[j]
            i = j
        else:
            i += 1
    runs, i = [], 0
    while i < n:
        v, j = lab[i], i
        while j < n and lab[j] == v: j += 1
        if v is not None and j - i >= min_run: runs.append((v, j - i))
        i = j
    digits = ""
    if runs:
        typ = typ_frames or sorted(r[1] for r in runs)[len(runs) // 2]
        for v, L in runs: digits += v * max(1, round(L / typ))
    return runs, digits


def dtmf_truth():
    with open(os.path.join(DATA, "dtmf", "truth.csv")) as f:
        return {r["file"]: (float(r["distance_samples_44k"]), r["number"]) for r in csv.DictReader(f)}

# %%
import warnings; warnings.filterwarnings("ignore")
import numpy as np, matplotlib.pyplot as plt, librosa.display
from IPython.display import Audio, display

plt.rcParams.update({"figure.dpi": 110, "font.size": 10})

# %%
truth = dtmf_truth()          # file -> (dialling-speed hint, number actually dialled)
name = "Demo_3.wav"; sr = 8000
y = load(os.path.join(DATA, "dtmf", name), sr=sr); t = np.arange(len(y)) / sr
fig, ax = plt.subplots(figsize=(13, 2.6)); ax.plot(t, y, lw=.4); ax.set_title(f"{name} — each burst is one key press"); ax.set_xlabel("time (s)"); plt.show()
print("dialled:", truth[name][1]); Audio(y, rate=sr)

# %% [markdown]
# ### Step 1 — the Goertzel algorithm
# We only care about **7 frequencies**, so a full FFT is overkill. Goertzel measures the energy at *one* frequency with a tiny recursive filter (`goertzel_power(x, sr, f)`, defined above). Check it on a pure 770 Hz tone — only the 770 Hz bin should light up.

# %%
tone = np.sin(2 * np.pi * 770 * np.arange(1600) / sr)
for f in DTMF_ALL:
    print(f"{f:5d} Hz  " + "#" * int(40 * goertzel_power(tone, sr, f) / goertzel_power(tone, sr, 770)))

# %% [markdown]
# ### Exercise 1 — read one digit from one frame
# Take a single 40 ms frame from the middle of the first key press. Compute the energy at the 7 DTMF frequencies, pick the strongest **low** and strongest **high**, and look the pair up in `DTMF_KEYS`.

# %%
# SOLUTION
frames = frame_signal(y, sr)
labels_rough = classify_frames(frames, tone_powers(frames, sr))
first = next(i for i, l in enumerate(labels_rough) if l is not None)
frame = frames[first + 8]
powers = [goertzel_power(frame, sr, f) for f in DTMF_ALL]
low = DTMF_LOW[int(np.argmax(powers[:4]))]; high = DTMF_HIGH[int(np.argmax(powers[4:]))]
print(low, high, "->", DTMF_KEYS[(low, high)])

# %%
plt.figure(figsize=(7, 2.8)); cols = ["tab:red" if f in (low, high) else "tab:blue" for f in DTMF_ALL]
plt.bar([str(f) for f in DTMF_ALL], powers, color=cols); plt.xlabel("DTMF frequency (Hz)"); plt.ylabel("Goertzel energy"); plt.title("one 40 ms frame: two clear peaks = one digit"); plt.show()

# %% [markdown]
# ### Step 2 — every frame, then key presses
# `classify_frames` applies the same rule to every frame and rejects frames that are not a clean tone (too quiet, energy not concentrated in one low + one high frequency). `group_presses` bridges tiny dropouts, keeps runs of ≥ 70 ms, and splits a *long* run into repeated digits (needs a hint about the dialling speed).

# %%
P = tone_powers(frames, sr); labels = classify_frames(frames, P)
print("per-frame label ('.' = no tone):"); print("".join("." if l is None else l for l in labels))
runs, digits = group_presses(labels, typ_frames=truth[name][0] / 441)   # hint: samples@44.1kHz / 441 = 10 ms frames
print("recovered:", digits, "   dialled:", truth[name][1])

# %% [markdown]
# ### Exercise 2 — decode all eight recordings
# Write `decode(file, hint=True)`, run it on every file, and count exact matches. Compare **with** the dialling-speed hint and **without** it (`typ_frames=None` → median run length).

# %%
# SOLUTION
def decode(fname, hint=True):
    y = load(os.path.join(DATA, "dtmf", fname), sr=8000)
    fr = frame_signal(y, 8000)
    labels = classify_frames(fr, tone_powers(fr, 8000))
    return group_presses(labels, typ_frames=truth[fname][0] / 441 if hint else None)[1]

# %%
print(f"{'file':12s} {'dialled':12s} {'with hint':12s} {'no hint':12s}")
ok = {True: 0, False: 0}
for fname in sorted(truth):
    num = truth[fname][1]; row = []
    for hint in (True, False):
        d = decode(fname, hint); ok[hint] += d == num; row.append(d + (" ✓" if d == num else " ✗"))
    print(f"{fname:12s} {num:12s} {row[0]:14s} {row[1]}")
print(f"\nexact: {ok[True]}/8 with the dialling-speed hint, {ok[False]}/8 without")

# %% [markdown]
# ### Exercise 3 — how much noise does it take?
# Add white noise to each recording at several signal-to-noise ratios (`add_noise(clip, snr_db, rng)`), decode **with** the hint, and count how many numbers are still recovered exactly. Average over **5 random noise draws** — a single draw is too noisy to trust.
#
# *Note:* the SNR is measured against the **average power of the whole recording**, which is mostly silence between key presses, so the *local* SNR during a tone is much better than the number suggests.

# %%
# SOLUTION
snrs = [20, 10, 0, -10, -15, -20]
exact = []
for snr in snrs:
    per_seed = []
    for seed in range(5):
        rng = np.random.default_rng(seed); n_ok = 0
        for fname, (dist, num) in sorted(truth.items()):
            y = load(os.path.join(DATA, "dtmf", fname), sr=8000)
            noisy = add_noise(y, snr, rng)
            fr = frame_signal(noisy, 8000)
            n_ok += group_presses(classify_frames(fr, tone_powers(fr, 8000)), typ_frames=dist / 441)[1] == num
        per_seed.append(n_ok)
    exact.append(np.mean(per_seed))

# %%
plt.figure(figsize=(6.5, 3.2)); plt.plot(snrs, exact, "o-"); plt.gca().invert_xaxis(); plt.ylim(-.3, 8.3)
plt.xlabel("SNR (dB)  ← more noise"); plt.ylabel("numbers recovered exactly (mean of 5 draws, of 8)"); plt.grid(alpha=.3); plt.show()
print({s_: round(e, 1) for s_, e in zip(snrs, exact)})

# %% [markdown]
# **Discuss**
# 1. This attack needs **no training data** — the 'model' is the DTMF standard. How does that change the threat model compared with the keyboard attack in the next labs (profiling cost)?
# 2. Where do DTMF tones end up in a real organisation? (Phone banking, conference-bridge PINs, voicemail codes, IVR menus, call recordings.)
# 3. Defences: don't enter secrets over an open line near other microphones; prefer app-based or out-of-band authentication; suppress or randomise local key tones; redact recordings.
#
# *Ethics:* the recordings are provided demo data. Decoding other people's calls without consent is illegal in many places.

# %% [markdown]
# ---
# ---
# <a id='lab2'></a>
# ## ▶ LAB 2  ·  `01_signal_and_segmentation.ipynb` (★★)

# %% [markdown]
# # Lab 2 — From raw audio to individual keystrokes (≈30 min)
# **Pipeline step:** *capture → filter → segment*
#
# You will: look at a real recording, find the frequency band where keystrokes live, and detect every keystroke automatically. Then you will see how fragile the detector is.

# %% [markdown]
# ### Helper functions for Lab 2
# Defined here, then used in the cells below.

# %%
def bandpass(y, lo=200, hi=500, sr=SR, order=4):
    sos = butter(order, [lo / (sr / 2), hi / (sr / 2)], btype="band", output="sos")
    return sosfiltfilt(sos, y)


def energy_envelope(y, sr=SR, lo=200, hi=500, smooth_ms=15):
    f = bandpass(y, lo, hi, sr)
    win = max(1, int(smooth_ms / 1000 * sr))
    return np.convolve(f ** 2, np.ones(win) / win, mode="same")


def detect_keystrokes(y, sr=SR, rel_thresh=1 / 8, min_gap_s=0.5, lo=200, hi=500):
    """Return sample indices of keystroke peaks (energy envelope + find_peaks)."""
    env = energy_envelope(y, sr, lo, hi)
    thr = env.max() * rel_thresh
    peaks, _ = find_peaks(env, height=thr, distance=int(min_gap_s * sr))
    return peaks, env, thr


def clip_around(y, peak, sr=SR, half_s=0.15):
    h = int(half_s * sr)
    return y[max(0, peak - h): min(len(y), peak + h)]

# %%
import warnings; warnings.filterwarnings("ignore")
import numpy as np, matplotlib.pyplot as plt, librosa.display
from IPython.display import Audio, display

plt.rcParams.update({"figure.dpi": 110, "font.size": 10})

# %%
y = load(os.path.join(DATA, "sentences", "good-afternoon.wav"))
t = np.arange(len(y)) / SR
fig, ax = plt.subplots(figsize=(13, 2.8)); ax.plot(t, y, lw=.4)
ax.set_xlabel("time (s)"); ax.set_title('"good afternoon" — raw microphone signal'); plt.show()
Audio(y, rate=SR)

# %% [markdown]
# ### 1.1 Where does keystroke energy live?
# Plot the spectrogram. Keystrokes show up as vertical streaks (broadband impulses) — but *where* are they strongest?

# %%
D = librosa.amplitude_to_db(np.abs(librosa.stft(y, n_fft=2048)), ref=np.max)
fig, ax = plt.subplots(figsize=(13, 4))
img = librosa.display.specshow(D, sr=SR, x_axis="time", y_axis="hz", ax=ax, cmap="magma")
ax.set_ylim(0, 3000); fig.colorbar(img, ax=ax, label="dB"); plt.show()

# %% [markdown]
# ### Exercise 4 — choose a band-pass filter
# From the spectrogram, pick `lo` and `hi` (Hz) so the filter keeps the keystroke thumps and rejects the rest. Then compare raw vs filtered.

# %%
# SOLUTION
lo, hi = 200, 500

# %%
filtered = bandpass(y, lo, hi)
fig, ax = plt.subplots(2, 1, figsize=(13, 4.5), sharex=True)
ax[0].plot(t, y, lw=.4); ax[0].set_title("raw")
ax[1].plot(t, filtered, lw=.4, c="C1"); ax[1].set_title(f"band-pass {lo}-{hi} Hz"); ax[1].set_xlabel("time (s)")
plt.tight_layout(); plt.show()
print("fraction of energy kept:", float(np.sum(filtered**2)/np.sum(y**2)))

# %% [markdown]
# **Discuss:** why would a *narrow low-frequency* band work well on a phone? (Hint: what excites the body of the phone vs. the electronics noise floor?)
#
# ### 1.2 Detect keystrokes
# We square the filtered signal, smooth it into an *energy envelope*, and use `scipy.signal.find_peaks` with two knobs:
# * `rel_thresh` — how tall a peak must be, relative to the tallest one
# * `min_gap_s` — minimum time between two keystrokes

# %%
peaks, env, thr = detect_keystrokes(y, rel_thresh=1/8, min_gap_s=0.4)
print("detected:", len(peaks), " — but 'good afternoon' has 13 letters!")
fig, ax = plt.subplots(figsize=(13, 3)); ax.plot(t, env); ax.plot(peaks/SR, env[peaks], "rv"); ax.axhline(thr, ls=":", c="gray")
ax.set_title(f"{len(peaks)} peaks with the default settings"); plt.show()

# %% [markdown]
# ### Exercise 5 — tune the detector
# We **know** the right answer is 13 keystrokes. Find `rel_thresh` and `min_gap_s` that give exactly 13.
# (The sweep below shows the full picture — peek at it only after trying by hand for a minute.)

# %%
# SOLUTION
rel_thresh, min_gap_s = 1/4, 0.7
peaks, env, thr = detect_keystrokes(y, rel_thresh=rel_thresh, min_gap_s=min_gap_s)
print(len(peaks), "keystrokes")

# %%
# Sensitivity sweep: how many keystrokes get detected for each setting?
gaps = [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 1.0]
rels = [1/2, 1/4, 1/8, 1/16, 1/32]
grid = np.array([[len(detect_keystrokes(y, rel_thresh=r, min_gap_s=g)[0]) for g in gaps] for r in rels])
fig, ax = plt.subplots(figsize=(7, 3.5)); im = ax.imshow(grid, cmap="RdYlGn_r", aspect="auto", vmin=5, vmax=40)
ax.set_xticks(range(len(gaps))); ax.set_xticklabels(gaps); ax.set_yticks(range(len(rels))); ax.set_yticklabels([f"1/{round(1/r)}" for r in rels])
ax.set_xlabel("min_gap_s"); ax.set_ylabel("rel_thresh")
for i in range(len(rels)):
    for j in range(len(gaps)): ax.text(j, i, grid[i, j], ha="center", va="center", fontsize=9, fontweight="bold" if grid[i, j] == 13 else None)
ax.set_title("detected keystrokes (13 = correct)"); plt.show()

# %% [markdown]
# **Discuss (3 min, in pairs):**
# 1. Only a narrow region of settings gives the right answer. What does that mean for a real attacker who *doesn't* know how many keys were pressed?
# 2. What would break a fixed `min_gap_s` — fast typists? Background music? Think about what a robust attacker would do instead.
#
# ### 1.3 Cut out the keystroke clips

# %%
fig, axes = plt.subplots(2, 7, figsize=(14, 4), sharey=True)
for i, (ax, pk) in enumerate(zip(axes.ravel(), peaks)):
    c = clip_around(y, pk, half_s=0.15); ax.plot(c, lw=.6); ax.set_title(f"key {i+1}", fontsize=8); ax.axis("off")
plt.suptitle('Each keystroke → a 300 ms clip (the true letters: g o o d a f t e r n o o n)'); plt.tight_layout(); plt.show()

# %% [markdown]
# **Takeaway.** Segmentation is a *signal-processing* problem and a real source of error before any machine learning happens. Next lab: turn each clip into numbers.

# %% [markdown]
# ---
# ---
# <a id='lab3'></a>
# ## ▶ LAB 3  ·  `02_features_and_classifier.ipynb` (★★)

# %% [markdown]
# # Lab 3 — Features and the key classifier (≈35 min)
# **Pipeline step:** *clip → features → "which letter was that?"*
#
# You will compare a small hand-crafted feature set with a richer one, and then design a feature of your own.

# %% [markdown]
# ### Helper functions for Lab 3
# Defined here, then used in the cells below.

# %%
def features(clip, sr=SR):
    """Per-keystroke feature vector: spectral kurtosis, mean pitch, short-time
    energy (original thesis features) + 13 MFCC means (added for the lab)."""
    if len(clip) < 1024:
        clip = np.pad(clip, (0, 1024 - len(clip)))
    c = librosa.effects.preemphasis(clip)
    P = np.abs(librosa.stft(c, n_fft=1024)) ** 2
    sk = float(np.mean(kurtosis(P, axis=1)))
    pit = librosa.piptrack(y=c, sr=sr, n_fft=1024)[0]
    nz = pit[pit > 0]
    pm = float(nz.mean()) if nz.size else 0.0
    fl, hl = int(0.02 * sr), int(0.01 * sr)
    ste = float(np.mean([np.sum(c[i:i + fl] ** 2) for i in range(0, max(1, len(c) - fl), hl)]))
    mf = librosa.feature.mfcc(y=c, sr=sr, n_mfcc=13, n_fft=1024).mean(axis=1)
    return np.concatenate([[sk, pm, ste], mf])


FEATURE_NAMES = ["spectral_kurtosis", "pitch", "ste"] + [f"mfcc{i}" for i in range(13)]


def feature_matrix(clips, feat_fn=features):
    return np.array([feat_fn(c) for c in clips])


def topk_accuracy(proba, classes, y_true, k=5):
    classes = np.asarray(classes)
    return float(np.mean([y_true[i] in classes[np.argsort(proba[i])[::-1][:k]] for i in range(len(y_true))]))

# %%
import warnings; warnings.filterwarnings("ignore")
import numpy as np, matplotlib.pyplot as plt, librosa.display
from IPython.display import Audio, display

plt.rcParams.update({"figure.dpi": 110, "font.size": 10})
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_predict
import collections

# %%
clips, letters, sessions = load_clips()
X = feature_matrix(clips)               # ~10 s
print(X.shape, "->", FEATURE_NAMES)
cnt = collections.Counter(letters); print(sorted(cnt.items()))
plt.figure(figsize=(8, 2.5)); plt.bar(*zip(*sorted(cnt.items()))); plt.title("clips per letter (note the imbalance!)"); plt.show()

# %% [markdown]
# `features()` returns 16 numbers per clip: the 3 original thesis features (**spectral kurtosis, pitch, short-time energy**) plus 13 **MFCCs**.
#
# ### 2.1 Can two features separate the letters?

# %%
fig, ax = plt.subplots(figsize=(7, 5))
for L, col in zip("egkpsvw", plt.cm.tab10.colors):
    m = letters == L; ax.scatter(X[m, 0], np.log10(X[m, 2] + 1e-12), s=14, color=col, label=L, alpha=.7)
ax.set_xlabel("spectral kurtosis"); ax.set_ylabel("log10 short-time energy"); ax.legend(ncol=2); plt.show()

# %% [markdown]
# Heavy overlap — one letter is not a point, it's a cloud, and clouds overlap. That is why we report **top-k** accuracy: the attacker only needs the right letter among a *short list*, because a dictionary will clean up the rest (Lab 7).
#
# ### Exercise 6 — measure it properly
# Complete `evaluate()` using **5-fold stratified cross-validation** and report top-1 and top-5 accuracy.

# %%
# SOLUTION
def evaluate(model, X, y, k=5):
    classes = np.array(sorted(set(y)))
    cv = StratifiedKFold(5, shuffle=True, random_state=0)
    proba = cross_val_predict(make_pipeline(StandardScaler(), model), X, y, cv=cv, method="predict_proba")
    top1 = float(np.mean(classes[proba.argmax(1)] == y))
    topk = topk_accuracy(proba, classes, y, k)
    return top1, topk

# %%
# keep letters with >=5 clips so every CV fold has them
keep = [l for l, c in cnt.items() if c >= 5]; m = np.isin(letters, keep); Xk, yk = X[m], letters[m]
print(f"{len(keep)} letters, chance level = {1/len(keep):.1%}\n")
rows = []
for name, cols in [("3 original features", slice(0, 3)), ("3 + 13 MFCC", slice(0, 16))]:
    for mname, mod in [("k-NN (k=5)", KNeighborsClassifier(5)), ("Random forest", RandomForestClassifier(300, random_state=0))]:
        t1, t5 = evaluate(mod, Xk[:, cols], yk); rows.append((name, mname, t1, t5)); print(f"{name:20s} {mname:14s} top-1 {t1:5.1%}   top-5 {t5:5.1%}")

# %% [markdown]
# **Read the table.** What gave the biggest jump — the model or the features? (In most side-channel work it is the features.)
#
# ### 2.2 What gets confused?

# %%
cls = np.array(sorted(set(yk)))
pred = cross_val_predict(make_pipeline(StandardScaler(), RandomForestClassifier(300, random_state=0)), Xk, yk,
                         cv=StratifiedKFold(5, shuffle=True, random_state=0))
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(yk, pred, labels=cls, normalize="true")
fig, ax = plt.subplots(figsize=(6.5, 5.5)); im = ax.imshow(cm, cmap="Blues")
ax.set_xticks(range(len(cls))); ax.set_xticklabels(cls); ax.set_yticks(range(len(cls))); ax.set_yticklabels(cls)
ax.set_xlabel("predicted"); ax.set_ylabel("true"); fig.colorbar(im); plt.show()

# %% [markdown]
# ### Exercise 7 — design your own feature *(optional if you are short on time)*
# Write `my_features(clip)` that returns the original 16 features **plus at least two of your own** (ideas: spectral centroid, spectral rolloff, zero-crossing rate, RMS, energy in 3 sub-bands, onset-to-peak time, decay time). Then compare with the baseline — a feature that doesn't help is a valid scientific result.

# %%
# SOLUTION
def my_features(clip, sr=SR):
    base = features(clip, sr)
    c = clip if len(clip) >= 1024 else np.pad(clip, (0, 1024 - len(clip)))
    cen = librosa.feature.spectral_centroid(y=c, sr=sr, n_fft=1024).mean()
    roll = librosa.feature.spectral_rolloff(y=c, sr=sr, n_fft=1024).mean()
    zcr = librosa.feature.zero_crossing_rate(c).mean()
    rms = np.sqrt(np.mean(c ** 2))
    return np.concatenate([base, [cen, roll, zcr, rms]])

# %%
Xm = feature_matrix(clips, my_features)[m]
rf = RandomForestClassifier(300, random_state=0)
print("baseline 16 features:", evaluate(rf, Xk, yk))
print("my features         :", evaluate(rf, Xm, yk))

# %% [markdown]
# **Takeaway.** Within a single recording condition, a laptop-grade pipeline recovers the right letter in its top-5 about nine times out of ten — from a *phone microphone* and a few thousand lines of Python. The next lab asks: does that survive a change of conditions?

# %% [markdown]
# ---
# ### ☕ Break (15 min)

# %% [markdown]
# ---
# ---
# <a id='lab4'></a>
# ## ▶ LAB 4  ·  `03_evaluation_pitfalls.ipynb` (★★★)

# %% [markdown]
# # Lab 4 — How much should you trust an attack paper? (≈20 min)
# Reported accuracy depends heavily on **how you split train and test**. This lab reproduces three evaluation protocols on the *same* data.
#
# | Protocol | What the attacker has |
# |---|---|
# | **A. Pooled random split** | test clips come from the same recordings as training clips |
# | **B. Cross-session** | train on session 1, test on a *different* session (another day / hand position) |
# | **C. Cross-session + calibration** | as B, but the attacker also gets a few labelled clips from the victim's session |

# %%
import warnings; warnings.filterwarnings("ignore")
import numpy as np, matplotlib.pyplot as plt, librosa.display
from IPython.display import Audio, display

plt.rcParams.update({"figure.dpi": 110, "font.size": 10})
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_predict
import collections
clips, letters, sessions = load_clips(); X = feature_matrix(clips)
mk = lambda: make_pipeline(StandardScaler(), RandomForestClassifier(300, random_state=0))

# %%
# Protocol A — pooled 5-fold CV
keep = [l for l, c in collections.Counter(letters).items() if c >= 5]; m = np.isin(letters, keep)
cls = np.array(sorted(set(letters[m])))
pA = cross_val_predict(mk(), X[m], letters[m], cv=StratifiedKFold(5, shuffle=True, random_state=0), method="predict_proba")
A = (np.mean(cls[pA.argmax(1)] == letters[m]), topk_accuracy(pA, cls, letters[m], 5)); print("A pooled      top-1 %.1f%%  top-5 %.1f%%" % (100*A[0], 100*A[1]))

# %% [markdown]
# ### Exercise 8 — protocol B
# Train on **session 1** only, test on **session 2** only, using only letters present in both sessions.

# %%
# SOLUTION
cnt1 = collections.Counter(letters[sessions == 1]); cnt2 = collections.Counter(letters[sessions == 2])
common = [l for l in cnt1 if cnt1[l] >= 3 and cnt2.get(l, 0) >= 3]
tr = (sessions == 1) & np.isin(letters, common); te = (sessions == 2) & np.isin(letters, common)
model = mk().fit(X[tr], letters[tr])
pB = model.predict_proba(X[te]); cl = model.classes_
B = (np.mean(cl[pB.argmax(1)] == letters[te]), topk_accuracy(pB, cl, letters[te], 5))
print("B cross-session top-1 %.1f%%  top-5 %.1f%%" % (100*B[0], 100*B[1]))

# %% [markdown]
# ### Exercise 9 — protocol C (calibration)
# Give the attacker `n_cal` labelled clips **per letter** from session 2, add them to the training set, and test on the remaining session-2 clips. How few clips are needed?

# %%
# SOLUTION
def protocol_C(n_cal, seed=0):
    rng = np.random.default_rng(seed)
    idx2 = np.where(te)[0]
    cal = []
    for L in common:
        li = idx2[letters[idx2] == L]; cal += list(rng.permutation(li)[:n_cal])
    cal = np.array(cal)
    rest = np.setdiff1d(idx2, cal)
    trn = np.concatenate([np.where(tr)[0], cal])
    mdl = mk().fit(X[trn], letters[trn]); p = mdl.predict_proba(X[rest])
    return float(np.mean(mdl.classes_[p.argmax(1)] == letters[rest])), topk_accuracy(p, mdl.classes_, letters[rest], 5)

# %%
ns = [0, 1, 2, 3, 5]
res = [np.mean([protocol_C(n, s) for s in range(5)], axis=0) if n else B for n in ns]
fig, ax = plt.subplots(figsize=(6.5, 3.5))
ax.plot(ns, [100*r[0] for r in res], "o-", label="top-1"); ax.plot(ns, [100*r[1] for r in res], "s-", label="top-5")
ax.axhline(100/len(common), ls=":", c="gray", label="chance (top-1)"); ax.set_xlabel("calibration clips per letter"); ax.set_ylabel("accuracy (%)"); ax.legend(); plt.show()
print(f"A pooled: {A[0]:.0%}/{A[1]:.0%}   B cross-session: {B[0]:.0%}/{B[1]:.0%}   (top-1/top-5)")

# %% [markdown]
# **Discussion — what should an industry reader ask of an attack paper?**
# 1. Was the test data recorded in a different session, on a different day, with a different device position?
# 2. How many labelled clips does the attacker need from the *victim's* device — and how would they get them? (Think: malware on the phone, a voice call, a shared video.)
# 3. Were consecutive keystrokes from one recording split across train and test?
# 4. Is accuracy per *keystroke*, per *word*, or per *sentence*? They are very different numbers.
#
# > The honest reading of this dataset: the signal is real and strong **within** a session; **across** sessions top-1 accuracy collapses and top-5 degrades less, unless the attacker calibrates on the victim's session. Both statements are true, and risk assessments should state both.
#
# *Caveat:* clips from one recording are correlated, so even protocol A is somewhat optimistic; and our dataset is small (≈650 clips, 16 letters, one phone).

# %% [markdown]
# ---
# ---
# <a id='lab5'></a>
# ## ▶ LAB 5  ·  `07_beyond_keyboards.ipynb` (★★★)

# %% [markdown]
# # Lab 5 — Beyond keyboards: which app is running? which instruction is executing? (≈25 min)
# Devices make sound even when nobody is typing: coil whine, capacitors and voltage regulators change their noise with the workload. Two demonstrations from the lecture's case studies:
#
# * **5A — App identification:** a phone's acoustic emanations while running Amazon / Facebook / LinkedIn / YouTube / Zomato (5 recordings, first 20 s each).
# * **5B — CPU instruction identification:** a microcontroller looping one of 6 AVR instructions (OR, SUB, ADIW, MUL, ASR, SWAP; 2 recordings each, first 10 s).
#
# > The original MATLAB demos report **99.8 %** (apps) and **100 %** (CPU). Both were scored on the *same recordings the model was trained on* ("resubstitution"). Here we re-do them in Python and ask the Lab 4 question again: **what does the number mean?**

# %% [markdown]
# ### Helper functions for Lab 5
# Defined here, then used in the cells below.

# %%
def window_features(y, sr, win_ms=30, hop_ms=15):
    """Per-window features for app identification: 13 MFCC + spectral centroid + RMS + zero-crossing rate."""
    n, h = int(win_ms / 1000 * sr), int(hop_ms / 1000 * sr)
    M = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13, n_fft=n, hop_length=h, n_mels=40)
    c = librosa.feature.spectral_centroid(y=y, sr=sr, n_fft=n, hop_length=h)
    r = librosa.feature.rms(y=y, frame_length=n, hop_length=h)
    z = librosa.feature.zero_crossing_rate(y, frame_length=n, hop_length=h)
    return np.vstack([M, c, r, z]).T


APP_FEATURE_NAMES = [f"mfcc{i}" for i in range(13)] + ["centroid", "rms", "zcr"]


def mrmr_select(X, y, k=8, random_state=0):
    """Simplified mRMR: greedily pick the feature maximising  relevance - mean |correlation| with already-chosen ones.
    relevance = mutual information with the label."""
    rel = mutual_info_classif(X, y, random_state=random_state)
    C = np.abs(np.corrcoef(X, rowvar=False)); chosen = [int(np.argmax(rel))]
    while len(chosen) < k:
        score = [(rel[j] - C[j, chosen].mean()) if j not in chosen else -np.inf for j in range(X.shape[1])]
        chosen.append(int(np.argmax(score)))
    return chosen, rel


def loudness_envelope(x, fs, tau=0.125):
    """Fast-weighted (125 ms) sound level in dB, like an SPL meter, mean removed."""
    a = np.exp(-1 / (tau * fs)); L = 10 * np.log10(lfilter([1 - a], [1, -a], x ** 2) + 1e-20)
    return L - L.mean()


def psd_block_feature(block, fs, n_feat=7):
    """Thesis feature: first n_feat bins of the centred periodogram of the loudness envelope of one block."""
    p = np.fft.fftshift(periodogram(loudness_envelope(block, fs), fs=fs, return_onesided=False)[1])
    return np.log10(p[:n_feat] + 1e-30)

# %%
import warnings; warnings.filterwarnings("ignore")
import numpy as np, matplotlib.pyplot as plt, librosa.display
from IPython.display import Audio, display

plt.rcParams.update({"figure.dpi": 110, "font.size": 10})
import glob, soundfile as sf, collections
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
mk = lambda: make_pipeline(StandardScaler(), SVC(C=10))

# %% [markdown]
# ## 5A — App identification
# Each recording is cut into 30 ms windows (15 ms hop); every window becomes 16 numbers (13 MFCC, spectral centroid, RMS, zero-crossing rate).

# %%
D = {}
for p in sorted(glob.glob(os.path.join(DATA, "emanations", "app", "*.wav"))):
    y, sr_app = sf.read(p); D[os.path.basename(p)[:-4]] = window_features(y.astype(np.float32), sr_app)
apps = list(D); print({k: v.shape for k, v in D.items()}, " sample rate", sr_app)
fig, ax = plt.subplots(1, 5, figsize=(14, 2.6), sharey=True)
for a, k in zip(ax, apps): a.imshow(D[k][:, :13].T[:, :300], aspect="auto", origin="lower", cmap="magma"); a.set_title(k, fontsize=9); a.set_xlabel("window")
ax[0].set_ylabel("MFCC index"); plt.tight_layout(); plt.show()

# %% [markdown]
# ### Exercise 10 — three ways to score the same classifier
# 1. **Resubstitution** — train and test on the same windows (what the original demo does).
# 2. **Random window split** — 70 % / 30 % of windows at random. *Overlapping 30 ms windows from the same second end up on both sides.*
# 3. **Time split** — train on the first 70 % of each recording, test on the last 30 %, leaving a **gap** of 40 windows so no window straddles the boundary.
#
# Implement `time_split` and compare.

# %%
# SOLUTION
def time_split(D, frac=0.7, gap=40):
    Xa, ya, Xb, yb = [], [], [], []
    for k, F in D.items():
        h = int(len(F) * frac)
        Xa.append(F[:h - gap]); ya += [k] * (h - gap); Xb.append(F[h:]); yb += [k] * (len(F) - h)
    return np.vstack(Xa), np.array(ya), np.vstack(Xb), np.array(yb)

# %%
Xa, ya, Xb, yb = time_split(D)
m = mk().fit(Xa, ya)
res_acc = np.mean(m.predict(Xa) == ya); time_acc = np.mean(m.predict(Xb) == yb)
Xall = np.vstack(list(D.values())); yall = np.concatenate([[k] * len(v) for k, v in D.items()])
idx = np.random.default_rng(0).permutation(len(yall)); cut = int(.7 * len(idx))
rnd_acc = np.mean(mk().fit(Xall[idx[:cut]], yall[idx[:cut]]).predict(Xall[idx[cut:]]) == yall[idx[cut:]])
# majority vote over ~1 s chunks (66 windows) of the time-split test part
pred = m.predict(Xb); votes = []; pos = 0
for k in apps:
    n_ = int(np.sum(yb == k)); pp = pred[pos:pos + n_]; pos += n_
    votes += [collections.Counter(pp[i:i + 66]).most_common(1)[0][0] == k for i in range(0, n_ - 65, 66)]
print(f"chance                          : {1/len(apps):.0%}")
print(f"1. resubstitution (windows)     : {res_acc:.1%}")
print(f"2. random window split          : {rnd_acc:.1%}   <- neighbours leak")
print(f"3. time split, per window       : {time_acc:.1%}")
print(f"   time split, 1-s majority vote: {np.mean(votes):.1%}   ({len(votes)} chunks)")

# %% [markdown]
# **Read it.** The signal is real (far above 20 % chance, even on unseen *time*) — but the headline number depends on the protocol, and **all** of this is still one recording per app in one session. A real claim needs several recordings per app on different days (the Lab 4 lesson).
#
# ### Exercise 11 — feature selection (mRMR)
# TapLeak and the original app demo use **mRMR** to keep a few features. `mrmr_select(X, y, k)` is a simplified version (relevance = mutual information with the label, minus average correlation with features already chosen). Sweep `k` and see whether selecting fewer features helps on the *time-split* test.

# %%
# SOLUTION
ks = [2, 4, 8, 12, 16]
scores = []
for k in ks:
    cols, _ = mrmr_select(Xa, ya, k)
    scores.append(np.mean(mk().fit(Xa[:, cols], ya).predict(Xb[:, cols]) == yb))

# %%
plt.figure(figsize=(6, 3.2)); plt.plot(ks, [100*s for s in scores], "o-"); plt.axhline(100/len(apps), ls=":", c="gray")
plt.xlabel("number of features kept"); plt.ylabel("time-split accuracy (%)"); plt.show()
print([f"k={k}: {s:.0%}" for k, s in zip(ks, scores)]); print("mRMR order:", [APP_FEATURE_NAMES[i] for i in mrmr_select(Xa, ya, 8)[0]])

# %% [markdown]
# *Note:* the original demo selected 8 out of **862** features. We only have 16, so selection has little to offer — in this setting it can even hurt. Whether a feature-selection step helps is an empirical question, not a given.
#
# ## 5B — Which CPU instruction is running?
# The thesis feature: take **one 1024-sample block** (~23 ms) of the recording, compute the *loudness envelope* (fast-weighted sound level), subtract its mean, and keep the **first 7 bins of the power spectrum** of that wobble. 12 clips → 12 points in 7-D.

# %%
cpu = {os.path.basename(p)[:-4]: sf.read(p)[0] for p in sorted(glob.glob(os.path.join(DATA, "emanations", "cpu", "*.wav")))}
FS = 44100; lab = lambda nme: nme.split("_")[0]
names = list(cpu); y_cpu = np.array([lab(k) for k in names])
X1 = np.array([psd_block_feature(cpu[k][6 * 1024: 7 * 1024], FS) for k in names])     # block #7 of every clip
print(X1.shape, "->", sorted(set(y_cpu)))

# %% [markdown]
# ### Exercise 12 — is 100 % meaningful?
# 1. Train a **1-nearest-neighbour** classifier on the 12 points and score it on the same 12 points.
# 2. **Shuffle the labels** (random instruction names) and do it again.
# 3. If a classifier also gets 100 % on *meaningless* labels, what does 100 % on real labels tell you?

# %%
# SOLUTION
knn = make_pipeline(StandardScaler(), KNeighborsClassifier(1))
real = np.mean(knn.fit(X1, y_cpu).predict(X1) == y_cpu)
rng = np.random.default_rng(0); shuffled = []
for _ in range(20):
    y_perm = rng.permutation(y_cpu)
    shuffled.append(np.mean(knn.fit(X1, y_perm).predict(X1) == y_perm))
print(f"real labels: {real:.0%}    shuffled labels: {np.mean(shuffled):.0%}")

# %% [markdown]
# Now the fair question: if we train on **recording 1** of each instruction and test on **recording 2** (a different capture of the same instruction), using many blocks per clip, can we still tell the instructions apart?

# %%
feats = {1: [], 2: []}; labs = {1: [], 2: []}
for k in names:
    rec = int(k[-1])
    for b in range(6, len(cpu[k]) // 1024, 10):
        feats[rec].append(psd_block_feature(cpu[k][b * 1024:(b + 1) * 1024], FS)); labs[rec].append(lab(k))
for tr, te in [(1, 2), (2, 1)]:
    m = mk().fit(np.array(feats[tr]), labs[tr]); acc = np.mean(m.predict(np.array(feats[te])) == np.array(labs[te]))
    print(f"train recording {tr} -> test recording {te}: {acc:.0%}   (chance {1/6:.0%}, {len(feats[te])} test blocks)")

# %% [markdown]
# **What can we conclude?** With *this* port of the feature and *only two recordings per instruction*, the held-out accuracy is near chance. That does **not** prove CPU-instruction leakage is impossible — we used one feature family, little data and a Python re-implementation of a MATLAB pipeline. It shows that the original 100 % cannot distinguish "learned the leakage" from "memorised 12 clips".
#
# **Design the study (discuss in groups, 5 min):** what would you need to record to make a defensible claim? Think: many recordings per instruction, different days / boards / microphone positions, instruction *sequences* instead of loops, a train/test split by *session*, and a shuffled-label baseline.

# %% [markdown]
# ---
# ---
# <a id='lab6'></a>
# ## ▶ LAB 6  ·  `05_defenses.ipynb` (★★★)

# %% [markdown]
# # Lab 6 — Defences (≈20 min)
# Now we play defender. For each countermeasure we measure how much it hurts the classifier — and then check whether an **adaptive attacker** who knows about it can recover.
#
# **Setup.** Train on clean clips; test on clips that have been degraded. Metric: top-1 / top-5 on held-out clips (5 random 70/30 splits).

# %% [markdown]
# ### Helper functions for Lab 6
# Defined here, then used in the cells below.

# %%
def lowpass(clip, cutoff, sr=SR, order=4):
    sos = butter(order, cutoff / (sr / 2), btype="low", output="sos")
    return sosfiltfilt(sos, clip)

# %%
import warnings; warnings.filterwarnings("ignore")
import numpy as np, matplotlib.pyplot as plt, librosa.display
from IPython.display import Audio, display

plt.rcParams.update({"figure.dpi": 110, "font.size": 10})
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
import collections
clips, letters, sessions = load_clips()
cnt = collections.Counter(letters); keep = [l for l, c in cnt.items() if c >= 10]
idx = np.array([i for i in range(len(letters)) if letters[i] in keep]); print(len(keep), "letters,", len(idx), "clips; chance =", f"{1/len(keep):.1%}")
X_clean = feature_matrix([clips[i] for i in idx]); y = letters[idx]
def run(transform_test, transform_train=None, seeds=(0, 1, 2), k=5):
    out = []
    for s in seeds:
        tri, tei = train_test_split(np.arange(len(idx)), test_size=.3, stratify=y, random_state=s)
        rng = np.random.default_rng(s)
        if transform_train is None: Xtr = X_clean[tri]
        else: Xtr = feature_matrix([transform_train(clips[idx[i]], rng) for i in tri])
        Xte = feature_matrix([transform_test(clips[idx[i]], rng) for i in tei])
        mdl = make_pipeline(StandardScaler(), RandomForestClassifier(200, random_state=0)).fit(Xtr, y[tri]); p = mdl.predict_proba(Xte)
        out.append((np.mean(mdl.classes_[p.argmax(1)] == y[tei]), topk_accuracy(p, mdl.classes_, y[tei], k)))
    return np.mean(out, axis=0)
print("baseline (no defence):", run(lambda c, r: c))

# %% [markdown]
# ### Defence 1 — masking noise (play white noise while typing)
# ### Exercise 13 — accuracy vs. signal-to-noise ratio
# Use `add_noise(clip, snr_db, rng)` to degrade the **test** clips at several SNRs (dB; lower = more noise) and plot accuracy.

# %%
# SOLUTION
snrs = [40, 30, 20, 10, 0, -10]
naive = []
for snr in snrs:
    naive.append(run(lambda c, r, snr=snr: add_noise(c, snr, r)))
naive = np.array(naive)

# %% [markdown]
# ### The adaptive attacker
# What if the attacker simply **trains on noisy data too** (they can add synthetic noise to their own profiling clips)?

# %%
adaptive = np.array([run(lambda c, r, snr=snr: add_noise(c, snr, r), lambda c, r, snr=snr: add_noise(c, snr, r)) for snr in snrs])
fig, ax = plt.subplots(figsize=(7, 3.8))
ax.plot(snrs, 100*naive[:, 0], "o-", label="naive attacker (top-1)"); ax.plot(snrs, 100*adaptive[:, 0], "s-", label="adaptive attacker (top-1)")
ax.plot(snrs, 100*naive[:, 1], "o--", c="C0", alpha=.5, label="naive (top-5)"); ax.plot(snrs, 100*adaptive[:, 1], "s--", c="C1", alpha=.5, label="adaptive (top-5)")
ax.axhline(100/len(keep), c="gray", ls=":"); ax.invert_xaxis(); ax.set_xlabel("SNR (dB)  ← more noise"); ax.set_ylabel("accuracy (%)"); ax.legend(fontsize=8); plt.show()
print("SNR  naive top-1/top-5     adaptive top-1/top-5")
for s_, a_, b_ in zip(snrs, naive, adaptive): print(f"{s_:4d}  {a_[0]:.0%} / {a_[1]:.0%}        {b_[0]:.0%} / {b_[1]:.0%}")

# %% [markdown]
# ### Defence 2 — limit the microphone bandwidth *(run it, discuss the plot; ≈5 min)*
# Some platforms restrict what an app can capture. Simulate low-pass filtering at several cut-offs. (Notice that even a mild 10 kHz cut-off hurts a *naive* attacker — a classifier trained on one condition is brittle to **any** mismatch, the same lesson as Lab 4.)

# %%
cuts = [10000, 4000, 2000, 1000, 500, 250]
bw = np.array([run(lambda c, r, f=f: lowpass(c, f)) for f in cuts])
bw_ad = np.array([run(lambda c, r, f=f: lowpass(c, f), lambda c, r, f=f: lowpass(c, f)) for f in cuts])
fig, ax = plt.subplots(figsize=(7, 3.5))
ax.plot(cuts, 100*bw[:, 0], "o-", label="naive top-1"); ax.plot(cuts, 100*bw_ad[:, 0], "s-", label="adaptive top-1")
ax.set_xscale("log"); ax.invert_xaxis(); ax.set_xlabel("low-pass cut-off (Hz)"); ax.set_ylabel("top-1 accuracy (%)"); ax.legend(); plt.show()
print("cutoff  naive top-1/top-5     adaptive top-1/top-5")
for f_, a_, b_ in zip(cuts, bw, bw_ad): print(f"{f_:6d}  {a_[0]:.0%} / {a_[1]:.0%}        {b_[0]:.0%} / {b_[1]:.0%}")

# %% [markdown]
# ### Discussion — which defences would you actually deploy?
# | Defence | Helps against | Weakness |
# |---|---|---|
# | Masking noise | naive attacker | adaptive training recovers some accuracy; annoying to users |
# | Restrict mic access / bandwidth | remote apps and calls | the key sounds are *low* frequency — filtering is not a cure (see plot); also breaks legitimate use |
# | Randomise or redesign the on-screen keyboard (virtual keyboards) | letter-to-position mapping | usability cost |
# | Dampened / silent keys; touch-to-pay PIN pads with sound off | all acoustic channels | not available everywhere |
# | Don't type secrets near an open mic (calls, meetings); use a password manager / autofill / biometrics | the actual high-value targets | user behaviour |
# | Detect: monitor which apps hold the mic; OS indicators | covert recording | does not stop a meeting participant |
#
# **Rules of the lab.** Everything we ran here was on our own data for defensive learning. Recording someone's typing without consent is unlawful in many jurisdictions and against any reasonable corporate policy.

# %% [markdown]
# ---
# ---
# <a id='lab7'></a>
# ## ▶ LAB 7  ·  `04_words_to_sentences.ipynb` (★★★★ hardest)

# %% [markdown]
# # Lab 7 — From letters to words to sentences (≈30 min)
# **Pipeline step:** *per-key top-k guesses → dictionary (Trie) → language model → sentence*
#
# The classifier is only ~55–60% right per key (top-1), but English is highly redundant. We exploit that.
#
# > **How the test sentences are made.** We do not have long typing recordings with labels, so we *simulate* a typed sentence by picking one random clip per letter from the dataset. Those clips are **removed from the training set first** — the model has never seen them. This models an attacker who has profiled the victim's device (protocol A/C of Lab 4), **not** a cold-start attacker.

# %% [markdown]
# ### Helper functions for Lab 7
# Defined here, then used in the cells below.

# %%
class Trie:
    def __init__(self):
        self.root = {}

    def insert(self, w):
        n = self.root
        for ch in w:
            n = n.setdefault(ch, {})
        n["$"] = True

    def search(self, cand_lists):
        """All dictionary words whose i-th letter is in cand_lists[i]."""
        out = []

        def dfs(node, d, acc):
            if d == len(cand_lists):
                if "$" in node:
                    out.append(acc)
                return
            for ch in cand_lists[d]:
                if ch in node:
                    dfs(node[ch], d + 1, acc + ch)
        dfs(self.root, 0, "")
        return out


class LanguageModel:
    """Tiny Brown-corpus unigram+bigram model (no downloads, no GPU)."""

    def __init__(self):
        import json
        self.uni = json.load(open(os.path.join(DATA, "lm_unigram.json")))
        self.bi = json.load(open(os.path.join(DATA, "lm_bigram.json")))
        self.total = sum(self.uni.values())

    def words(self):
        return list(self.uni)

    def logp_word(self, w, prev=None):
        pu = (self.uni.get(w, 0) + 0.5) / self.total
        if prev is None:
            return float(np.log(pu))
        c_prev = self.uni.get(prev, 0)
        pb = self.bi.get(f"{prev} {w}", 0) / c_prev if c_prev else 0.0
        return float(np.log(0.7 * pb + 0.3 * pu))     # interpolation

    def score(self, sentence):
        ws = sentence.split()
        return sum(self.logp_word(w, ws[i - 1] if i else None) for i, w in enumerate(ws))

# %%
import warnings; warnings.filterwarnings("ignore")
import numpy as np, matplotlib.pyplot as plt, librosa.display
from IPython.display import Audio, display

plt.rcParams.update({"figure.dpi": 110, "font.size": 10})
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
import itertools
clips, letters, sessions = load_clips(); X = feature_matrix(clips)
print("letters in dataset:", "".join(sorted(set(letters))))

# %% [markdown]
# ### 4.1 The dictionary Trie and the language model

# %%
lm = LanguageModel(); trie = Trie()
for w in lm.words(): trie.insert(w)
print(len(lm.words()), "words in the dictionary")
# Toy example: suppose for 4 keystrokes the classifier's top-3 lists were...
print(trie.search([list("sgk"), list("tpr"), list("oae"), list("pnt")]))

# %% [markdown]
# ### Exercise 14 — rank candidate sentences
# Given a list of per-word candidate lists, return all sentences sorted best-first. Score each sentence as
#
# `score = lam · lm.score(sentence)  +  Σ acoustic scores of its words` (the acoustic part is optional: `ac[(position, word)]`, used from 4.3 onward).
#
# `itertools.product` enumerates the combinations; `lm.score(sentence)` is a log-probability (higher = more plausible).

# %%
# SOLUTION
def rank_sentences(word_cands, ac=None, lam=1.0):
    scored = []
    for combo in itertools.product(*word_cands):
        s = " ".join(combo)
        score = lam * lm.score(s)
        if ac: score += sum(ac[(i, w)] for i, w in enumerate(combo))
        scored.append((s, score))
    return sorted(scored, key=lambda t: -t[1])

# %%
print(rank_sentences([["every","evey"], ["street","sweet","steer"]])[:3])

# %% [markdown]
# ### 4.2 The full attack on one sentence

# %%
SENT = "every street needs power"
rng = np.random.default_rng(1)

def attack(sentence, k, n_cand=8, rng=rng, verbose=False):
    # 1) pick held-out clips for each typed letter
    held, seq = set(), []
    for L in sentence.replace(" ", ""):
        pool = [i for i in np.where(letters == L)[0] if i not in held]
        i = int(rng.choice(pool)); held.add(i); seq.append(i)
    train_idx = np.array([i for i in range(len(letters)) if i not in held])
    model = make_pipeline(StandardScaler(), RandomForestClassifier(300, random_state=0)).fit(X[train_idx], letters[train_idx])
    proba = model.predict_proba(X[seq]); cl = model.classes_
    topk = [list(cl[np.argsort(p)[::-1][:k]]) for p in proba]
    # 2) split per word and query the Trie
    word_cands, pos = [], 0
    for w in sentence.split():
        c = trie.search(topk[pos:pos + len(w)]); pos += len(w)
        c = sorted(set(c) | set() , key=lambda x: -lm.logp_word(x))[:n_cand]       # most frequent first
        word_cands.append(c)
    key_hits = np.mean([sentence.replace(" ", "")[i] in topk[i] for i in range(len(topk))])
    word_ok = [w in c for w, c in zip(sentence.split(), word_cands)]
    ranked = rank_sentences(word_cands) if all(word_cands) else []
    if verbose:
        print("per-key top-%d hit rate: %.0f%%" % (k, 100*key_hits))
        for w, c in zip(sentence.split(), word_cands): print(f"  {w:8s} -> {c}")
        for r, (s, sc) in enumerate(ranked[:5], 1): print(f"  #{r} {s}  ({sc:.1f})" + ("   <-- TRUE" if s == sentence else ""))
    return key_hits, word_ok, ranked

_ = attack(SENT, k=5, verbose=True)

# %% [markdown]
# ### 4.3 The hard top-k Trie is brittle
# With `k=5` the per-key hit rate is ~90%, yet whole words are often **missing**: a single keystroke whose true letter fell outside its top-5 list kills the Trie match (look for empty `[]` lists above). Throwing away the classifier's *confidence* is wasteful.
#
# ### Exercise 15 — soft decoding
# Instead of hard lists, score **every dictionary word of the right length** by how likely the classifier thinks it is:
#
# `acoustic_score(word) = Σ_i log P(letter_i | clip_i)`
#
# and combine it with the language model: `score = acoustic + λ · log P_LM`, at word level to pick candidates and again at sentence level in `rank_sentences`. Implement `acoustic_score`.

# %%
# SOLUTION
def acoustic_score(logP, word, class_index, floor=np.log(1e-3)):
    return float(sum(logP[i, class_index[ch]] if ch in class_index else floor for i, ch in enumerate(word)))

# %%
by_len = {}
for w in lm.words(): by_len.setdefault(len(w), []).append(w)

def attack_soft(sentence, n_cand=8, lam=0.3, rng=None, verbose=False):
    rng = rng or np.random.default_rng(0)
    held, seq = set(), []
    for L in sentence.replace(" ", ""):
        pool = [i for i in np.where(letters == L)[0] if i not in held]
        i = int(rng.choice(pool)); held.add(i); seq.append(i)
    train_idx = np.array([i for i in range(len(letters)) if i not in held])
    model = make_pipeline(StandardScaler(), RandomForestClassifier(300, random_state=0)).fit(X[train_idx], letters[train_idx])
    logP = np.log(model.predict_proba(X[seq]) + 1e-3); ci = {c: i for i, c in enumerate(model.classes_)}
    word_cands, pos, ac_map = [], 0, {}
    for wi, w in enumerate(sentence.split()):
        n_ = len(w); sc = []
        for cw in by_len[n_]:
            ac = acoustic_score(logP[pos:pos + n_], cw, ci); ac_map[(wi, cw)] = ac
            sc.append((cw, ac + lam * lm.logp_word(cw)))
        pos += n_
        word_cands.append([c for c, _ in sorted(sc, key=lambda t: -t[1])[:n_cand]])
    ranked = rank_sentences(word_cands, ac=ac_map, lam=lam)
    word_ok = [w in c for w, c in zip(sentence.split(), word_cands)]
    if verbose:
        for w, c in zip(sentence.split(), word_cands): print(f"  {w:8s} -> {c[:5]}")
        for r, (s_, sc_) in enumerate(ranked[:3], 1): print(f"  #{r} {s_}" + ("   <-- TRUE" if s_ == sentence else ""))
    return word_ok, ranked

_ = attack_soft(SENT, verbose=True)

# %% [markdown]
# ### 4.4 Hard vs soft — many random draws
# Each repeat re-draws the held-out clips and retrains (≈2 min). **Closed-vocabulary assumption:** every true word is in the 20,000-word dictionary — a real attacker would also face names, typos and passwords.

# %%
SENTS = ["every street needs power", "seven green towers", "never post ten reports"]
R = 4; res = {}
for k in [1, 3, 5]:
    w, s_ = [], []
    for sent in SENTS:
        for r in range(R):
            _, wok, ranked = attack(sent, k, rng=np.random.default_rng(100 * k + r)); w += wok; s_.append(bool(ranked) and ranked[0][0] == sent)
    res[f"hard top-{k}"] = (np.mean(w), np.mean(s_))
w, s_ = [], []
for sent in SENTS:
    for r in range(R):
        wok, ranked = attack_soft(sent, rng=np.random.default_rng(r)); w += wok; s_.append(ranked[0][0] == sent)
res["soft decoding"] = (np.mean(w), np.mean(s_))
fig, ax = plt.subplots(figsize=(7, 3.6)); xs = np.arange(len(res))
ax.bar(xs - .2, [100 * v[0] for v in res.values()], .4, label="true word in candidate list"); ax.bar(xs + .2, [100 * v[1] for v in res.values()], .4, label="whole sentence ranked #1")
ax.set_xticks(xs); ax.set_xticklabels(res.keys()); ax.set_ylabel("%"); ax.legend(); plt.show()
for k_, v in res.items(): print(f"{k_:14s} words {v[0]:.0%}   sentences {v[1]:.0%}")

# %% [markdown]
# **Takeaways**
# 1. *Keep the uncertainty.* Hard decisions at each stage compound errors; probabilities flow end-to-end.
# 2. Notice the gap between **per-key**, **per-word** and **per-sentence** success. Which would a security team care about for a **password** (no dictionary, no language model)? For a *chat message*?
# 3. The language model does a lot of the work — which is why free-text and random passwords are very different threat models.
#
# *Limits of this demo:* a 16-letter alphabet, a small LM, clips from the profiled device, and no real inter-key timing. Treat the numbers as an illustration of the mechanism, not as an attack success rate.
