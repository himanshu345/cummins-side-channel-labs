# Acoustic Side-Channel Attacks — Hands-On Lab

Build the acoustic attacks yourself: recover **keypad numbers, typed words and sentences** from
sound, learn to **judge whether a result is real**, and test **defences**. Everything runs in
Python/Jupyter against the recordings included in `data/` — no extra downloads.

## Setup (any OS)

```bash
cd lab
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
jupyter notebook 00_setup_check.ipynb
```

Run **Lab 0** first — if every cell prints ✅, you're ready. Each later notebook has cells with
`...` **TODO stubs** for you to complete. Your instructor has the worked solutions.

## The notebooks

Two ways to work:

- **One notebook, easiest → hardest:** open **`Cummins_ASCA_All_Labs.ipynb`** and run top to
  bottom. This is the recommended path for the live session (it starts with the DTMF attack, so
  everyone succeeds early).
- **Or the separate notebooks `00–08`** (original numbering):

| Notebook | What you do | Level |
|---|---|---|
| **00** Setup check | confirm your environment works | — |
| **01** Signal & segmentation | spectrogram, band-pass, find each keystroke | ★★ |
| **02** Features & classifier | 3 vs 16 features, k-NN vs random forest | ★★ |
| **03** Evaluation pitfalls | pooled vs cross-session vs calibration | ★★★ |
| **04** Words → sentences | Trie + language model, hard vs soft decoding | ★★★★ |
| **05** Defences | noise & bandwidth vs a naive / adaptive attacker | ★★★ |
| **06** Keypad tones (DTMF) | read a dialled number — no ML needed | ★ |
| **07** Beyond keyboards | app & CPU-instruction emanations; "is 100% meaningful?" | ★★★ |
| **08** Bonus — record your own | capture and attack your own typing (needs a mic) | — |

## What's in the folder

```
lab/
├── 00_setup_check.ipynb … 08_bonus_record_your_own.ipynb   the labs (TODO stubs)
├── Cummins_ASCA_All_Labs.ipynb   all labs in one notebook, easiest → hardest
├── asca_lib.py                   shared helper code the notebooks import
├── record_keystrokes.py          records your own keystrokes (Lab 8, needs sounddevice)
├── requirements.txt
└── data/                         the recordings: keystroke clips, sentences, DTMF, emanations
```

## Ground rules
Record only your **own** typing, or with explicit consent. These labs use provided data or your
own recordings. Only ever test systems and people you are authorised to.
