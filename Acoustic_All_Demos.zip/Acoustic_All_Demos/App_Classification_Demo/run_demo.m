function run_demo()
%% App Classification - live demo
% Identifies which smartphone app is running (Amazon / Facebook / LinkedIn /
% YouTube / Zomato) from a recording of the phone's acoustic emanations.
%
% Re-implements ../App Classification/all_Instructions.m without the
% interactive Classification Learner steps. The model is retrained from the
% recordings on every run (rng fixed, so the result is reproducible), which
% keeps this folder small.
%
% Requirements: MATLAB + Audio Toolbox + Statistics and Machine Learning Toolbox
%
% Just run:  >> run_demo

clc
% Resolve this file's folder whether run whole, by section, or by selection.
here = fileparts(mfilename('fullpath'));          % set when run as a whole file
if isempty(here)                                  % run by section/selection: locate it
    for c = [string(pwd), fullfile(pwd,"App_Classification_Demo"), fileparts(which('run_demo'))]
        if c ~= "" && isfolder(fullfile(c,'recordings')); here = char(c); break; end
    end
end
recDir = fullfile(here,'recordings');
outDir = fullfile(here,'output');
assert(isfolder(recDir), 'run_demo:noRecDir', ...
    ['recordings not found (here = "%s").\n' ...
     'In the MATLAB terminal, cd into the App_Classification_Demo folder, then rerun.'], here);
if ~exist(outDir,'dir'); mkdir(outDir); end

fprintf('App Classification demo\n=======================\n');
fprintf('Recordings: %s\n\n', recDir);

%% 1. Datastore, label = app name from the file name
aDS        = audioDatastore(recDir);
[~,fn]     = fileparts(aDS.Files);
aDS.Labels = categorical(fn);
fprintf('Apps: %s\n\n', strjoin(string(categories(aDS.Labels)),', '));

%% 2. Feature extraction (all audioFeatureExtractor features enabled)
fs  = 44100;
aFE = audioFeatureExtractor('SampleRate',fs, ...
        'Window',rectwin(round(0.03*fs)), ...
        'OverlapLength',round(0.002*fs));
sw = fields(info(aFE,'all'));
cellfun(@(s) aFE.set(s,true), sw);

fprintf('Extracting features from %d recordings ...\n', numel(aDS.Files));
% force mono (some decoders return stereo, which makes extract() 3-D)
tf     = transform(aDS, @(a){extract(aFE, mean(a,2))});
featAll = readall(tf);

N = cellfun(@(x) size(x,1), featAll);       % analysis windows per file
T = repelem(aDS.Labels, N);                 % window-level labels
X = cat(1, featAll{:});                     % [windows x 862] feature matrix
XX = mean(X,2);                             % single feature per window (as in original)
fprintf('  %d analysis windows, %d features -> collapsed to mean feature\n', ...
        size(X,1), size(X,2));
fprintf('  windows per app: %s\n\n', mat2str(N(:)'));

%% 3. Train the bagged-tree ensemble (random forest)
rng('default')
tmpl = templateTree('Reproducible',true);
Mdl  = fitcensemble(XX, T, 'Method','Bag', 'Learners', tmpl);

%% 4a. Resubstitution result (matches the saved figure in ../App Classification)
yhat = predict(Mdl, XX);
accRe = mean(yhat==T)*100;

%% 4b. Honest estimate: per-recording leave-one-out
%     (train on 4 apps' windows... not meaningful for classification;
%      instead hold out 30% of each app's windows)
cv = cvpartition(T,'HoldOut',0.30);
MdlCv = fitcensemble(XX(training(cv)), T(training(cv)), 'Method','Bag', ...
                     'Learners', templateTree('Reproducible',true));
yCv   = predict(MdlCv, XX(test(cv)));
accCv = mean(yCv==T(test(cv)))*100;

%% 5. Report
fprintf('Resubstitution accuracy (train == test) : %.2f %%  (%d/%d windows)\n', ...
        accRe, sum(yhat==T), numel(T));

% per-recording majority vote (one prediction per app recording)
fprintf('Per-recording majority vote:\n');
tag  = ["WRONG" "correct"];                 % indexed by (isCorrect)+1
idx0 = [0; cumsum(N)];
for i = 1:numel(aDS.Files)
    seg  = yhat(idx0(i)+1 : idx0(i+1));
    vote = mode(seg);
    fprintf('  %-9s -> %-9s  (%s)\n', string(aDS.Labels(i)), string(vote), ...
            tag((vote==aDS.Labels(i))+1));
end

figure('Position',[100 100 720 620]);
confusionchart(T, yhat, 'Title', ...
    sprintf('App Classification (resubstitution): %.2f %%', accRe));
exportgraphics(gcf, fullfile(outDir,'confusion_matrix.png'), 'Resolution', 150);
fprintf('\nConfusion matrix saved to output/confusion_matrix.png\n');
end
