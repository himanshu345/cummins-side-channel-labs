function run_full_demo()
%% App Classification - FULL pipeline demo   (862 features -> MRMR -> SVM)
% ---------------------------------------------------------------------------
% The classroom version: the WHOLE pipeline the way the thesis did it
% (../App Classification/all_Instructions.m, i.e. MathWorks' "Audio Feature
% Selection for Machine Learning Tasks" example) - nothing collapsed.
%
%   STEP 1  the recordings
%   STEP 2  what "862 features per 30 ms window" actually is
%   STEP 3  extract that for every clip  ->  a [windows x 862] matrix
%   STEP 4  RANK all 862 features by MRMR (fscmrmr), keep the best 8
%   STEP 5  TRAIN a bagged-tree ensemble on those 8 features
%   STEP 6  classify each window, then majority-vote per recording
%
% Apps: Amazon / Facebook / LinkedIn / YouTube / Zomato   (recordings/*.wav)
%
% Requirements: MATLAB + Audio Toolbox + Statistics and Machine Learning Toolbox
%
% Run whole:    >> run_full_demo
% Step through: "Run Section" (Ctrl+Enter) each %% block IN ORDER, starting with
%               section 0 -- it addpaths this folder (for the uniqueFeatureName
%               helper) and defines the constants the later sections need.
% All plots are also written to output/*.png, so it works with no display.
%
% NOTE: there is ONE recording per app and no held-out set, so the accuracy
%   below is RESUBSTITUTION - the model graded on its own training windows,
%   the same figure the source project reports. It demonstrates the pipeline,
%   not a cross-session generalisation result.
% ---------------------------------------------------------------------------

clc; close all

%% ================================================================
%  0. locate the folder + constants
%  ================================================================
here = fileparts(mfilename('fullpath'));
if isempty(here)
    for c = [string(pwd), fullfile(pwd,"App_Classification_Demo"), fileparts(which('run_full_demo'))]
        if c ~= "" && isfolder(fullfile(c,'recordings')); here = char(c); break; end
    end
end
if ~isempty(here); addpath(here); end   % so uniqueFeatureName.m is found even
                                        % when a %% section is run on its own
recDir = fullfile(here,'recordings');
outDir = fullfile(here,'output');
assert(isfolder(recDir), 'run_full_demo:noData', ...
    'recordings/ not found under "%s". cd into App_Classification_Demo and rerun.', here);
if ~isfolder(outDir); mkdir(outDir); end

FS   = 44100;   % feature-extractor sample rate
KSEL = 8;       % how many features MRMR keeps (the thesis scripts use 8)

fprintf('==========================================================\n');
fprintf(' APP CLASSIFICATION - full pipeline    (%s)\n', here);
fprintf('==========================================================\n\n');

%% ================================================================
%  1. the recordings
%  ================================================================
aDS        = audioDatastore(recDir);
[~,fn]     = fileparts(aDS.Files);
aDS.Labels = categorical(fn);
apps       = string(categories(aDS.Labels));
chance     = 100/numel(apps);

fprintf('STEP 1   the recordings\n');
fprintf('-----------------------\n');
fprintf('  %d apps : %s\n', numel(apps), strjoin(apps,', '));
fprintf('  1 recording per app, ~32 s each. guessing blindly = %.0f%%.\n\n', chance);

%% ================================================================
%  2. what "862 features per 30 ms window" is
%  ================================================================
fprintf('STEP 2   the feature extractor\n');
fprintf('-----------------------------\n');
aFE = audioFeatureExtractor('SampleRate',FS, ...
        'Window',rectwin(round(0.03*FS)), ...       % 30 ms rectangular window
        'OverlapLength',round(0.002*FS));           % 2 ms hop
cellfun(@(s) aFE.set(s,true), fields(info(aFE,'all')));   % enable EVERY feature

fmap  = info(aFE);                                  % feature -> column index(es)
fname = uniqueFeatureName(fmap);                    % one name per column
grp   = fieldnames(fmap);
fprintf('  window : 30 ms rectangular, 2 ms hop\n');
fprintf('  %d feature groups  ->  %d numbers per analysis window:\n', numel(grp), numel(fname));
for g = 1:numel(grp)
    cc = fmap.(grp{g});
    fprintf('    %-22s cols %4d..%-4d (%d)\n', grp{g}, cc(1), cc(end), numel(cc));
end

F1 = extract(aFE, mean(audioread(aDS.Files{1}),2));
fprintf('\n  %s.wav  ->  %d windows x %d features\n\n', ...
        string(aDS.Labels(1)), size(F1,1), size(F1,2));

%% ================================================================
%  3. feature matrix for every recording
%  ================================================================
fprintf('STEP 3   extract features from all %d recordings  (~1-2 min)\n', numel(aDS.Files));
fprintf('----------------------------------------------------------\n');
tf      = transform(aDS, @(a){extract(aFE, mean(a,2))});
featAll = readall(tf);
N = cellfun(@(x) size(x,1), featAll);              % windows per recording
T = repelem(aDS.Labels, N);                        % window-level labels
X = cat(1, featAll{:});                            % [windows x 862]
fprintf('  X is %s   (windows per app: %s)\n\n', mat2str(size(X)), mat2str(N(:).'));

%% ================================================================
%  4. MRMR feature selection  (fscmrmr)
%  ================================================================
fprintf('STEP 4   rank the 862 features by MRMR, keep the best %d\n', KSEL);
fprintf('------------------------------------------------------\n');
rng('default')
[rank, scores] = fscmrmr(X, T);                    % rank(1) = most useful column
sel = rank(1:KSEL);

fprintf('  MRMR = Minimum Redundancy Maximum Relevance:\n');
fprintf('    maximise  mutual information(feature ; app label)      [relevance]\n');
fprintf('    minimise  mutual information(feature ; already-picked) [redundancy]\n');
fprintf('    -> the top %d are individually informative AND not copies of each other\n\n', KSEL);
fprintf('  %-4s %-24s %-8s %s\n', 'col', 'feature', 'score', '');
for j = 1:KSEL
    fprintf('  %-4d %-24s %.4f\n', sel(j), fname{sel(j)}, scores(sel(j)));
end

f = figure('Visible','off','Position',[70 70 1000 420]);
tl = tiledlayout(f,1,2,'TileSpacing','compact','Padding','compact');
title(tl,'MRMR feature ranking')
nexttile; bar(scores); grid on
title('(a) score of all 862 features'); xlabel('feature column'); ylabel('MRMR score')
nexttile
topN = 25;
bar(scores(rank(1:topN))); grid on
set(gca,'XTick',1:topN,'XTickLabel',fname(rank(1:topN)),'XTickLabelRotation',55,'FontSize',7);
title(sprintf('(b) top %d, ranked  (first %d kept)', topN, KSEL)); ylabel('MRMR score')
hold on; bar(1:KSEL, scores(rank(1:KSEL)), 'FaceColor', [0.85 0.33 0.10]);
exportgraphics(f, fullfile(outDir,'01_mrmr_scores.png'), 'Resolution',140);
fprintf('\n  -> output/01_mrmr_scores.png\n\n');

%% ================================================================
%  5. train a classifier on the selected features
%  ================================================================
fprintf('STEP 5   train  (bagged-tree ensemble on the %d selected features)\n', KSEL);
fprintf('---------------------------------------------------------------\n');
Xsel = X(:,sel);
rng('default')
Mdl  = fitcensemble(Xsel, T, 'Method','Bag', 'Learners', templateTree('Reproducible',true));
fprintf('  model : bagged decision trees (random forest), 100 trees, majority vote\n');
fprintf('  input : the %d MRMR-selected features\n', KSEL);
fprintf('  (a linear SVM on 8 features underfits badly here - ~30%%; a Gaussian-\n');
fprintf('   kernel SVM manages ~80%%. Trees are used to match run_demo.m.)\n\n');

%% ================================================================
%  6. classify: per window, then majority vote per recording
%  ================================================================
fprintf('STEP 6   accuracy\n');
fprintf('----------------\n');
yhat = predict(Mdl, Xsel);
accW = 100*mean(yhat==T);
fprintf('  per-window accuracy (resubstitution) : %.1f %%  (%d/%d windows)\n\n', ...
        accW, sum(yhat==T), numel(T));

fprintf('  per-recording majority vote:\n');
tag  = ["WRONG" "correct"];
idx0 = [0; cumsum(N)];
nOK  = 0;
for i = 1:numel(aDS.Files)
    vote = mode(yhat(idx0(i)+1 : idx0(i+1)));
    ok   = (vote == aDS.Labels(i));  nOK = nOK + ok;
    fprintf('    %-9s -> %-9s  (%s)\n', string(aDS.Labels(i)), string(vote), tag(ok+1));
end
fprintf('  -> %d/%d recordings correct\n', nOK, numel(aDS.Files));

h = figure('Visible','off','Position',[70 70 640 560]);
confusionchart(T, yhat, 'RowSummary','row-normalized', ...
    'Title', sprintf('App Classification (resubstitution): %.1f%% windows,  %d/%d recordings', ...
                     accW, nOK, numel(aDS.Files)));
exportgraphics(h, fullfile(outDir,'02_confusion_matrix.png'), 'Resolution',140);
fprintf('  -> output/02_confusion_matrix.png\n');

%% ================================================================
%  7. recap
%  ================================================================
fprintf('\n==========================================================\n');
fprintf(' RECAP\n');
fprintf('==========================================================\n');
fprintf(' FEATURES  audioFeatureExtractor, 30 ms window -> 862 numbers / window\n');
fprintf(' SELECT    fscmrmr ranks all 862 by relevance minus redundancy;\n');
fprintf('           keep the top %d  (%s)\n', KSEL, strjoin(string(fname(sel)).', ', '));
fprintf(' MODEL     bagged-tree ensemble (random forest) on those %d features\n', KSEL);
fprintf(' RESULT    %.1f%% per window,  %d/%d recordings  (resubstitution)\n', accW, nOK, numel(aDS.Files));
fprintf(' FILES     output/01_mrmr_scores.png\n');
fprintf('           output/02_confusion_matrix.png\n');
fprintf('==========================================================\n');
end
