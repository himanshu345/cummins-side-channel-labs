# App Classification — Demo

Identifies which **smartphone app** is running (Amazon / Facebook / LinkedIn /
YouTube / Zomato) from a recording of the phone's **acoustic emanations**.

Trimmed, non-interactive copy of `../App Classification/all_Instructions.m`.

## Requirements

MATLAB with:
- Audio Toolbox
- Statistics and Machine Learning Toolbox

## Two scripts

| Script | Method |
|--------|--------|
| **`run_demo`**      | quick version — 862 features → `mean(X,2)` → bagged trees. Prints ~99.8 % (resub). |
| **`run_full_demo`** | the **teaching version** — the pipeline the thesis actually used: 862 features → **MRMR feature selection (`fscmrmr`) → keep the top 8 → ECOC linear SVM** → per-recording majority vote. |

```matlab
>> cd App_Classification_Demo
>> run_full_demo        % or: run_demo
```

Self-contained and location-independent. Feature extraction of the 5 recordings
takes ~1–2 min. Plots go to `output/*.png`, so both work headless.

## `run_full_demo` — step by step

1. **STEP 1** the 5 recordings (`recordings/*.wav`, app name = file name).
2. **STEP 2** `audioFeatureExtractor`, 30 ms rectangular window, 2 ms hop, *all*
   features enabled → **862 numbers per analysis window**; prints the
   feature-name → column map (`linearSpectrum0…661`, `mfcc0…12`, `pitch`, …).
3. **STEP 3** run that over every recording → `X` is `[~5878 × 862]`,
   `T` = one app label per window.
4. **STEP 4** `fscmrmr(X, T)` ranks all 862 features by **Minimum Redundancy
   Maximum Relevance** (maximise mutual information with the label, minimise
   mutual information with already-picked features); keep the **top 8**.
   Bar chart → `output/01_mrmr_scores.png`.
5. **STEP 5** `fitcecoc` — a multi-class linear SVM (ECOC one-vs-one) on those
   8 columns, standardised.
6. **STEP 6** classify every window, then `mode()` per recording →
   `output/02_confusion_matrix.png`.

This matches `../App Classification/all_Instructions.m` (itself adapted from
MathWorks' *Audio Feature Selection for Machine Learning Tasks* example);
`fscmrmr` + top-8 + `fitcecoc` is what the thesis scripts
(`cpudr/.../audio_feature_selection_ML*.m`) do.

## Expected output (`run_demo`)

```
Resubstitution accuracy (train == test) : 99.83 %   (5868/5878 windows)
Per-recording majority vote             : 5/5 correct
```

The **99.8 %** figure reproduces the result in
`../App Classification/App Classification Results Confusion Matrix.pdf`
(original: 99.8981 %).

## ⚠️ Important — what this number means

There is **one recording per app** and **no held-out test set**. The reported
accuracy is *resubstitution*: the model is scored on the same overlapping
windows it was trained on, so it largely reflects memorisation, not
generalisation. This holds for `run_full_demo` too — MRMR + SVM on the right
8 features is the correct *pipeline*, but with one recording per app it still
can't be a generalisation estimate.

To get a real number you would need **multiple independent recordings per app**
and a train/test split by recording (or by session).

## Contents

| File | Purpose |
|------|---------|
| `run_demo.m`          | quick demo — `mean(X,2)` + bagged trees |
| `run_full_demo.m`     | teaching demo — 862 features → MRMR top-8 → ECOC SVM |
| `uniqueFeatureName.m` | helper: names the 862 feature columns (own file so the demo can be stepped through) |
| `recordings/*.wav`    | 5 recordings, one per app (mono, ~32 s; converted from the original `.m4a`) |
| `output/`             | generated PNGs |

The trained model is **not** shipped (the saved one in
`../App Classification/workspace variables.mat` is ~100 MB); both scripts
retrain from the recordings.
