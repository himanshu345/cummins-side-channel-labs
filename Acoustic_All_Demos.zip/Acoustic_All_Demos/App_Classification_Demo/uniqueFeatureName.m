function c = uniqueFeatureName(afeInfo)
%UNIQUEFEATURENAME  Unique per-column names for an audioFeatureExtractor output.
%   c = uniqueFeatureName(info(aFE)) returns a cell array with one name per
%   output column, e.g. 'linearSpectrum0'...'linearSpectrum661', 'mfcc0'...,
%   'pitch', 'shortTimeEnergy'.  (From the MathWorks "Audio Feature Selection
%   for Machine Learning Tasks" example; helper for run_full_demo.m.)
a = repelem(fields(afeInfo), structfun(@numel, afeInfo));
b = matlab.lang.makeUniqueStrings(a);
d = find(endsWith(b,"_1"));
c = strrep(b,"_","");
c(d-1) = strcat(c(d-1),"0");
end
