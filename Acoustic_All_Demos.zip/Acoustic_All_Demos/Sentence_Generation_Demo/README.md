# Acoustic Side-Channel Attack — Character → Sentence Demo

Recovers text typed on a **smartphone on-screen keyboard** using only the
phone's **built-in microphone**. Two notebooks, meant to be shown in order:

| Notebook | Shows |
|----------|-------|
| **`1_Character_Classification.ipynb`** | The per-keystroke pipeline: capture → bandpass 200–500 Hz → `find_peaks()` segmentation → 3 features (spectral kurtosis, pitch, short-time energy) → k-NN → **top-5 candidate letters per keystroke**. Target word: **"what"**. |
| **`2_Sentence_Generation.ipynb`** | The same character classifier, then **word + sentence reconstruction**: top-5 letters → Trie word candidates → GPT-2 perplexity ranking → recovered sentence. Target: **"get help online now"**. |

Both are trimmed, path-fixed copies of `../Acoustic_Sentence_Generation/`
(`ASCA_Word_Demo.ipynb` and `ASCA_Sentence_Attack.ipynb`) — the thesis work of
Ashee Jain, MTech, IIT Kanpur, 2025.

## Setup

```bash
cd Sentence_Generation_Demo
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# CPU-only torch (skip if you have a CUDA build):
pip install torch --index-url https://download.pytorch.org/whl/cpu
jupyter lab      # or: jupyter notebook
```

- Python 3.11–3.14 all work (verified on 3.14).
- The notebooks locate their own folder automatically (via `__file__` /
  working directory / its parents), so they run even if Jupyter is launched
  from somewhere else. No paths to edit.
- First run downloads GPT-2 (~500 MB) from HuggingFace — needs internet **once**.
- If `torch`/`transformers` are missing, the notebooks still run and print the
  Trie candidates; only the GPT-2 ranking step is skipped.

## What you'll see (verified output)

**Notebook 1 — "what"**
```
Top-5 accuracy on "what" (same-session): 4/4 = 100%
Trie valid 4-letter words: [... 'weak', 'went', 'what', 'know']
GPT-2 rank 1: what   (perplexity 368.83)   ← RECOVERED ✓
```

**Notebook 2 — "get help online now"**
```
Overall top-5 accuracy: 16/16 = 100%
Trie:  get→{let,len,get,gen,met,men,zen}  help→{help}  online→{online}  now→{wow,hop,how,now,...}
GPT-2 rank 1: "get help online now"   (perplexity 1249.91, 1.8× better than #2)  ← RECOVERED ✓
```

Both notebooks are saved **already executed** — you can scroll through the plots
and results without running anything, then re-run live for the demo.

## Contents

```
1_Character_Classification.ipynb   2_Sentence_Generation.ipynb
requirements.txt
words.txt                          9,884 common English words for the Trie
Recordings/Internal mic/Bottom/
├── Splitted_audios/   305 per-keystroke training clips (≤0.5 s), letters a–z minus b,c,f,h,i,j,l,x
├── Train/             h_b1.wav, i_b1.wav, l_b1.wav — batch recordings, re-segmented
│                      at run time to supply the letters missing from Splitted_audios
└── Words/             what / get / help / online / now .wav — the attack recordings
```

Only the files the two notebooks actually read are included (~15 MB of the
original 545 MB `Recordings/`).

## Important — what the accuracy means

The k-NN's *raw* accuracy is low (~27% 5-fold CV) — but the pipeline only needs
the correct letter in the **top-5**, and because the query clips come from the
**same recording session** as the training clips, top-5 is ~100%. The Trie +
GPT-2 stages then collapse the candidates to one sentence. This is the same
setup (and the same caveat) as the thesis: it demonstrates the attack chain,
not a cross-session generalisation result.

## Changing the target

- Notebook 1: edit `ATTACK_WORD` (needs `Words/<word>.wav`; any letter it uses
  that isn't in `Splitted_audios` also needs `Train/<letter>_b1.wav`).
- Notebook 2: edit `SENTENCE` (one `.wav` per word in `Words/`).
