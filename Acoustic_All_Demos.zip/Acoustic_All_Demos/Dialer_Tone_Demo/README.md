# Dialer-Tone — Demo

Recovers a **dialled phone number from the sound of the phone keypad** (DTMF
tones). Self-contained re-implementation of `../../Dialer_Tone/Prediction.ipynb`.

## Requirements

- Python 3.9+ and **`matplotlib`** (`pip install -r requirements.txt`).
  Everything else is the Python standard library.
- No internet, no dataset download.

## Run

Open **`Dialer_Tone_Demo.ipynb`** in Jupyter and run the cells top to bottom:

```bash
cd Dialer_Tone_Demo
pip install -r requirements.txt
jupyter lab        # or: jupyter notebook
```

The notebook locates its own folder, so it works whatever directory Jupyter is
launched from. It comes **pre-executed** — you can read it through first, then
re-run cell by cell while presenting.

## What the cells cover

1. **DTMF table** — each key = one low + one high frequency.
2. **Load a recording** — `Demo 7.wav` (`1234567890`), plot the waveform.
3. **Goertzel algorithm** — measure energy at one frequency in O(N); sanity check.
4. **Frame + classify** — 40 ms / 10 ms frames, per-frame tone/no-tone + digit,
   plotted over the energy envelope.
5. **Group frames into key presses** — bridge dropouts, keep runs ≥ 70 ms, split
   over-long runs into repeated digits.
6. **Zoom into one keystroke** — bar chart of Goertzel energy at the 7 DTMF
   frequencies; the two red bars are the digit.
7. **`decode()`** — the three steps wrapped up, plus a stdlib `.xlsx` reader for
   the ground truth.
8. **All eight recordings** vs `dataset.xlsx` → **8 / 8**.

## Accuracy

- **8/8** with the `dataset.xlsx` dialling-speed hint (`distance` column).
- **7/8** with no hint (median-length fallback) — only `Demo 7`, dialled slowly,
  needs it, because telling one held key from two fast identical presses is
  genuinely ambiguous from audio.

## Contents

| File | Purpose |
|------|---------|
| `Dialer_Tone_Demo.ipynb` | the demo (run cell by cell) |
| `recordings/Demo 1–8.wav` | 8 recordings of dialled numbers |
| `dataset.xlsx` | ground truth: file → dialling `distance` → number |
| `requirements.txt` | `matplotlib` |

Differences from `../../Dialer_Tone/Prediction.ipynb`: runs locally instead of
Colab/Drive; Goertzel instead of FFT + `scipy.find_peaks`; automatic tone
segmentation instead of a hand-set `height`/`distance` per file; no unused ML
`loaded_model`.
