# Acoustic Side-Channel Attack — Demos

Four self-contained, verified demos. Each folder has its own `README.md` with
setup and expected output.

| Folder | Attack | Recovers | Runs with | Verified result |
|--------|--------|----------|-----------|-----------------|
| **CPU_Doctor_Demo** | CPU acoustic emanations | which **AVR/Arduino instruction** is executing (OR, SUB, ADIW, MUL, ASR, SWAP) | MATLAB + Audio/Signal/DSP/Statistics toolboxes | 12/12 = **100%** |
| **App_Classification_Demo** | phone acoustic emanations | which **smartphone app** is running (Amazon / Facebook / LinkedIn / YouTube / Zomato) | MATLAB + Audio + Statistics toolbox | 99.8% resubstitution (see caveat in its README) |
| **Dialer_Tone_Demo** | phone keypad DTMF tones | the **dialled phone number** | Python + matplotlib (Jupyter notebook) | 8/8 numbers |
| **Sentence_Generation_Demo** | on-screen keyboard keystroke sounds | **typed words / sentences** (k-NN top-5 → Trie → GPT-2) | Python + librosa/scipy/scikit-learn (+ torch/transformers), Jupyter notebooks | "what" and "get help online now" both recovered |

## Suggested demo order

1. **CPU_Doctor_Demo** — simplest: sound in → instruction out, 100%. (`run_demo.m`)
2. **App_Classification_Demo** — same idea, one level up (whole app from its sound). (`run_demo.m`)
3. **Dialer_Tone_Demo** — a concrete real-world target (phone numbers). Open
   `Dialer_Tone_Demo.ipynb` and step through the cells.
4. **Sentence_Generation_Demo** — the full chain: characters → words → sentence.
   Run `1_Character_Classification.ipynb` first, then `2_Sentence_Generation.ipynb`.

The MATLAB demos run with `cd <folder>` then `run_demo`. The notebooks locate
their own folder, so Jupyter can be launched from anywhere. All the notebooks
ship pre-executed — read them through, then re-run cell by cell while presenting.

## Source

Trimmed from the material in `../` (`m files/cpudr/`, `App Classification/`,
`Dialer_Tone/`, `Acoustic_Sentence_Generation/`). Each demo copies only the
files it needs and fixes hard-coded / Colab paths to run locally.
