function Ltn = splMeterEnvelope(x, fs)
%SPLMETERENVELOPE  loudness-vs-time (dB), "Fast" weighting, mean removed.
%  Helper for run_full_demo.m.
spl = splMeter('TimeWeighting','Fast','SampleRate',fs,'Bandwidth','Full band');
Lt  = spl(x);  release(spl);
Ltn = Lt - mean(Lt);
end
