function [X,y] = extractFeatures(ds, fs, nBlock, nFeat)
%EXTRACTFEATURES  every clip in datastore ds -> a row of nFeat features.
%  Feature = first nFeat bins of the PSD of the loudness envelope of one
%  1024-sample block (identical maths to run_demo.m / CPU_Dr_PSD_Lt.m).
%  Helper for run_full_demo.m.
X = zeros(numel(ds.Files), nFeat);
for i = 1:numel(ds.Files)
    a  = mean(audioread(ds.Files{i}), 2);           % mono
    b0 = (nBlock-1)*1024 + 1;
    x  = a(b0 : b0+1023);                           % the nBlock-th 1024-sample block
    Ltn = splMeterEnvelope(x, fs);
    X(i,:) = psdFeature(Ltn, fs, nFeat);
end
y = ds.Labels;
end
