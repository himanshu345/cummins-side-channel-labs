function run_demo()
%% CPU Doctor - live demo
% Recognises which AVR/Arduino instruction is running purely from the sound
% it makes. Uses the pre-trained ensemble-SVM stored in PSD_Lt.mat.
%
% Requirements: MATLAB + Audio Toolbox + Signal Processing Toolbox
%               + DSP System Toolbox + Statistics and Machine Learning Toolbox
%
% Just run:  >> run_demo
%
% Everything is resolved relative to this file, so the folder can be moved
% anywhere.

clc
% Resolve this file's folder whether run whole, by section, or by selection.
here = fileparts(mfilename('fullpath'));          % set when run as a whole file
if isempty(here)                                  % run by section/selection: locate it
    for c = [string(pwd), fullfile(pwd,"CPU_Doctor_Demo"), fileparts(which('run_demo'))]
        if c ~= "" && isfolder(fullfile(c,'test_recordings')); here = char(c); break; end
    end
end
testDir = fullfile(here,'test_recordings');
outDir  = fullfile(here,'output');
assert(isfolder(testDir), 'run_demo:noTestDir', ...
    ['test_recordings not found (here = "%s").\n' ...
     'In the MATLAB terminal, cd into the CPU_Doctor_Demo folder, then rerun.'], here);
if ~exist(outDir,'dir'); mkdir(outDir); end

fprintf('CPU Doctor demo\n===============\n');
fprintf('Test recordings: %s\n\n', testDir);

%% 1. Load the test recordings, label = instruction name in the file name
ADS = audioDatastore(testDir,'IncludeSubfolders',true);
[~,fn]     = fileparts(ADS.Files);
ADS.Labels = extractBefore(fn," (");
fprintf('Loaded %d recordings: %s\n\n', numel(ADS.Files), ...
        strjoin(unique(string(ADS.Labels)),', '));

%% 2. Feature extraction: PSD of the time-weighted sound level L_t
fs  = 44.1e3;
SPL = splMeter('TimeWeighting','Fast','SampleRate',fs,'Bandwidth','Full band');
PSD = zeros(numel(ADS.Files),7);
for i = 1:numel(ADS.Files)
    data = dsp.AudioFileReader(ADS.Files{i});
    for j = 1:7
        x = mean(data(),2);          % skip first frames, keep the 7th
    end
    Lt  = SPL(x(:,1));
    Ltn = Lt - mean(Lt);
    pxx = periodogram(Ltn,[],[],"centered","psd",fs);
    PSD(i,:) = pxx(1:7).';            % first 7 PSD bins = the feature vector
    release(data)
end
release(SPL)

% the trained model expects predictor columns named Var1..Var7
featureTableTest            = array2table(PSD, 'VariableNames', compose("Var%d",1:7));
featureTableTest.ActivityID = ADS.Labels;

%% 3. Predict with the trained model
S = load(fullfile(here,'PSD_Lt.mat'),'trainedELSVMModel');
[yfit,~] = S.trainedELSVMModel.predictFcn(featureTableTest);

%% 4. Results
ytrue = categorical(string(ADS.Labels));
ypred = categorical(string(yfit));
acc   = mean(ytrue == ypred) * 100;

fprintf('\nPredictions\n-----------\n');
disp(table(string(ytrue), string(ypred), ytrue==ypred, ...
     'VariableNames', {'Actual','Predicted','Correct'}))
fprintf('Accuracy: %.1f %%  (%d / %d correct)\n', acc, sum(ytrue==ypred), numel(ytrue));

figure('Position',[100 100 700 600]);
confusionchart(ytrue, ypred, ...
    'Title', sprintf('CPU Doctor - Arduino instruction recognition: %.1f %%', acc), ...
    'RowSummary','row-normalized');
exportgraphics(gcf, fullfile(outDir,'confusion_matrix.png'), 'Resolution', 150);
fprintf('\nConfusion matrix saved to output/confusion_matrix.png\n');
end
