function lab = labelsFromFiles(files)
%LABELSFROMFILES  "SWAP (2).wav" -> categorical "SWAP"
%  Helper for run_full_demo.m (kept as its own file so the demo can also be
%  stepped through section by section, when local functions are not visible).
[~,fn] = fileparts(files);
lab = categorical(extractBefore(string(fn)," ("));
end
