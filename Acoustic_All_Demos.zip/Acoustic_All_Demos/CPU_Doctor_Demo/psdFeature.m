function v = psdFeature(Ltn, fs, nFeat)
%PSDFEATURE  the thesis feature: first nFeat bins of the "centered" periodogram
%  PSD of the loudness fluctuation. Helper for run_full_demo.m.
pxx = periodogram(Ltn,[],[],"centered","psd",fs);
v   = pxx(1:nFeat).';
end
