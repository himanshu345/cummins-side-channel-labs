function run_full_demo()
%% CPU Doctor - FULL pipeline demo   (extract features -> train -> classify)
% ---------------------------------------------------------------------------
% For the classroom: the WHOLE chain, nothing pre-baked.
%
%   STEP 1  the recordings
%   STEP 2  turn ONE 20 s clip into 7 numbers, with a plot at every stage
%   STEP 3  do that for every clip  ->  a small feature table  (+ PCA picture)
%   STEP 4  TRAIN a multi-class SVM in front of the class
%   STEP 5  CLASSIFY the test clips  ->  accuracy + confusion matrix
%   STEP 6  recap
%
% Instructions:  OR, SUB (G1) | ADIW, MUL (G2) | ASR, SWAP (G3)
%   train_recordings/  2 clips per instruction   (learn from)
%   test_recordings/   2 clips per instruction   (classify)
%
% Requirements: MATLAB + Audio Toolbox + Signal Processing Toolbox
%               + DSP System Toolbox + Statistics and Machine Learning Toolbox
%
% Run whole:    >> run_full_demo
% Step through: "Run Section" (Ctrl+Enter) each %% block IN ORDER, starting with
%               section 0 -- it puts this folder on the path (addpath) and defines
%               the variables the later sections need. Running a later section on
%               its own will fail with "Unrecognized function 'labelsFromFiles'"
%               or an undefined variable.
% All plots are also written to output/*.png, so it works with no display.
%
% (Note for the presenter: the 12 test clips are the same recordings as the
%  12 training clips, so this is a resubstitution result - the same number the
%  thesis / PSD_Lt.mat reports. Fine for showing the pipeline end to end.)
% ---------------------------------------------------------------------------

clc; close all

%% ================================================================
%  0. locate the folder (run-whole / by-section / by-selection)
%  ================================================================
here = fileparts(mfilename('fullpath'));
if isempty(here)
    for c = [string(pwd), fullfile(pwd,"CPU_Doctor_Demo"), fileparts(which('run_full_demo'))]
        if c ~= "" && isfolder(fullfile(c,'train_recordings')); here = char(c); break; end
    end
end
if ~isempty(here); addpath(here); end   % so the helper .m files are found even
                                        % when you step through a %% section
                                        % from another current folder
trainDir = fullfile(here,'train_recordings');
testDir  = fullfile(here,'test_recordings');
outDir   = fullfile(here,'output');
assert(isfolder(trainDir) && isfolder(testDir), 'run_full_demo:noData', ...
    ['train_recordings/ or test_recordings/ missing under "%s".\n' ...
     'cd into CPU_Doctor_Demo and rerun.'], here);
if ~isfolder(outDir); mkdir(outDir); end

FS     = 44100;   % handed to splMeter/periodogram. The WAVs are really 48 kHz;
                  % the thesis script used 44100, so we do too. Train and test
                  % use the same value, so the classifier is unaffected.
NBLOCK = 7;       % which 1024-sample block to analyse (skips the noisy onset)
NFEAT  = 7;       % PSD bins kept  =  length of the feature vector

fprintf('==========================================================\n');
fprintf(' CPU DOCTOR - full pipeline    (%s)\n', here);
fprintf('==========================================================\n\n');

%% ================================================================
%  1. the recordings
%  ================================================================
trainDS = audioDatastore(trainDir,'IncludeSubfolders',true);
testDS  = audioDatastore(testDir ,'IncludeSubfolders',true);
trainDS.Labels = labelsFromFiles(trainDS.Files);
testDS.Labels  = labelsFromFiles(testDS.Files);
instr   = string(categories(trainDS.Labels));
chance  = 100/numel(instr);

fprintf('STEP 1   the recordings\n');
fprintf('-----------------------\n');
fprintf('  %d instructions : %s\n', numel(instr), strjoin(instr,', '));
fprintf('  train clips     : %d    (2 per instruction)\n', numel(trainDS.Files));
fprintf('  test  clips     : %d    (2 per instruction)\n', numel(testDS.Files));
fprintf('  a clip = ~20 s of that one instruction looping on the MCU.\n');
fprintf('  guessing blindly would score %.0f%% (1 in %d).\n\n', chance, numel(instr));

%% ================================================================
%  2. FEATURE EXTRACTION - narrated on ONE clip
%  ================================================================
fprintf('STEP 2   how one 20-second clip becomes 7 numbers\n');
fprintf('------------------------------------------------\n');

demoFile = trainDS.Files{1};
[~,nm]   = fileparts(demoFile);
fprintf('  example : %s.wav   (true label: %s)\n', nm, string(trainDS.Labels(1)));

% 2a. read audio, pull out analysis block #NBLOCK (1024 samples) --------
[xfull,fsFile] = audioread(demoFile);  xfull = mean(xfull,2);
b0  = (NBLOCK-1)*1024 + 1;
blk = xfull(b0 : b0+1023);                  % the 7th 1024-sample block
fprintf('  a. raw clip ......... %d samples @ %d Hz  (%.1f s)\n', numel(xfull),fsFile,numel(xfull)/fsFile);
fprintf('  b. one block ........ samples %d..%d  (%d samples, ~%.0f ms)\n', ...
        b0, b0+1023, numel(blk), 1000*numel(blk)/FS);

% 2b. loudness envelope L_t, then remove its mean ----------------------
spl = splMeter('TimeWeighting','Fast','SampleRate',FS,'Bandwidth','Full band');
Lt  = spl(blk);  release(spl);
Ltn = Lt - mean(Lt);
fprintf('  c. loudness L_t .... mean %.1f dB  ->  subtract it (only the wobble matters)\n', mean(Lt));

% 2c. spectrum of the wobble; first NFEAT bins = the feature -----------
featVec  = psdFeature(Ltn, FS, NFEAT);            % the 7-number feature vector
pxx1     = periodogram(Ltn,[],[],"onesided","psd",FS);   % for the plot only
fPlot    = (0:numel(pxx1)-1) * (FS/2) / (numel(pxx1)-1);
fprintf('  d. PSD, first %d bins  ->  FEATURE VECTOR:\n     [ %s ]\n\n', ...
        NFEAT, strjoin(compose("%.3e",featVec),'  '));

% 2d. one figure, whole chain ----------------------------------------
f  = figure('Visible','off','Position',[80 80 1000 780]);
tl = tiledlayout(f,4,1,'TileSpacing','compact','Padding','compact');
title(tl, sprintf('CPU Doctor - feature extraction for "%s.wav"',nm))
nexttile; plot((0:numel(xfull)-1)/fsFile,xfull); grid on
xregion((b0-1)/fsFile,(b0+1022)/fsFile,'FaceColor','r');
title('(a) raw waveform   (red = the 1024-sample analysis block)'); xlabel('time (s)'); ylabel('amp')
nexttile; plot((0:numel(blk)-1)/FS*1000,blk); grid on
title(sprintf('(b) analysis block #%d   (the ~23 ms we actually analyse)',NBLOCK)); xlabel('time (ms)'); ylabel('amp')
nexttile; plot((0:numel(Ltn)-1)/FS*1000,Ltn); grid on
title('(c) loudness fluctuation   L_t - mean(L_t)   [splMeter "Fast"]'); xlabel('time (ms)'); ylabel('dB')
nexttile; semilogy(fPlot, pxx1); grid on; xlim([0 2000])
title(sprintf('(d) spectrum of (c)  -  %d numbers summarising this curve = the feature vector',NFEAT))
xlabel('frequency (Hz)'); ylabel('power (log)')
exportgraphics(f,fullfile(outDir,'01_feature_extraction.png'),'Resolution',140);
fprintf('  -> output/01_feature_extraction.png\n\n');

%% ================================================================
%  3. feature table for EVERY clip
%  ================================================================
fprintf('STEP 3   the feature table (each clip -> a row of 7 numbers)\n');
fprintf('----------------------------------------------------------\n');
[Xtr,ytr] = extractFeatures(trainDS, FS, NBLOCK, NFEAT);
[Xte,yte] = extractFeatures(testDS , FS, NBLOCK, NFEAT);

T = array2table(Xtr,'VariableNames',compose("PSD%d",1:NFEAT));
T.Instruction = ytr;
disp(T)
fprintf('  ^ 12 clips, each now a point in 7-D space, tagged with its instruction.\n');
fprintf('    Next: train a classifier to draw the boundaries between them.\n');

[~,score] = pca(zscore(Xtr));
g = figure('Visible','off','Position',[80 80 700 560]);
gscatter(score(:,1),score(:,2),ytr,lines(numel(instr)),'.',24); grid on
title('feature space  (first 2 principal components of the 7 features)')
xlabel('PC 1'); ylabel('PC 2')
exportgraphics(g,fullfile(outDir,'02_feature_space.png'),'Resolution',140);
fprintf('  -> output/02_feature_space.png   (one colour per instruction)\n\n');

%% ================================================================
%  4. TRAIN a multi-class SVM
%  ================================================================
fprintf('STEP 4   training a multi-class SVM\n');
fprintf('----------------------------------\n');
rng(1)
% features span ~6 orders of magnitude -> work in log10, the natural scale
Xtr_m = log10(Xtr);
Xte_m = log10(Xte);
svmT  = templateSVM('KernelFunction','gaussian','Standardize',true);
Mdl   = fitcecoc(Xtr_m, ytr, 'Learners', svmT, 'Coding','onevsone');
nBin  = numel(Mdl.BinaryLearners);
fprintf('  input    : log10 of the 7 PSD features, then standardised\n');
fprintf('  model    : ECOC one-vs-one  ->  %d binary SVMs vote  (C(%d,2))\n', nBin, numel(instr));
fprintf('  kernel   : Gaussian (RBF)\n\n');

%% ================================================================
%  5. CLASSIFY the test clips
%  ================================================================
fprintf('STEP 5   classify the test recordings\n');
fprintf('------------------------------------\n');
ypred    = predict(Mdl, Xte_m);
accTest  = 100*mean(ypred == yte);
accTrain = 100*mean(predict(Mdl,Xtr_m) == ytr);

fprintf('  training-set accuracy : %5.1f %%\n', accTrain);
fprintf('  test-set accuracy     : %5.1f %%   (%d / %d clips)\n\n', ...
        accTest, sum(ypred==yte), numel(yte));

fprintf('  per-clip predictions on test_recordings/:\n');
disp(table(string(yte), string(ypred), yte==ypred, ...
     'VariableNames',{'Actual','Predicted','Correct'}))

% cross-check against the shipped pre-trained model -----------------
if isfile(fullfile(here,'PSD_Lt.mat'))
    S   = load(fullfile(here,'PSD_Lt.mat'),'trainedELSVMModel');
    Tte = array2table(Xte,'VariableNames',compose("Var%d",1:NFEAT));
    Tte.ActivityID = yte;                       % the shipped model expects this column
    yShip  = categorical(string(S.trainedELSVMModel.predictFcn(Tte)));
    accShip = 100*mean(yShip==yte);
    fprintf('  same clips through the shipped PSD_Lt.mat model : %.0f%% (%d/%d)\n\n', ...
            accShip, sum(yShip==yte), numel(yte));
end

h = figure('Visible','off','Position',[80 80 640 560]);
confusionchart(yte, ypred, 'RowSummary','row-normalized', ...
    'Title', sprintf('CPU Doctor - Arduino instruction recognition: %.0f%%', accTest));
exportgraphics(h,fullfile(outDir,'03_confusion_matrix.png'),'Resolution',140);
fprintf('  -> output/03_confusion_matrix.png\n');

%% ================================================================
%  6. recap
%  ================================================================
fprintf('\n==========================================================\n');
fprintf(' RECAP\n');
fprintf('==========================================================\n');
fprintf(' FEATURE  20 s clip -> one 1024-sample block -> loudness L_t\n');
fprintf('          -> minus mean -> PSD -> first 7 bins   = 7 numbers\n');
fprintf(' MODEL    %d one-vs-one Gaussian SVMs (ECOC) on log10 features\n', nBin);
fprintf(' RESULT   %.0f%% instruction recognition on the test recordings\n', accTest);
fprintf(' FILES    output/01_feature_extraction.png\n');
fprintf('          output/02_feature_space.png\n');
fprintf('          output/03_confusion_matrix.png\n');
fprintf('==========================================================\n');
end

% Helpers live in their own files in this folder, so the demo works whether you
% run it whole or step through it section by section (local functions are not
% visible when a %% section / selection is evaluated on its own):
%   labelsFromFiles.m   splMeterEnvelope.m   psdFeature.m   extractFeatures.m
