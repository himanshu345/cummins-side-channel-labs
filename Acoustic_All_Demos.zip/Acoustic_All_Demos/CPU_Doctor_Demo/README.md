# CPU Doctor — Demo

Recognises which **AVR / Arduino assembly instruction** a microcontroller is
executing, purely from the **sound** it emits (acoustic side channel).

## Requirements

MATLAB with:
- Audio Toolbox
- Signal Processing Toolbox
- DSP System Toolbox
- Statistics and Machine Learning Toolbox

## Two scripts

| Script | What it shows |
|--------|---------------|
| **`run_demo`**      | the quick version — load the 12 clips, run the pre-trained model in `PSD_Lt.mat`, print `100 %`. |
| **`run_full_demo`** | the **teaching version** — extract the features from scratch (with plots), **train** the classifier live, then classify the test clips. Prints `100 %`. Use this in the classroom. |

```matlab
>> cd CPU_Doctor_Demo
>> run_full_demo        % or: run_demo
```

Both are self-contained and location-independent. All plots are also written to
`output/*.png`, so the scripts work on a headless machine.

---

## `run_full_demo` — the pipeline, step by step

1. **STEP 1 – the recordings.** 6 instructions (`OR, SUB, ADIW, MUL, ASR, SWAP`),
   2 clips each in `train_recordings/`, 2 each in `test_recordings/`.
2. **STEP 2 – feature extraction, narrated on one clip.** 20 s clip → the 7th
   1024-sample block (~23 ms) → time-weighted loudness `L_t` (`splMeter`, "Fast")
   → subtract the mean → power spectral density → **first 7 bins = the feature
   vector**. Written to `output/01_feature_extraction.png`.
3. **STEP 3 – the feature table.** Every clip → a row of 7 numbers, plus a PCA
   scatter (`output/02_feature_space.png`).
4. **STEP 4 – training.** A multi-class SVM: ECOC one-vs-one → 15 binary
   Gaussian-kernel SVMs, on `log10` of the features (they span orders of
   magnitude), standardised.
5. **STEP 5 – classify the test clips** → **100 % (12/12)**, per-clip table, and
   `output/03_confusion_matrix.png`. Cross-checked against the shipped
   `PSD_Lt.mat` model (also 100 %).

## Expected result

```
training-set accuracy : 100.0 %
test-set accuracy     : 100.0 %   (12 / 12 clips)
```

## Note on the number

`run_full_demo` and the shipped `PSD_Lt.mat` both report **100 %**, matching the
thesis. This is a **resubstitution** result: there are 2 recordings per
instruction and the 12 `test_recordings/` WAVs are the same recordings as the 12
`train_recordings/` WAVs. It demonstrates the end-to-end pipeline
(sound → features → trained classifier → instruction), not a
cross-session generalisation result — the same situation as the
App_Classification demo. A real generalisation estimate needs many independent
recordings per instruction and a by-session train/test split.

## Contents

| File | Purpose |
|------|---------|
| `run_demo.m`              | quick demo — pre-trained model, prints 100 % |
| `run_full_demo.m`         | teaching demo — extract + train + classify, prints 100 % |
| `labelsFromFiles.m`, `splMeterEnvelope.m`, `psdFeature.m`, `extractFeatures.m` | helpers for `run_full_demo` (own files so it can be stepped through section by section) |
| `PSD_Lt.mat`              | the pre-trained model (`trainedELSVMModel`, 38-class ECOC linear SVM) |
| `train_recordings/G1..G3/`| 12 training clips (2 per instruction), from `cpudr/Workshop_all/Workshop/` |
| `test_recordings/G1..G3/` | 12 test clips (2 per instruction) — same recordings, from `cpudr/Workshop_all/simple/` |
| `output/`                 | generated PNGs |

## Notes

- `run_demo.m` is a trimmed copy of `cpudr/CPU_Dr_PSD_Lt.m` with the interactive
  `classificationLearner` steps removed; `run_full_demo.m` replaces the
  Classification Learner step with a scripted `fitcecoc` so training happens live.
- `PSD_Lt.mat` is the whole saved workspace from that thesis script; only the
  `trainedELSVMModel` variable is used.
- Full training set (38 instruction types, 76 clips):
  `cpudr/Workshop_all/Workshop/`.
